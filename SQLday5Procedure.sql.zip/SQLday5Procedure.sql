select * from tbl_employee
--1
Create proc proc_addEmployee(@name varchar(100),@city varchar(100),@password varchar(100))
as
insert tbl_employee values(@name,@city,@password,getdate())
return @@identity
--2
create proc proc_employeedetail(@id int)
as
select * from tbl_employee where EmployeeID=@id
--3
create proc proc_Showemployees(@city varchar(100))
as
select * from tbl_employee where EmployeeCity=@city
--4
create proc proc_searchemployees(@key varchar(100))
as
select * from tbl_employee where EmployeeID like '%'+@key+'%' or EmployeeName like '%'+@key+'%' or EmployeeCity like '%'+@key+'%';
--5
create proc proc_Updateemployees(@id int,@city varchar(100),@password varchar(100))
as
update tbl_employee set EmployeeCity=@city,EmployeePassword=@password where
EmployeeID=@id
return @@rowcount
--6
create proc proc_deleteemployees(@id int)
as
delete tbl_employee where EmployeeID=@id
return @@rowcount
--7
create proc proc_login(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_employee where EmployeeID=@id and EmployeePassword=@password
return @count




