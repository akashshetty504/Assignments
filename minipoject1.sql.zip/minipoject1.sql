create database BankingDB

use BankingDB

create table tbl_Customers
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(100),
CustomerEmail varchar(100),
CustomerMobileNo varchar(100),
CustomerGender varchar(100),
CustomerPassword varchar(100)
)

 
create table tbl_Accounts
(
AccountID int identity(100,1)primary key,
CustomerID int not null foreign key references tbl_Customers(CustomerID),
AccountBalance int,
AccountType varchar(100),
AccountOD datetime
)
select * from tbl_Accounts

create table tbl_Transactions
(
TransID int identity(1,1)primary key,
AccountID int foreign key references tbl_Accounts(AccountID),
Amount int ,
TransType varchar(100),
TransDate DateTime
) 
select * from tbl_Transactions


create proc proc_addCustomer(@name varchar(100),@email varchar(100),@mobileno varchar(100),@gender varchar(100),@password varchar(100))
as
insert tbl_Customers values(@name,@email,@mobileno,@gender ,@password)
return @@identity

create proc proc_login(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_Customers where CustomerID=@id and CustomerPassword=@password
return @count

alter proc proc_addAccount(@id int,@balance int,@acctype varchar(100))
as 
insert tbl_Accounts values(@id,@balance,@acctype,GETDATE())
return @@identity
select * from tbl_Accounts


create proc proc_my_account(@id int)
as
select * from tbl_Accounts where CustomerID=@id

alter proc proc_addtransaction(@AccountID int,@amount int ,@type varchar(100))
as
insert tbl_Transactions values(@AccountID,@amount,@type,GETDATE())
return @@identity

create proc proc_my_Transaction(@id int)
as
select * from tbl_Transactions where AccountID=@id

select * from tbl_Accounts
select * from tbl_Transactions

alter trigger Account_Balance
on tbl_Transactions
for insert
as 
begin
declare @AccounID int
declare @amount int
declare @type varchar(100)
select @AccounID=AccountID,@amount=amount,@type=Transtype from inserted
begin
if(@type='withdraw')
update tbl_Transactions set Amount=Amount-@amount where AccountID=@AccounID
end
if(@type='deposit')
begin
update tbl_Transactions set Amount=Amount+@amount where AccountID=@AccounID
end 
end

create proc proc_account_per(@cid int)
as
select AccountID from tbl_Accounts where CustomerID=@cid