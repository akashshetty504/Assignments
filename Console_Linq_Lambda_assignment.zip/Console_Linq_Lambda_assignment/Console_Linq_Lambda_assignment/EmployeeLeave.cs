﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq_Lambda_assignment
{
    class EmployeeLeave
    {
        public int EmployeeID { get; set; }
        public int LeaveID { get; set; }
        public string LeaveType { get; set; }
        public string Reason { get; set; }
    }
}
