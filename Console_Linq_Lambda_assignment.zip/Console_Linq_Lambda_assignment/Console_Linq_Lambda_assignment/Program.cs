﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq_Lambda_assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employees> emplist = new List<Employees>();
            emplist.Add(new Employees { EmployeeID = 1000, EmployeeName = "ABC", EmployeeCity = "pune", EmployeeSalary = 35000, EmployeeExp = 2 });
            emplist.Add(new Employees { EmployeeID = 1001, EmployeeName = "XYZ", EmployeeCity = "Chennai", EmployeeSalary = 60000, EmployeeExp = 3 });
            emplist.Add(new Employees { EmployeeID = 1002, EmployeeName = "DEF", EmployeeCity = "BGL", EmployeeSalary = 50000, EmployeeExp = 5 });
            emplist.Add(new Employees { EmployeeID = 1003, EmployeeName = "GHI", EmployeeCity = "BGL", EmployeeSalary = 25000, EmployeeExp = 6 });

            List<EmployeeLeave> levlist = new List<EmployeeLeave>();
            levlist.Add(new EmployeeLeave { EmployeeID = 1001, LeaveID = 1, LeaveType = "casual", Reason = "function" });
            levlist.Add(new EmployeeLeave { EmployeeID = 1002, LeaveID = 2, LeaveType = "casual", Reason = "fever" });
            levlist.Add(new EmployeeLeave { EmployeeID = 1001, LeaveID = 3, LeaveType = "casual", Reason = "trip" });
            levlist.Add(new EmployeeLeave { EmployeeID = 1003, LeaveID = 4, LeaveType = "casual", Reason = "marriage" });
            //linq 1
            var q = from e in emplist
                    where e.EmployeeExp > 5
                    select new { EID = e.EmployeeID, EName = e.EmployeeName, ECity = e.EmployeeCity };
            foreach (var x in q)
            {
                Console.WriteLine(x.EID + " " + x.EName + " " + x.ECity);
            }
            //lambda 1
            var l = emplist.Where((e) => e.EmployeeExp > 5);
            foreach (var x in l)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeCity);

            }
            //linq 2
            var getsalary = from e in emplist
                            where e.EmployeeSalary > 50000
                            select new { EID = e.EmployeeID, EName = e.EmployeeName, ECity = e.EmployeeCity, EExp = e.EmployeeExp };

            foreach (var p in getsalary)
            {
                Console.WriteLine(p.EID + " " + p.EName + " " + p.ECity + " " + p.EExp);
            }
            //lambda 2
            var o = emplist.Where((e) => e.EmployeeSalary > 50000);
            foreach (var x in o)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + x.EmployeeCity + " " + x.EmployeeExp);

            }


            //linq 3
            string City = "BGL";
            var v = from e in emplist
                    where e.EmployeeCity == City
                    select e;
            foreach (var x in v)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExp);

            }
            //lambda 3
            var c = emplist.Where((e) => e.EmployeeCity == "BGL");
            foreach (var x in c)
            {
                Console.WriteLine(x.EmployeeID + " " + x.EmployeeName + " " + x.EmployeeSalary + " " + x.EmployeeExp);

            }
            //linq 4
            var FL = from e in emplist
                     where e.EmployeeName.StartsWith("A")
                     select e;
            foreach (var d in FL)
            {
                Console.WriteLine(d.EmployeeID + " " + d.EmployeeName + " " + d.EmployeeCity + " " + d.EmployeeSalary + " " + d.EmployeeExp);

            }
            //lambda 4
            var FL1 = emplist.Where((e) => e.EmployeeName.StartsWith("A"));
            foreach (var d in FL1)
            {
                Console.WriteLine(d.EmployeeID + " " + d.EmployeeName + " " + d.EmployeeCity + " " + d.EmployeeSalary + " " + d.EmployeeExp);

            }
            //linq 5
            var joindata = from e in emplist join
                           i in levlist on
                           e.EmployeeID equals i.EmployeeID
                           select new { EID = e.EmployeeID, EName = e.EmployeeName, ECity = e.EmployeeCity, ESalary = e.EmployeeSalary, EExp = e.EmployeeExp, LID = i.LeaveID, LType = i.LeaveType, LReason = i.Reason };
            foreach (var j in joindata)
            {
                Console.WriteLine(j.EID + " " + j.EName + " " + j.ECity + " " + j.ESalary + " " + j.EExp + " " + j.LID + " " + j.LType + " " + j.LReason);

            }
            //lambda 5
            var joindata2 = emplist.Join(levlist, (e) => e.EmployeeID, (i) => i.EmployeeID,
                 (e, i) => new
                 {
                     EID = e.EmployeeID,
                     EName = e.EmployeeName,
                     ECity = e.EmployeeCity,
                     ESalary = e.EmployeeSalary,
                     EExp = e.EmployeeExp,
                     LID=i.LeaveID,
                     LType=i.LeaveType,
                     LReason=i.Reason
                 });

            foreach(var f in joindata2)
            {
                Console.WriteLine(f.EID + " " + f.EName + " " + f.ECity + " " + f.ESalary + " " + f.EExp + " " + f.LID + " " + f.LType + " " + f.LReason);
            }


            Console.ReadLine();
        }
    }
}
