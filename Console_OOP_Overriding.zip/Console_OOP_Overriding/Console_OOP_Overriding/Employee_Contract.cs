﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Employee_Contract:Employee
    {
        public Employee_Contract(int EmployeeID,string EmployeeName,int EmployeeSalary)
        :base(EmployeeID,EmployeeName,EmployeeSalary)
        {

        }
        public override int GetSalary(int Days)
        {
            int TotalSalary = this.PEmployeeSalary / 30 * Days;
            return TotalSalary;
        }
        
    }
}
