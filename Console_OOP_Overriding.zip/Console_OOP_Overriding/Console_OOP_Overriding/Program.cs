﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter employee ID");
            int ID= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter Employee Name");
            string Name = Console.ReadLine();
            Console.WriteLine("employee salary");
            int Salary = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter type Name");
            string Type = Console.ReadLine();


            Employee obj = null;
            if (Type == "Employee")
            {

                obj = new Employee(ID, Name, Salary);
            }
            else if(Type== "Contract")
            {
                obj = new Employee_Contract(ID, Name, Salary);
            }
            else if(Type=="Trainee")
            {
                obj = new Employee_Trainee(ID, Name, Salary);
            }
            if (obj != null)
            {
                string Work = obj.GetWork();
                
                Console.WriteLine(Work);

                Console.WriteLine("enter no. of Days :");
                int Days = Convert.ToInt32(Console.ReadLine());
                int CurrentMonthSalary = obj.GetSalary(Days);
                Console.WriteLine("Salary :" + " " + CurrentMonthSalary);
                Console.ReadLine();
            }
        }
    }
}
