create database Library1db


use librarydb

create table tbl_Students
(
StudentID int identity(1000,1)primary key,
StudentName varchar(100) not null,
StudentEmailID varchar(100) not null,
StudentPassword varchar(100) not null,
StudentImage varchar(100) not null
) 

select * from tbl_Students 

select * from tbl_books

create table tbl_Books1
(
BookID int identity(100,1) primary key,
BookName varchar(100) not null,
AuthorName varchar(100) not null,
BookImage varchar(100) not null
)
select *  from tbl_Books1

create table tbl_issuebook
(
IssueID int identity(2000,1) primary key,
BookID int not null foreign key references tbl_Books1(BookID),
StudentID int not null foreign key references tbl_Students(StudentID),
IssueDate DateTime,
IssueStatus varchar(100)
)
select * from tbl_issuebook

create proc proc_addstudents(@name varchar(100),@emailid varchar(100),@password varchar(100),
@stdimage varchar(100))
as
insert tbl_Students values(@name,@emailid,@password,@stdimage)
return @@identity

create proc proc_login(@sid int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_Students where StudentID=@sid and StudentPassword=@password
return @count


alter proc proc_AddBook(@bname varchar(100),@aname varchar(100),@image varchar(100))
as
insert tbl_Books1 values(@bname,@aname,@image)
return @@identity

select * from tbl_Books1


alter proc proc_Searchbook(@key varchar(100))
as
select * from tbl_Books1 where BookID like '%'+@key+'%'
or BookName like '%' +@key+ '%'
or AuthorName like '%'+@key+'%'




alter proc proc_Details(@bid  int)
as
select * from tbl_Books1 where BookID=@bid


create proc proc_Details(@bid int)
as
select * from tbl_Books1 where BookID=@bid



alter proc proc_Login1(@sid int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_Students where StudentID=@sid and StudentPassword=@password
return @count


alter proc proc_issuebook(@sid int,@bid int)
as
insert tbl_issuebook values(@sid,@bid,GETDATE())
return @@identity









alter proc proc_IssueBook(@bid int,@sid int)
as
insert tbl_issuebook values(@bid,@sid,GETDATE(),'issued')
return @@identity

