﻿namespace Salary_Cal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_days = new System.Windows.Forms.Label();
            this.lbl_Per_Day_Salary = new System.Windows.Forms.Label();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.txt_Per_Day_Salary = new System.Windows.Forms.TextBox();
            this.btn_Get_Salary = new System.Windows.Forms.Button();
            this.lbl_Salary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_days
            // 
            this.lbl_days.AutoSize = true;
            this.lbl_days.Location = new System.Drawing.Point(40, 62);
            this.lbl_days.Name = "lbl_days";
            this.lbl_days.Size = new System.Drawing.Size(44, 17);
            this.lbl_days.TabIndex = 0;
            this.lbl_days.Text = "Days:";
            // 
            // lbl_Per_Day_Salary
            // 
            this.lbl_Per_Day_Salary.AutoSize = true;
            this.lbl_Per_Day_Salary.Location = new System.Drawing.Point(47, 149);
            this.lbl_Per_Day_Salary.Name = "lbl_Per_Day_Salary";
            this.lbl_Per_Day_Salary.Size = new System.Drawing.Size(105, 17);
            this.lbl_Per_Day_Salary.TabIndex = 1;
            this.lbl_Per_Day_Salary.Text = "Per Day salary:";
            // 
            // txt_days
            // 
            this.txt_days.Location = new System.Drawing.Point(286, 71);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(100, 22);
            this.txt_days.TabIndex = 2;
            // 
            // txt_Per_Day_Salary
            // 
            this.txt_Per_Day_Salary.Location = new System.Drawing.Point(282, 156);
            this.txt_Per_Day_Salary.Name = "txt_Per_Day_Salary";
            this.txt_Per_Day_Salary.Size = new System.Drawing.Size(100, 22);
            this.txt_Per_Day_Salary.TabIndex = 3;
            // 
            // btn_Get_Salary
            // 
            this.btn_Get_Salary.Location = new System.Drawing.Point(168, 273);
            this.btn_Get_Salary.Name = "btn_Get_Salary";
            this.btn_Get_Salary.Size = new System.Drawing.Size(93, 23);
            this.btn_Get_Salary.TabIndex = 4;
            this.btn_Get_Salary.Text = "Get Salary";
            this.btn_Get_Salary.UseVisualStyleBackColor = true;
            this.btn_Get_Salary.Click += new System.EventHandler(this.btn_Get_Salary_Click);
            // 
            // lbl_Salary
            // 
            this.lbl_Salary.AutoSize = true;
            this.lbl_Salary.Location = new System.Drawing.Point(327, 278);
            this.lbl_Salary.Name = "lbl_Salary";
            this.lbl_Salary.Size = new System.Drawing.Size(46, 17);
            this.lbl_Salary.TabIndex = 5;
            this.lbl_Salary.Text = "salary";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 399);
            this.Controls.Add(this.lbl_Salary);
            this.Controls.Add(this.btn_Get_Salary);
            this.Controls.Add(this.txt_Per_Day_Salary);
            this.Controls.Add(this.txt_days);
            this.Controls.Add(this.lbl_Per_Day_Salary);
            this.Controls.Add(this.lbl_days);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_days;
        private System.Windows.Forms.Label lbl_Per_Day_Salary;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.TextBox txt_Per_Day_Salary;
        private System.Windows.Forms.Button btn_Get_Salary;
        private System.Windows.Forms.Label lbl_Salary;
    }
}

