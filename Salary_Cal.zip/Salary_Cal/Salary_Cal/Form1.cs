﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salary_Cal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Get_Salary_Click(object sender, EventArgs e)
        {
            if(txt_days.Text==String.Empty)
            {
                MessageBox.Show("enter the days");
            }
            else if(txt_Per_Day_Salary.Text==string.Empty)
            {
                MessageBox.Show("enter per day salary");
            }
            else
            {
                int days = Convert.ToInt32(txt_days.Text);
                int Per_Day_salary = Convert.ToInt32(txt_Per_Day_Salary.Text);

                SalaryLibrary.Salary obj = new SalaryLibrary.Salary();
                int total = obj.GetSalary(days, Per_Day_salary);
                lbl_Salary.Text = total.ToString();
            }
        }
    }
}
