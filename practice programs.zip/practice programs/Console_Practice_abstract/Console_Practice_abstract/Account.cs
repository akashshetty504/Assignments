﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice_abstract
{
    class Account
    {
        private int AccountID;
        private string CustomerName;
        private int Balance;

        public Account(int AccountID, string CustomerName,int Balance)
        {
            this.AccountID = AccountID;
            this.CustomerName = CustomerName;
            this.Balance = Balance;

        }
        public int PAccountID { get { return this.AccountID; } }
        public string PCustomerName { get { return this.CustomerName; } }
        public int PBalance { get { return this.Balance; } }

        public void StopPayment()
        {
            Console.WriteLine(" stop payment");

        }
        public void BlockPayment()
        {
            Console.WriteLine("Block Payment");
        }
        public int GetBalance()
        {
            return this.Balance;
        }
        public abstract void Deposit(int Amt);
        public abstract void Withdraw(int Amt);
    }
}
