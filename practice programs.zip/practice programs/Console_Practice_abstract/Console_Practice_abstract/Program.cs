﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice_abstract
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the account Id");
            int ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the Customer name");
            string Name = Console.ReadLine();
            Console.WriteLine("enter the Balance");
            int Balance = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the type");
            string Type = Console.ReadLine();

            Account obj = null;
            {

            }

        }
    }
}
