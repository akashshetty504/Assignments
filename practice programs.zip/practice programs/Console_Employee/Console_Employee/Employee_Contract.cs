﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice_Overriding
{
    class Employee_Contract:Employee
    {
       public Employee_Contract(int EmployeeID,string EmployeeName,int Salary)
            :base(EmployeeID,EmployeeName,Salary)
        {

        }
            public override int GetSalary(int Days)
        {
            int Totalsalary1 = (PSalary / 30 * Days)+1000;
            return Totalsalary1;
        }

    }
}
