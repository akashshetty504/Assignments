﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Employee ID");
            int ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter Employee Name");
            string Name = Console.ReadLine();
            Console.WriteLine("enter the salary");
            int Salary = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the type");
            string Type = Console.ReadLine();

            Employee obj = null;
            if (Type=="Employee")
            {
                obj = new Employee(ID, Name, Salary);
            }
            else if(Type=="Employee_Contract")
            {
                obj = new Employee_Contract(ID, Name, Salary);
            }
            if (obj != null)
            {
                string Work = obj.GetWork();
                Console.WriteLine(Work);
                Console.WriteLine("eneter the days");
                int Days = Convert.ToInt32(Console.ReadLine());
                int TotalMonthlySalary = obj.GetSalary(Days);
                Console.WriteLine("Salary" + " "+ TotalMonthlySalary);
                Console.ReadLine();
            }
        }
    }
}
