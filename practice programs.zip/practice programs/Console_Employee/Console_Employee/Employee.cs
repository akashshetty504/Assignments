﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice_Overriding
{
    class Employee
    {
        private int EmployeeID;
        private string EmployeeName;
        private int Salary;

        public Employee(int EmployeeID, string EmployeeName, int Salary)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.Salary = Salary;
        }
        public int PEmployeeId { get { return this.EmployeeID; } }
        public string PEmployeeName { get { return this.EmployeeName; } }
        public int PSalary { get { return this.Salary; } }

        public string GetWork()
        {
            return "writing overriding program";
       
        }
        public virtual int GetSalary(int Days)
        {
            int TotalSalary = this.Salary / 30 * Days;
            return TotalSalary;
        }


        }
    
}
