﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter order id");
            int ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the customer name");
            string Name = Console.ReadLine();
            Console.WriteLine("enter item name");
            string Item = Console.ReadLine();
            Console.WriteLine("enter the item price");
            int Price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the item quantity");
            int Quantity = Convert.ToInt32(Console.ReadLine());

            Order1 obj = new Order1(ID, Name, Item, Price, Quantity);

            int Amt = obj.GetOrder();
                Console.WriteLine(Amt);

            string Details = obj.GetDetails();
            Console.WriteLine(Details);
            Console.ReadLine();




        }
    }
}
