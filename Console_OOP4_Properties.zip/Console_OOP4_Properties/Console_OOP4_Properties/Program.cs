﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Properties
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter Customer name");
            string Name = Console.ReadLine();
            Console.WriteLine("item name");
            string ItemName = Console.ReadLine();
            Console.WriteLine("enter item quantity");
            int Quantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item price");
            int Price = Convert.ToInt32(Console.ReadLine());
            Order obj = new Order (Name, ItemName, Quantity, Price);

            Console.WriteLine(obj.POrderID +" "+obj.PCustomerName+" "+obj.PItemName+" "+obj.PItemQuantity+" " +obj.PItemPrice);
            Console.ReadLine();

            

       
        }
    }
}
