﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Properties
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemQuantity;
        private int ItemPrice;

        public int POrderID
        {
            get
            {
                return this.OrderID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }set
            {
                this.CustomerName = value;
            }
        }
       public string PItemName
        {
            get
            {
                return this.ItemName;

            }
        }
        public int PItemQuantity
        {
            get
            {
                return this.ItemQuantity;
            }
            set
            {
                this.ItemQuantity = value;
            }
            }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }set
            {
                this.ItemPrice = value;
            }
        }
        private static int count = 20;
        
         public Order(string CustomerName, string ItemName, int ItemQuantity, int ItemPrice)
        {
            Order.count++;
            this.OrderID = Order.count;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
        }
        

    }

       
    }

