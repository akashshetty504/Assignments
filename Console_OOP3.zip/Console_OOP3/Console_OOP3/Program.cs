﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("order id");
            int ID = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("customer name");
            string Name = Console.ReadLine();
            Console.WriteLine("item name");
            string Item = Console.ReadLine();
            Console.WriteLine("item price");
            int Price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("item quantity");
            int Quantity = Convert.ToInt32(Console.ReadLine());

            Order obj = new Order(ID, Name, Item, Price, Quantity);
            int orderAmt = obj.OrderAmt();
            Console.WriteLine(orderAmt);
            Console.ReadLine();
        }
    }
}
