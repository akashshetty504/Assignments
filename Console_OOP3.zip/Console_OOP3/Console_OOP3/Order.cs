﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP3
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;

        public Order(int OrderID,string CustomerName,string ItemName,int ItemPrice,int ItemQuantity)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;
        }

        public int OrderAmt()
        {
            return ItemPrice * ItemQuantity;
        }

    }
}
