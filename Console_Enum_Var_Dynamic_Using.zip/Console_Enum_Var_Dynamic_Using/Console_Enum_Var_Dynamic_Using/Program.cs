﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using x=Console_Enum_Var_Dynamic_Using1;
using static Console_Enum_Var_Dynamic_Using1.Test;

namespace Console_Enum_Var_Dynamic_Using
{
    class Program
    {
        static void Main(string[] args)
        {
            var i = 100;
           x.Test t = new x.Test();
            t.MakePayment(Paymenttype.NetBanking);
            call();
        }
    }
}
