﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Console_Enum_Var_Dynamic_Using;

namespace Console_Enum_Var_Dynamic_Using1
{
    class Test
    {
        public void MakePayment(Paymenttype t)
        {
            Console.WriteLine(t);
        }
        public static void call()
        {

        }
    }
}
