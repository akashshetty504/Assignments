﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Singleton
{
    class Manager
    {
        private int ManagerID;
        private string ManagerName;
        
        public int PManagerId { get { return this.ManagerID; } }
        public string PManagerName { get { return this.ManagerName; } }
        private Manager(int ManagerID,string ManagerName)
        {
            this.ManagerID = ManagerID;
            this.ManagerName = ManagerName;
        }
        static Manager m;
        public static Manager GetManager()
        {
            if (m == null)
            {
                m = new Manager(1001, "abc");
            }
            return m;
        }
    

    }
}
