create database studentdb
use studentdb


create table tbl_students
(
StudentID int identity(1000,1) primary key,
StudentName varchar(100) not null,
StudentCity varchar(100) not null,
StudentImageAddress varchar(100) not null
)

select * from tbl_students




create proc proc_addstudent(@name varchar(100),@city varchar(100),@address varchar(100))
as
insert tbl_students values(@name,@city,@address)
return @@identity

create proc proc_search(@key varchar(1000))
as
select * from tbl_students where StudentID like '%' +@key+'%'
or StudentName like '%'+@key+ '%'
or StudentCity like '%' +@key+ '%'


create proc proc_details(@id  int)
as
select * from tbl_students where StudentID=@id

select * from tbl_students