create database orderASP1

use orderASP1

create table tbl_orderASP1
(
orderid int identity(200,1)primary key,
customeremailid varchar(100),
productid int,
productprice int,
productqty int,
producttype varchar(100),
ordercity varchar(100),
delivaryaddress varchar(100)
) 

select * from tbl_orderASP1

create proc proc_addorder(@emailid varchar(100),@pid int,@price int,@qty int,@type varchar(100),
@city varchar(100),@address varchar(100))
as
insert tbl_orderASP1 values(@emailid,@pid,@price,@qty,@type,@city,@address)
return @@identity









