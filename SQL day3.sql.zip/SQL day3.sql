
declare @count int=0;
set @count=100;
select @count=count(*) from tbl_employees;
if(@count>0)
begin
--update
end
else
begin

end

select @count;

declare @count int=0;
while(@count<10)
begin
select @count;
set @count=@count+1;
end

alter  proc sp_employees
as
select * from tbl_employees order by employeesalary desc

exec sp_employees

create proc sp_employees_city (@city varchar(100))
as
select * from tbl_employees where employeecity=@city

exec sp_employees_city'chennai'

select * from tbl_employees


select * from tbl_accounts

alter proc sp_add_account(@name varchar(100),@balance int)
as
if(@balance>=1000)
begin 
insert tbl_accounts values(@name,@balance)
return @@identity
end
else
begin
return 0
end


declare @r int
exec @r=sp_add_account 'ABCD',20000
select @r

create proc sp_account_balance (@accountid int)
as
declare @balance int
select @balance=accountbalance from tbl_accounts where accountid=@accountid;
return @balance


declare @bal int 
exec @bal =sp_account_balance 3
select @bal

select * from tbl_customerinfo

create proc sp_login(@id int,@password varchar(100))
as
declare @count int
select @count=count(*)from tbl_customerinfo
where customerid=@id and customerpassword=@password
return @count

declare @c int
exec @c=sp_login 100,'password1'
select @c


select * from tbl_employees

create proc sp_employee_details(@id int,@name varchar(100) output,@city varchar(100)output)
as
select @name=employeename,@city=employeecity from tbl_employees where employeeid=@id

declare @name varchar(100)
declare @city varchar(100)
exec sp_employee_details 1001,@name output,@city output
select @name,@city

create table tbl_student
(
studentid int,
studentname varchar(100),
studentcity varchar(100)
)

alter  trigger trg_add_student
on tbl_student
for insert
as
begin
select * from inserted
select 'trigger fired'
end

insert tbl_student values(7,'A','pune')

select * from tbl_student

create table tbl_stock
(
itemid int identity(1,1)primary key,
itemqty int not null
)
insert tbl_stock values(100)
select * from tbl_stock

create table tbl_orders1
(
orderid int identity(1000,1)primary key,
itemid int not null foreign key references  tbl_stock(itemid),
orderqty int not null,
price int not null
)

insert tbl_orders1 values(1,30,200)

select * from tbl_orders1

 
 create trigger trg_update_stock
 on tbl_orders1
 for insert
 as
 begin 
 declare @itemid int
 declare @orderqty int
 select @itemid=itemid,@orderqty=orderqty from inserted
 update tbl_stock set itemqty=itemqty-@orderqty where itemid=@itemid
 end

 select * from tbl_employees


 alter view v_employee_BGL
 with encryption,schemabinding
 as
 select employeeid,employeename,employeesalary,employeecity from dbo.tbl_employees where employeecity='banglore'
 with check option

 drop table tbl_employees


 sp_helptext v_employee_BGL

 select * from v_employee_BGL where employeesalary>50000

 insert v_employee_BGL values(1005,'ABC','Banglore',20000)
  insert v_employee_BGL values(1005,'ABC','mumbai',20000)



  create table t1
  (
  code int,
  name varchar(100)
  )

  create table t2
  (
  code int,
  city varchar(100)
  )
  insert t1 values(1,'A')
  insert t2 values(1,'BGl')
  select * from t1
  select * from t2

  create view v_data
  as
  select t1.code,t1.name,t2.city from t1 join t2 on t1.code=t2.code

  select*from v_data

  
  insert v_data values(3,'XYZ','pune')


create trigger trg_view
on v_data
instead of insert
as
begin 
declare @code int
declare @name varchar(100)
declare @city varchar(100)
select @code=code,@name=name,@city=city from inserted
insert t1 values (@code,@name)
insert t2 values(@code,@city)
end




create table tbl_employeeinfo
(
employeeid int identity(1,1),
employeename varchar(100),
employeecity varchar(100)
)

declare @c int=0;
while(@c<50000)
begin
insert tbl_employeeinfo values('ABCD','HYD');
set @c=@c+1;
end


select * from tbl_employeeinfo where employeeid=49999


create clustered index idx
on tbl_employeeinfo(employeeid)

select * from tbl_employees

begin tran tr1

insert tbl_employees values(10010,'abc','bgl',20000)

select * from tbl_employees

rollback tran
commit tran




select * from tbl_Customers

create proc sp_add_customer(@id int,@customername varchar(100),@customercity varchar(100),@customerdob datetime)
as
begin
insert tbl_Customers values(@id,@customername,@customercity,@customerdob)

end

declare @r int
exec @r=sp_add_customer 1006,'LKJH','Pune','10-11-1997'



alter proc sp_add_customer(@id int,@customername varchar(100),@customercity varchar(100))
as
update  tbl_Customers set customerName=@customername,CustomerCity=@customercity
 where CustomerID=@id

 declare @r int
 exec @r=sp_add_customer 1001,'smitha','pune'


 select * from tbl_customerinfo


 alter proc sp_add_customer (@id int,@mobileno varchar(100),@password varchar(100))
 as
 update tbl_customerinfo set customermobileno=@mobileno where customerid=@id and customerpassword=@password

 declare @r int
 exec @r=sp_add_customer 100,'99020030496','password1'

 select * from tbl_accountinfo

 alter proc sp_add_customer(@id int)
 as
 select tbl_customerinfo.customerid,tbl_customerinfo.customername,tbl_accountinfo.accountid,
 tbl_accountinfo.accountbalance from tbl_customerinfo join tbl_accountinfo 
 on tbl_customerinfo.customerid=tbl_accountinfo.customerid

 declare @r int
 exec sp_add_customer 100

 select * from tbl_transactioninfo

 create trigger trg_update_Balance
 on tbl_transactioninfo
 for insert
 as
 begin
 declare @accid int
 declare @amount int
 declare @tp varchar(100)
 select @accid=accountid,@amount=amount,@tp=transactiontype
 from inserted 
 if(@tp='withdraw')
 begin
 update tbl_accountinfo set accountbalance=accountbalance-@amount where
 accountid=@accid
 end

  update tbl_accountinfo set accountbalance=accountbalance+@amount where
 accountid=@accid
 end

 insert tbl_transactioninfo values(1001,'withdraw',45000,'11-01-2018')
 select * from tbl_accountinfo

 create view v_customer
 as
 select c.customerid,c.customername,a.accountid,a.accountbalance from
 tbl_customerinfo c join tbl_accountinfo a
 on c.customerid=a.customerid

 select * from v_customer

 alter view v_customer1
 with encryption
 as
 select * from tbl_accountinfo  where accountid=1007
 with check option
 select * from v_customer1

 select * from tbl_accountinfo
  select * from tbl_transactioninfo

  
  





