create database pathfrontdb2

use pathfrontdb2

 
create table tbl_customers
(
customerid int identity(1000,1)primary key,
customername varchar(100) not null,
customercity varchar(100) not null,
customeremail varchar(100) not null unique,
customermobileno varchar(15) not null unique
)

insert tbl_customers values('rahul','hyderbad','rahul123@gmail.com','9108842341')
insert tbl_customers values('lalith','chennai','lalith13@gmail.com','8105654489')
insert tbl_customers values( 'gopi','banglore','gopi@gmail.com','9591593554')
insert tbl_customers values('srikar','kolkata','srikar678@gmail.com','9902030496')
insert tbl_customers values('ram','chennai','ramsandeep2gmail.com','9901030587')

select * from tbl_customers

create table tbl_items
(
itemid int identity(1,1) primary key,
itemname varchar(100) not null,
itemprice int check(itemprice>0)
)

insert tbl_items values('books',1000)
insert tbl_items values('toys',2000)
insert tbl_items values('dress',5000)
insert tbl_items values('fruits',1500)
insert tbl_items values('vegetables',2500)

select * from tbl_items


create table tbl_invoices
(
invoiceid int identity(10000,1) primary key,
customerid int not null foreign key references tbl_customers(customerid),
invoicecity varchar(100) not null,
invoicedate datetime not null,
invoiceaddress varchar(100)
)

insert tbl_invoices values(1001,'pune',getdate(),'qwe')
insert tbl_invoices values(1004,'kolkata',getdate(),'asd')

select * from tbl_invoices

create table tbl_invoiceitems
(
invoiceid int not null foreign key references tbl_invoices(invoiceid),
itemid int not null foreign key references tbl_items(itemid),
itemqty int check(itemqty>0),
itemprice int check(itemprice>0),
primary key (invoiceid,itemid)
)

insert tbl_invoiceitems values(10001,4,5,1000)

select * from tbl_invoiceitems

select * from tbl_customers where customerid in (select customerid from tbl_invoices) 
select * from tbl_customers where customerid not in (select customerid  from tbl_invoices)

select * from tbl_items where itemid in(select itemid from tbl_invoiceitems)

select * from tbl_items where itemid not in (select itemid from tbl_invoiceitems)

select * from tbl_customers where customerid =(
select top 1 customerid  from tbl_invoices order by invoicedate desc )

create table tbl_employees
(
employeeid int identity(1,1) primary key,
employeename varchar(100)  not null,
employeesalary int not null,
employeedept varchar(100),
managerid int foreign key references tbl_employees(employeeid)
)

insert tbl_employees values('john',20000,'HR',null)
insert tbl_employees values('rosy',16000,'HR',1)
insert tbl_employees values('xyz',20000,'IT',null)
insert tbl_employees values('abc',13000,'IT',3)


select * from tbl_employees

select e.employeeid,e.employeename,e.employeesalary,e.managerid,m.employeename from tbl_employees e left outer join tbl_employees m
on
e.managerid=m.employeeid

select * from tbl_employees e1 where e1.employeesalary >
(select avg(e2.employeesalary) from tbl_employees e2
where e2.employeedept = e1.employeedept)

select top 1 * from tbl_employees where employeeid not in(
select top 1 with ties employeeid from tbl_employees order by employeesalary desc ) order by employeesalary desc

select top 1 * from tbl_employees where employeeid in(
select top 2 employeeid from tbl_employees order by employeesalary desc)
order by employeesalary asc

select * from tbl_employees 






select * from tbl_customers cross join tbl_invoices
select * from tbl_invoices

select tbl_customers.customerid,tbl_customers.customername,tbl_invoices.invoiceid,
tbl_invoices.invoicedate from tbl_customers full  join tbl_invoices
on 
tbl_customers.customerid=tbl_invoices.customerid


select tbl_invoices.invoiceid,tbl_invoices.customerid,tbl_invoices.invoicecity,
tbl_invoiceitems.itemid,tbl_invoiceitems.itemqty,tbl_items.itemname,tbl_customers.customername from tbl_invoices join tbl_invoiceitems
on
tbl_invoices.invoiceid=tbl_invoiceitems.invoiceid
join tbl_items
on
tbl_items.itemid=tbl_invoiceitems.itemid
join tbl_customers
on
tbl_customers.customerid=tbl_invoices.customerid





