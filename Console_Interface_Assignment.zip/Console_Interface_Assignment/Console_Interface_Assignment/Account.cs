﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Assignment
{
    class Account
    {
        public void GetEmployee(IAccountEmp IA)
        {
            int Sal = IA.GetEmployeeSalary();
            int AccNo = IA.GetEmployeeAccountNumber();
            int ID = IA.GetEmployeeID();
            Console.WriteLine("salary:" + Sal + " " + "AccountNo:" + AccNo + " " + "id:" + ID);
        }
    }
}
