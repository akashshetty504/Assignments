﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee e = new Employee(1234,"abc","udupi",20000,"xyz","asdfg",10,123456,"SBI",30);
            Account a = new Account();
            Manager m = new Manager();
            HR hr = new HR();
            a.GetEmployee(e);
            m.GetEmployee(e);
            hr.GetEmployee(e);

            Console.ReadLine();

        }
    }
}
