﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Assignment
{
    class HR
    {
        public void GetEmployee(IHREMP obj1)
        {
            string EAdd = obj1.GetEmployeeAddress();
            int ESal = obj1.GetEmployeeSalary();
            int EID = obj1.GetEmployeeID();
            Console.WriteLine("Address:" + " " + EAdd + " " + "Salary:" + ESal + " " + "ID: " + EID);

          

            
        }
    }
}
