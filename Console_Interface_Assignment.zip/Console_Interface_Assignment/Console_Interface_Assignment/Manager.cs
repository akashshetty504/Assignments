﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface_Assignment
{
    class Manager
    {

        public void GetEmployee(IManagerEmp IM)
        {
            int ID = IM.GetEmployeeID();
            int Exp = IM.GetEmployeeExp();
            string Project = IM.GetEmployeeProjectDetails();
            Console.WriteLine("id:" + ID + " " + "exp" + Exp + " " + "project:" + Project);
        }
    }
}
