﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Bank_System
{
    class Program
    {
        static void Main(string[] args)
        {
            bool flag = true;
            Console.WriteLine("accountid");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("customer name");
            string customername = Console.ReadLine();
            Console.WriteLine("customer address");
            string customeraddress = Console.ReadLine();
            Console.WriteLine("account type");
            string accounttype = Console.ReadLine();
            int balance=500;
           

            while (flag)
            {
                Console.WriteLine("deposit [1]");
                Console.WriteLine("withdraw [2]");
                Console.WriteLine("check balance [3]");
                Console.WriteLine("exit [4]");

                Console.WriteLine("press any no.");
                int opt = Convert.ToInt32(Console.ReadLine());

                switch (opt)
                {
                    case 1:Console.WriteLine("deposit");



                        int a = Convert.ToInt32(Console.ReadLine());
                        balance = balance + a;
                        Console.WriteLine("remain balance" + balance);
                        break;
                    case 2:
                        Console.WriteLine("withdraw");

                        int b = Convert.ToInt32(Console.ReadLine());
                        balance = balance - b;
                        Console.WriteLine("after withdraw balance" + balance);
                        break;
                    case 3:
                        Console.WriteLine(balance);
                        break;
                    case 4:
                        flag = false;
                        break;
                    default:
                        Console.WriteLine("entered wrong no.");
                        break;
                }

            }




            





        }
    }
}
