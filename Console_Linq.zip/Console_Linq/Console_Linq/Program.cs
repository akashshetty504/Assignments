﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1, CustomerAge = 25, CustomerCity = "BGL", CustomerName = "ABC" });
            custlist.Add(new Customer { CustomerID = 2, CustomerAge = 30, CustomerCity = "Pune", CustomerName = "Rahul" });
            custlist.Add(new Customer { CustomerID = 3, CustomerAge = 22, CustomerCity = "kolkata", CustomerName = "raju" });
            custlist.Add(new Customer { CustomerID = 4, CustomerAge = 35, CustomerCity = "Hyderbad", CustomerName = "ram" });
            custlist.Add(new Customer { CustomerID = 5, CustomerAge = 28, CustomerCity = "Delhi", CustomerName = "vinay" });


            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { OrederID = 1000, CustomerID = 1, ItemName = "one plus 6", ItemPrice = 40000 });
            ordlist.Add(new Order { OrederID = 1001, CustomerID = 1, ItemName = "books", ItemPrice = 1000 });
            ordlist.Add(new Order { OrederID = 1002, CustomerID = 3, ItemName = "fruits", ItemPrice = 1500 });
            ordlist.Add(new Order { OrederID = 1003, CustomerID = 2, ItemName = "toys", ItemPrice = 3000 });
            ordlist.Add(new Order { OrederID = 1004, CustomerID = 2, ItemName = "veg", ItemPrice = 1000 });

            string city = "BGL";
            var q = from c in custlist
                    where c.CustomerCity == city
                    orderby c.CustomerAge descending,c.CustomerName ascending
            select c;

            foreach(var x in q)
            {
                Console.WriteLine(x.CustomerID + " " + x.CustomerName + " " + x.CustomerCity + " " + x.CustomerAge);

            }

            var count=(from c in custlist
                      where c.CustomerCity==city
                      select c).Count();
            Console.WriteLine(count);

            var obj = (from c in custlist
                       where c.CustomerID == 2
                       select c).FirstOrDefault();

            if (obj != null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName);
            }
            else
            {
                Console.WriteLine("not found");
            }

            var qdata = from c in custlist
                        where c.CustomerAge > 20
                        select new { CID = c.CustomerID, CName = c.CustomerName, CCity = c.CustomerCity };

            foreach(var p in qdata)
            {
                Console.WriteLine(p.CCity + " " + p.CName + " " + p.CCity);
            }

            var joindata = from c in custlist
                           join o in ordlist on
        c.CustomerID equals o.CustomerID
                           select new { CID = c.CustomerID, CName = c.CustomerName, OID = o.OrederID, IName = o.ItemName, IPrice = o.ItemPrice };

            foreach(var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.OID + " " + j.IName
                    + " " + j.IPrice);
            }

            Console.ReadLine();

            
        } 
    }
}
