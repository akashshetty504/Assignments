﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment_Generic_Collection
{
    class Company
    {
        public void onLeave(int ID, string Reason)
         {
            Console.WriteLine("company class : employee on leave:" + ID + " ," + Reason);
        }

    private string CompanyAddress;
        private string CompanyName;

        public Company(string CompanyAddress,string CompanyName)
        {
            this.CompanyAddress =CompanyAddress;
            this.CompanyName = CompanyName;
        }
        private List<Employee> Employeelist = new List<Employee>();

        public void AddEmployee(Employee Em)
        {

            Employee.delleave d = new Employee.delleave(this.onLeave);
            Em.evtleave += d;
            Employeelist.Add(Em);
        }
        public Employee Search(int ID)
        {
            foreach (Employee e in Employeelist)
            {
                if (e.PEmployeeID == ID)
                {
                    return e;
                }
            }
            return null;
        }
        public bool Remove(int ID)
        {
            foreach (Employee e in Employeelist)
            {
                if (e.PEmployeeID == ID)
                {
                    Employeelist.Remove(e);
                    return true;
                }
            }
            return false;
        }

        public void ShowAll()
        {
            foreach(Employee e in Employeelist)
            {
                Console.WriteLine(e.PEmployeeID + " " + e.PEmployeeName + " " + e.PEmployeeCity);

            }
        }
        

        }

    }

