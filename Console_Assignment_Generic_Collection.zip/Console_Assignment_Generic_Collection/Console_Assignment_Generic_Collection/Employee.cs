﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment_Generic_Collection
{
    class Employee
    {
        public delegate void delleave(int ID, string Reason);
        public event delleave evtleave;




        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;

        private static int count = 1000;

        public Employee(string EmployeeName, string EmployeeCity)
        {
            Employee.count++;
            this.EmployeeID = Employee.count;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
        }
        public int PEmployeeID
        { get { return this.EmployeeID; } }
        public string PEmployeeName
        { get { return this.EmployeeName; } }
        public string PEmployeeCity
        { get { return this.EmployeeCity; } }

        public void TakeLeave(string Reason)
        {
            if (this.evtleave != null)
            {
                this.evtleave(this.EmployeeID, Reason);
            }
            Console.WriteLine("employee on leave :" + this.EmployeeID + ",Reason : " + Reason);

        }


        }
    }
