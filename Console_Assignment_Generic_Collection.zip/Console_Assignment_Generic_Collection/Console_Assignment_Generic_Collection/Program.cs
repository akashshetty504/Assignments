﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment_Generic_Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company("Banglore", "Wipro");
            bool flag = true;

            while(flag)
            {
                Console.WriteLine("enter the option : 1-Add,2-Search,3-Remove,4-ShowAll,5-Exit,6-Leave");
                int opt = Convert.ToInt32(Console.ReadLine());

                switch(opt)
                {
                    case 1:
                        Console.WriteLine("enter the employee name");
                        string Name = Console.ReadLine();
                        Console.WriteLine("enter the employee city");
                        string City = Console.ReadLine();
                        Employee e = new Employee(Name, City);
                        c.AddEmployee(e);
                        Console.WriteLine("employee added" + e.PEmployeeID);
                        break;
                    case 2:
                        Console.WriteLine("enter the employee id");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Employee obj = c.Search(ID);
                        if(obj!=null)
                        {
                            Console.WriteLine(obj.PEmployeeID + " " + obj.PEmployeeName);

                        }else
                        {
                            Console.WriteLine("employee not found");

                        }break;
                    case 3:
                        Console.WriteLine("enter the employee id");
                        int EID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(EID);
                        if(status)
                        {
                            Console.WriteLine("Employee removed");

                        }
                        else
                        {
                            Console.WriteLine("Employee not found");
                        }
                        break;
                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        Console.WriteLine("enter the employee ID");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Employee eobj = c.Search(id);
                        Console.WriteLine("enter the reason");
                        string Reason = Console.ReadLine();
                        eobj.TakeLeave(Reason);
                        break;
                        

                        
                    


                }

            }
        }
    }
}
