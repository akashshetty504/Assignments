﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Console_Mutex_Semaphore
{
    class Program
    {
        static void Main(string[] args)
        {
            bool status;
            Semaphore sm = new Semaphore(2, 2);
           // Mutex m = new Mutex(false, "XYZ", out status);
            Task t1 = Task.Run(() =>
            {
                //  m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("Task 1 started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 1 completed");
                //  m.ReleaseMutex();
                sm.Release();
            });

            Task t2 = Task.Run(() =>
            {
                //m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("Task 2 started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 2 completed");
                // m.ReleaseMutex();
                sm.Release();
            });

            Task t3 = Task.Run(() =>
            {
                //m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("Task 3 started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 3 completed");
                // m.ReleaseMutex();
                sm.Release();
            });

            Console.ReadLine();

        }
    }
}
