﻿namespace Wind_ADO
{
    partial class frm_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.txt_EmployeePassword = new System.Windows.Forms.TextBox();
            this.txt_EmployeeCity = new System.Windows.Forms.TextBox();
            this.txt_EmployeeName = new System.Windows.Forms.TextBox();
            this.lbl_EmployeePassword = new System.Windows.Forms.Label();
            this.lbl_EmployeeCity = new System.Windows.Forms.Label();
            this.lbl_EmployeeName = new System.Windows.Forms.Label();
            this.lbl_EmployeeID = new System.Windows.Forms.Label();
            this.lbl_EmployeeDOJ = new System.Windows.Forms.Label();
            this.txt_EmployeeID = new System.Windows.Forms.TextBox();
            this.txt_EmployeeDOJ = new System.Windows.Forms.TextBox();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(438, 417);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(75, 23);
            this.btn_Update.TabIndex = 15;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(263, 417);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(125, 23);
            this.btn_Find.TabIndex = 14;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // txt_EmployeePassword
            // 
            this.txt_EmployeePassword.Location = new System.Drawing.Point(389, 248);
            this.txt_EmployeePassword.Name = "txt_EmployeePassword";
            this.txt_EmployeePassword.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeePassword.TabIndex = 13;
            // 
            // txt_EmployeeCity
            // 
            this.txt_EmployeeCity.Location = new System.Drawing.Point(389, 160);
            this.txt_EmployeeCity.Name = "txt_EmployeeCity";
            this.txt_EmployeeCity.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeeCity.TabIndex = 12;
            // 
            // txt_EmployeeName
            // 
            this.txt_EmployeeName.Location = new System.Drawing.Point(389, 87);
            this.txt_EmployeeName.Name = "txt_EmployeeName";
            this.txt_EmployeeName.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeeName.TabIndex = 11;
            // 
            // lbl_EmployeePassword
            // 
            this.lbl_EmployeePassword.AutoSize = true;
            this.lbl_EmployeePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmployeePassword.Location = new System.Drawing.Point(154, 248);
            this.lbl_EmployeePassword.Name = "lbl_EmployeePassword";
            this.lbl_EmployeePassword.Size = new System.Drawing.Size(196, 25);
            this.lbl_EmployeePassword.TabIndex = 10;
            this.lbl_EmployeePassword.Text = "Employee Password:";
            // 
            // lbl_EmployeeCity
            // 
            this.lbl_EmployeeCity.AutoSize = true;
            this.lbl_EmployeeCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmployeeCity.Location = new System.Drawing.Point(206, 156);
            this.lbl_EmployeeCity.Name = "lbl_EmployeeCity";
            this.lbl_EmployeeCity.Size = new System.Drawing.Size(144, 25);
            this.lbl_EmployeeCity.TabIndex = 9;
            this.lbl_EmployeeCity.Text = "Employee City:";
            // 
            // lbl_EmployeeName
            // 
            this.lbl_EmployeeName.AutoSize = true;
            this.lbl_EmployeeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmployeeName.Location = new System.Drawing.Point(210, 74);
            this.lbl_EmployeeName.Name = "lbl_EmployeeName";
            this.lbl_EmployeeName.Size = new System.Drawing.Size(162, 25);
            this.lbl_EmployeeName.TabIndex = 8;
            this.lbl_EmployeeName.Text = "Employee Name:";
            // 
            // lbl_EmployeeID
            // 
            this.lbl_EmployeeID.AutoSize = true;
            this.lbl_EmployeeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmployeeID.Location = new System.Drawing.Point(210, 29);
            this.lbl_EmployeeID.Name = "lbl_EmployeeID";
            this.lbl_EmployeeID.Size = new System.Drawing.Size(154, 25);
            this.lbl_EmployeeID.TabIndex = 16;
            this.lbl_EmployeeID.Text = "lbl_EmployeeID:";
            // 
            // lbl_EmployeeDOJ
            // 
            this.lbl_EmployeeDOJ.AutoSize = true;
            this.lbl_EmployeeDOJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmployeeDOJ.Location = new System.Drawing.Point(199, 312);
            this.lbl_EmployeeDOJ.Name = "lbl_EmployeeDOJ";
            this.lbl_EmployeeDOJ.Size = new System.Drawing.Size(151, 25);
            this.lbl_EmployeeDOJ.TabIndex = 17;
            this.lbl_EmployeeDOJ.Text = "Employee DOJ:";
            // 
            // txt_EmployeeID
            // 
            this.txt_EmployeeID.Location = new System.Drawing.Point(389, 33);
            this.txt_EmployeeID.Name = "txt_EmployeeID";
            this.txt_EmployeeID.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeeID.TabIndex = 18;
            // 
            // txt_EmployeeDOJ
            // 
            this.txt_EmployeeDOJ.Location = new System.Drawing.Point(389, 312);
            this.txt_EmployeeDOJ.Name = "txt_EmployeeDOJ";
            this.txt_EmployeeDOJ.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeeDOJ.TabIndex = 19;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(608, 420);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 23);
            this.btn_Delete.TabIndex = 20;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // frm_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 471);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.txt_EmployeeDOJ);
            this.Controls.Add(this.txt_EmployeeID);
            this.Controls.Add(this.lbl_EmployeeDOJ);
            this.Controls.Add(this.lbl_EmployeeID);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.txt_EmployeePassword);
            this.Controls.Add(this.txt_EmployeeCity);
            this.Controls.Add(this.txt_EmployeeName);
            this.Controls.Add(this.lbl_EmployeePassword);
            this.Controls.Add(this.lbl_EmployeeCity);
            this.Controls.Add(this.lbl_EmployeeName);
            this.Name = "frm_form";
            this.Text = "frm_form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.TextBox txt_EmployeePassword;
        private System.Windows.Forms.TextBox txt_EmployeeCity;
        private System.Windows.Forms.TextBox txt_EmployeeName;
        private System.Windows.Forms.Label lbl_EmployeePassword;
        private System.Windows.Forms.Label lbl_EmployeeCity;
        private System.Windows.Forms.Label lbl_EmployeeName;
        private System.Windows.Forms.Label lbl_EmployeeID;
        private System.Windows.Forms.Label lbl_EmployeeDOJ;
        private System.Windows.Forms.TextBox txt_EmployeeID;
        private System.Windows.Forms.TextBox txt_EmployeeDOJ;
        private System.Windows.Forms.Button btn_Delete;
    }
}