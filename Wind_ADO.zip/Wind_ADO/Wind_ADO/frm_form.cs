﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wind_ADO
{
    public partial class frm_form : Form
    {
        public frm_form()
        {
            InitializeComponent();
        }

       // private void frm_form_Load(object sender, EventArgs e)
        //{

        //}

        private void btn_Find_Click(object sender, EventArgs e)
        {
            if(txt_EmployeeID.Text==string.Empty)
            {
                MessageBox.Show("Enter ID");

            }
            else
            {
                int ID = Convert.ToInt32(txt_EmployeeID.Text);
                EmployeeDAL dal = new EmployeeDAL();
                Employee emp = dal.Find(ID);
                if(emp!=null)
                {
                    txt_EmployeeName.Text = emp.EmployeeName;
                    txt_EmployeePassword.Text = emp.EmployeePassword;
                    txt_EmployeeCity.Text = emp.EmployeeCity;
                    txt_EmployeeDOJ.Text= emp.EmployeeDOj.ToString();
                    }
                else
                {
                    MessageBox.Show("not found");
                }



                }

            }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if(txt_EmployeeID.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if(txt_EmployeeCity.Text==string.Empty)
            {
                MessageBox.Show("enter city");

            }
            else if(txt_EmployeePassword.Text==string.Empty)
            {
                MessageBox.Show("enter password");

            }
            else
            {
                int ID = Convert.ToInt32(txt_EmployeeID.Text);
                string City = txt_EmployeeCity.Text;
                string Password = txt_EmployeePassword.Text;

                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.update(ID, City, Password);
                if(status)
                {
                    MessageBox.Show("updated");

                }else
                {
                    MessageBox.Show("not updated");
                }


        }

        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if(txt_EmployeeID.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_EmployeeID.Text);
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Delete(ID);
                if(status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }
    }
    }

