﻿namespace Wind_ADO
{
    partial class frm_ShowEmployees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_EmployeeCity = new System.Windows.Forms.Label();
            this.lbl_Search = new System.Windows.Forms.Label();
            this.txt_EmployeeCity = new System.Windows.Forms.TextBox();
            this.txt_Search = new System.Windows.Forms.TextBox();
            this.btn_Find = new System.Windows.Forms.Button();
            this.btn_SearchAll = new System.Windows.Forms.Button();
            this.dg_Employees = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Employees)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_EmployeeCity
            // 
            this.lbl_EmployeeCity.AutoSize = true;
            this.lbl_EmployeeCity.Location = new System.Drawing.Point(49, 34);
            this.lbl_EmployeeCity.Name = "lbl_EmployeeCity";
            this.lbl_EmployeeCity.Size = new System.Drawing.Size(97, 17);
            this.lbl_EmployeeCity.TabIndex = 0;
            this.lbl_EmployeeCity.Text = "Employee City";
            // 
            // lbl_Search
            // 
            this.lbl_Search.AutoSize = true;
            this.lbl_Search.Location = new System.Drawing.Point(46, 97);
            this.lbl_Search.Name = "lbl_Search";
            this.lbl_Search.Size = new System.Drawing.Size(53, 17);
            this.lbl_Search.TabIndex = 1;
            this.lbl_Search.Text = "Search";
            // 
            // txt_EmployeeCity
            // 
            this.txt_EmployeeCity.Location = new System.Drawing.Point(212, 33);
            this.txt_EmployeeCity.Name = "txt_EmployeeCity";
            this.txt_EmployeeCity.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeeCity.TabIndex = 2;
            // 
            // txt_Search
            // 
            this.txt_Search.Location = new System.Drawing.Point(214, 101);
            this.txt_Search.Name = "txt_Search";
            this.txt_Search.Size = new System.Drawing.Size(100, 22);
            this.txt_Search.TabIndex = 3;
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(361, 43);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 23);
            this.btn_Find.TabIndex = 4;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // btn_SearchAll
            // 
            this.btn_SearchAll.Location = new System.Drawing.Point(366, 109);
            this.btn_SearchAll.Name = "btn_SearchAll";
            this.btn_SearchAll.Size = new System.Drawing.Size(121, 23);
            this.btn_SearchAll.TabIndex = 5;
            this.btn_SearchAll.Text = "Search(All)";
            this.btn_SearchAll.UseVisualStyleBackColor = true;
            this.btn_SearchAll.Click += new System.EventHandler(this.btn_SearchAll_Click);
            // 
            // dg_Employees
            // 
            this.dg_Employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Employees.Location = new System.Drawing.Point(29, 184);
            this.dg_Employees.Name = "dg_Employees";
            this.dg_Employees.RowTemplate.Height = 24;
            this.dg_Employees.Size = new System.Drawing.Size(779, 305);
            this.dg_Employees.TabIndex = 6;
            // 
            // frm_ShowEmployees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 501);
            this.Controls.Add(this.dg_Employees);
            this.Controls.Add(this.btn_SearchAll);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.txt_Search);
            this.Controls.Add(this.txt_EmployeeCity);
            this.Controls.Add(this.lbl_Search);
            this.Controls.Add(this.lbl_EmployeeCity);
            this.Name = "frm_ShowEmployees";
            this.Text = "frm_ShowEmployees";
            ((System.ComponentModel.ISupportInitialize)(this.dg_Employees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_EmployeeCity;
        private System.Windows.Forms.Label lbl_Search;
        private System.Windows.Forms.TextBox txt_EmployeeCity;
        private System.Windows.Forms.TextBox txt_Search;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Button btn_SearchAll;
        private System.Windows.Forms.DataGridView dg_Employees;
    }
}