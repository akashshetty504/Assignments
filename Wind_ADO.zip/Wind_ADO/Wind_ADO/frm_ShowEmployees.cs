﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wind_ADO
{
    public partial class frm_ShowEmployees : Form
    {
        public frm_ShowEmployees()
        {
            InitializeComponent();
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string City = txt_EmployeeCity.Text;
            List<Employee> list = dal.ShowEmployees(City);
            dg_Employees.DataSource = list;


        }

        private void btn_SearchAll_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string key = txt_Search.Text;
            List<Employee> list = dal.SearchEmployees(key);
            dg_Employees.DataSource = list; 
        }
    }
}
