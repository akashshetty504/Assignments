﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wind_ADO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            txt_EmployeeName.Text = string.Empty;
            txt_EmployeeCity.Text = string.Empty;
            txt_EmployeePassword.Text = string.Empty;

        }

        private void btn_NewEmployee_Click(object sender, EventArgs e)
        {
            if(txt_EmployeeName.Text==string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if(txt_EmployeeCity.Text==string.Empty)
            {
                MessageBox.Show("enter city");

            }
            else if(txt_EmployeePassword.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                string Name = txt_EmployeeName.Text;
                string City = txt_EmployeeCity.Text;
                string Password = txt_EmployeePassword.Text;
                Employee obj = new Employee();
                obj.EmployeeName = Name;
                obj.EmployeeCity = City;
                obj.EmployeePassword = Password;

                EmployeeDAL dal = new EmployeeDAL();
                int id = dal.AddEmployee(obj);
                MessageBox.Show("employee added:" + id);

            }
        }
    }
}
