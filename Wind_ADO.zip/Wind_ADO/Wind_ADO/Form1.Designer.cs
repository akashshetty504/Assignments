﻿namespace Wind_ADO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_EmployeeName = new System.Windows.Forms.Label();
            this.lbl_EmployeeCity = new System.Windows.Forms.Label();
            this.lbl_EmployeePassword = new System.Windows.Forms.Label();
            this.txt_EmployeeName = new System.Windows.Forms.TextBox();
            this.txt_EmployeeCity = new System.Windows.Forms.TextBox();
            this.txt_EmployeePassword = new System.Windows.Forms.TextBox();
            this.btn_NewEmployee = new System.Windows.Forms.Button();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_EmployeeName
            // 
            this.lbl_EmployeeName.AutoSize = true;
            this.lbl_EmployeeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmployeeName.Location = new System.Drawing.Point(94, 39);
            this.lbl_EmployeeName.Name = "lbl_EmployeeName";
            this.lbl_EmployeeName.Size = new System.Drawing.Size(162, 25);
            this.lbl_EmployeeName.TabIndex = 0;
            this.lbl_EmployeeName.Text = "Employee Name:";
            // 
            // lbl_EmployeeCity
            // 
            this.lbl_EmployeeCity.AutoSize = true;
            this.lbl_EmployeeCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmployeeCity.Location = new System.Drawing.Point(90, 121);
            this.lbl_EmployeeCity.Name = "lbl_EmployeeCity";
            this.lbl_EmployeeCity.Size = new System.Drawing.Size(144, 25);
            this.lbl_EmployeeCity.TabIndex = 1;
            this.lbl_EmployeeCity.Text = "Employee City:";
            // 
            // lbl_EmployeePassword
            // 
            this.lbl_EmployeePassword.AutoSize = true;
            this.lbl_EmployeePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmployeePassword.Location = new System.Drawing.Point(38, 213);
            this.lbl_EmployeePassword.Name = "lbl_EmployeePassword";
            this.lbl_EmployeePassword.Size = new System.Drawing.Size(196, 25);
            this.lbl_EmployeePassword.TabIndex = 2;
            this.lbl_EmployeePassword.Text = "Employee Password:";
            // 
            // txt_EmployeeName
            // 
            this.txt_EmployeeName.Location = new System.Drawing.Point(261, 45);
            this.txt_EmployeeName.Name = "txt_EmployeeName";
            this.txt_EmployeeName.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeeName.TabIndex = 3;
            // 
            // txt_EmployeeCity
            // 
            this.txt_EmployeeCity.Location = new System.Drawing.Point(257, 124);
            this.txt_EmployeeCity.Name = "txt_EmployeeCity";
            this.txt_EmployeeCity.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeeCity.TabIndex = 4;
            // 
            // txt_EmployeePassword
            // 
            this.txt_EmployeePassword.Location = new System.Drawing.Point(260, 213);
            this.txt_EmployeePassword.Name = "txt_EmployeePassword";
            this.txt_EmployeePassword.Size = new System.Drawing.Size(100, 22);
            this.txt_EmployeePassword.TabIndex = 5;
            // 
            // btn_NewEmployee
            // 
            this.btn_NewEmployee.Location = new System.Drawing.Point(155, 339);
            this.btn_NewEmployee.Name = "btn_NewEmployee";
            this.btn_NewEmployee.Size = new System.Drawing.Size(125, 23);
            this.btn_NewEmployee.TabIndex = 6;
            this.btn_NewEmployee.Text = "New Employee";
            this.btn_NewEmployee.UseVisualStyleBackColor = true;
            this.btn_NewEmployee.Click += new System.EventHandler(this.btn_NewEmployee_Click);
            // 
            // btn_Reset
            // 
            this.btn_Reset.Location = new System.Drawing.Point(388, 330);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(75, 23);
            this.btn_Reset.TabIndex = 7;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 436);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn_NewEmployee);
            this.Controls.Add(this.txt_EmployeePassword);
            this.Controls.Add(this.txt_EmployeeCity);
            this.Controls.Add(this.txt_EmployeeName);
            this.Controls.Add(this.lbl_EmployeePassword);
            this.Controls.Add(this.lbl_EmployeeCity);
            this.Controls.Add(this.lbl_EmployeeName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_EmployeeName;
        private System.Windows.Forms.Label lbl_EmployeeCity;
        private System.Windows.Forms.Label lbl_EmployeePassword;
        private System.Windows.Forms.TextBox txt_EmployeeName;
        private System.Windows.Forms.TextBox txt_EmployeeCity;
        private System.Windows.Forms.TextBox txt_EmployeePassword;
        private System.Windows.Forms.Button btn_NewEmployee;
        private System.Windows.Forms.Button btn_Reset;
    }
}

