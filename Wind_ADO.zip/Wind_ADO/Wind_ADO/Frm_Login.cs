﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wind_ADO
{
    public partial class Frm_Login : Form
    {
        public Frm_Login()
        {
            InitializeComponent();
        }

        private void lbl_LoginID_Click(object sender, EventArgs e)
        {

        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_LoginID.Text);
            string Password = txt_Password.Text;
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Login(ID, Password);
                if (status)
                {
                    MessageBox.Show("valid user");
                }
                else
                {
                    MessageBox.Show("invalid user");
                }
            }
            catch(System.Data.SqlClient.SqlException exp)
            {
                MessageBox.Show("Sql error");
            }
            catch(Exception exp)
            {
                MessageBox.Show("try again");
            }
            finally
            {
                MessageBox.Show("finally block");
            }
        }

        private void btn_LoginSqlInjection_Click(object sender, EventArgs e)
        {
            string ID = txt_LoginID.Text;
            string Password = txt_Password.Text;
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.LoginSqlInjection(ID, Password);
            if(status)
            {
                MessageBox.Show("Valid user");
            }
            else
            {
                MessageBox.Show("invalid user");
            }

        }
    }
}
