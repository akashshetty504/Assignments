﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;//DLL ref

namespace Wind_ADO
{
    class EmployeeDAL1
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddEmployee(Employee emp)
        {
            SqlCommand com_emp_insert = new SqlCommand
                ("insert tbl_employee values(@name,@city,@password,getdate())", con);
            com_emp_insert.Parameters.AddWithValue("@name", emp.EmployeeName);
            com_emp_insert.Parameters.AddWithValue("@city", emp.EmployeeCity);
            com_emp_insert.Parameters.AddWithValue("@password", emp.EmployeePassword);
            con.Open();
            com_emp_insert.ExecuteNonQuery();

            SqlCommand com_id = new SqlCommand("Select @@identity", con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;


        }
        public Employee Find(int ID)
        {
            SqlCommand com_find = new SqlCommand
            ("select * from tbl_employee where employeeid=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                Employee e = new Employee();
                e.EmployeeID = dr.GetInt32(0);
                e.EmployeeName = dr.GetString(1);
                e.EmployeeCity = dr.GetString(2);
                e.EmployeePassword = dr.GetString(3);
                e.EmployeeDOj = dr.GetDateTime(4);
                con.Close();
                return e;
            }
            else
            {
                return null;
            }
            }

        public bool update(int ID, string City, string Password)
        {
            SqlCommand com_update = new SqlCommand
                ("update tbl_employee set EmployeeCity=@city,EmployeePassword=@password where EmployeeID=@id", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@city", City);
            com_update.Parameters.AddWithValue("@password", Password);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }





        
        
            
        }

        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand
         ("delete tbl_Employee where EmployeeID=@id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if(count>0)
            {
                return true;

            }
            else
            {
                return false;
            }

        }

        public List<Employee> ShowEmployees(string City)
        {
            SqlCommand com_Employees = new SqlCommand("select * from tbl_Employee where EmployeeCity=@city", con);
            com_Employees.Parameters.AddWithValue("@city", City);
            con.Open();
            SqlDataReader dr = com_Employees.ExecuteReader();

            List<Employee> emplist = new List<Employee>();
            while (dr.Read())
            {
                Employee obj = new Employee();
                obj.EmployeeID = dr.GetInt32(0);
                obj.EmployeeName = dr.GetString(1);
                obj.EmployeeCity = dr.GetString(2);
                obj.EmployeePassword = dr.GetString(3);
                obj.EmployeeDOj = dr.GetDateTime(4);

                emplist.Add(obj);
            }
            con.Close();
            return emplist;

        }

        public List<Employee> SearchEmployees(string Search)
        {
            SqlCommand com_Search=new SqlCommand
                ("select * from tbl_Employee where EmployeeID like '%"+Search+"%' or EmployeeName like '%"+Search+"%' or EmployeeCity like '%"+Search+"%'",con);
            con.Open();
            SqlDataReader dr = com_Search.ExecuteReader();
            List<Employee> emplist = new List<Employee>();
            while(dr.Read())
            {
                Employee emp = new Employee();
                emp.EmployeeID = dr.GetInt32(0);
                emp.EmployeeName = dr.GetString(1);
                emp.EmployeeCity = dr.GetString(2);
                emp.EmployeePassword = dr.GetString(3);
                emp.EmployeeDOj = dr.GetDateTime(4);

                emplist.Add(emp);


            }
            con.Close();
            return emplist;
        }

        public bool Login(int ID,String Password)
        {
            SqlCommand com_Login = new SqlCommand("select count(*) from tbl_Employee where EmployeeID=@id and EmployeePassword=@password", con);
            com_Login.Parameters.AddWithValue("@id", ID);
            com_Login.Parameters.AddWithValue("@password", Password);
            con.Open();
            int count = Convert.ToInt32(com_Login.ExecuteScalar());
            con.Close();
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public bool LoginSqlInjection(string ID, string Password)
        {
            SqlCommand com_Login = new SqlCommand("select count(*) from tbl_Employee where EmployeeID='"+ID+"' and EmployeePassword='"+Password+"'", con);
            con.Open();
            int count = Convert.ToInt32(com_Login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
