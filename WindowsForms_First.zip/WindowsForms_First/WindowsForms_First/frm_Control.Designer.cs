﻿namespace WindowsForms_First
{
    partial class frm_Control
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_Cities = new System.Windows.Forms.ListBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.cmb_Cities = new System.Windows.Forms.ComboBox();
            this.chk_Readme = new System.Windows.Forms.CheckBox();
            this.rdb_Male = new System.Windows.Forms.RadioButton();
            this.rdb_Female = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lst_Cities
            // 
            this.lst_Cities.FormattingEnabled = true;
            this.lst_Cities.ItemHeight = 16;
            this.lst_Cities.Location = new System.Drawing.Point(34, 49);
            this.lst_Cities.Name = "lst_Cities";
            this.lst_Cities.Size = new System.Drawing.Size(120, 84);
            this.lst_Cities.TabIndex = 0;
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(238, 46);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(107, 47);
            this.btn_Save.TabIndex = 1;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // cmb_Cities
            // 
            this.cmb_Cities.FormattingEnabled = true;
            this.cmb_Cities.Location = new System.Drawing.Point(75, 200);
            this.cmb_Cities.Name = "cmb_Cities";
            this.cmb_Cities.Size = new System.Drawing.Size(121, 24);
            this.cmb_Cities.TabIndex = 2;
            // 
            // chk_Readme
            // 
            this.chk_Readme.AutoSize = true;
            this.chk_Readme.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Readme.Location = new System.Drawing.Point(239, 150);
            this.chk_Readme.Name = "chk_Readme";
            this.chk_Readme.Size = new System.Drawing.Size(144, 36);
            this.chk_Readme.TabIndex = 3;
            this.chk_Readme.Text = "Readme";
            this.chk_Readme.UseVisualStyleBackColor = true;
            // 
            // rdb_Male
            // 
            this.rdb_Male.AutoSize = true;
            this.rdb_Male.Location = new System.Drawing.Point(246, 215);
            this.rdb_Male.Name = "rdb_Male";
            this.rdb_Male.Size = new System.Drawing.Size(59, 21);
            this.rdb_Male.TabIndex = 4;
            this.rdb_Male.TabStop = true;
            this.rdb_Male.Text = "Male";
            this.rdb_Male.UseVisualStyleBackColor = true;
            // 
            // rdb_Female
            // 
            this.rdb_Female.AutoSize = true;
            this.rdb_Female.Location = new System.Drawing.Point(242, 264);
            this.rdb_Female.Name = "rdb_Female";
            this.rdb_Female.Size = new System.Drawing.Size(75, 21);
            this.rdb_Female.TabIndex = 5;
            this.rdb_Female.TabStop = true;
            this.rdb_Female.Text = "Female";
            this.rdb_Female.UseVisualStyleBackColor = true;
            // 
            // frm_Control
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 367);
            this.Controls.Add(this.rdb_Female);
            this.Controls.Add(this.rdb_Male);
            this.Controls.Add(this.chk_Readme);
            this.Controls.Add(this.cmb_Cities);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.lst_Cities);
            this.Name = "frm_Control";
            this.Text = "frm_Control";
            this.Load += new System.EventHandler(this.frm_Control_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_Cities;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.ComboBox cmb_Cities;
        private System.Windows.Forms.CheckBox chk_Readme;
        private System.Windows.Forms.RadioButton rdb_Male;
        private System.Windows.Forms.RadioButton rdb_Female;
    }
}