﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_First
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        private void btn_Login_Click(object sender, EventArgs e)
        {
          if ( txt_LoginID.Text==string.Empty)
            {
                MessageBox.Show("Enter Login ID");
            }
          else if(txt_Password.Text==string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                string LoginID = txt_LoginID.Text;
                string Password = txt_Password.Text;
                if(LoginID=="admin@gmail.com"&& Password=="Pass@123")
                {
                    MessageBox.Show("Valid User");
                    frm_sum obj = new frm_sum();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("Invalid user");
                }
            }
        }
    }
}
