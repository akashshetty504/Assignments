﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_First
{
    public partial class frm_Control : Form
    {
        public frm_Control()
        {
            InitializeComponent();
        }

        private void frm_Control_Load(object sender, EventArgs e)
        {
            lst_Cities.Items.Add("Pune");
            lst_Cities.Items.Add("Chennai");
            lst_Cities.Items.Add("Hyd");

            cmb_Cities.Items.Add("Pune");
            cmb_Cities.Items.Add("Chennai");
            cmb_Cities.Items.Add("Hyd");
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if(rdb_Male.Checked==false && rdb_Female.Checked==false)
            {
                MessageBox.Show("Select your Gender");
            }
            else
            {
                string Gender = string.Empty;
                if (rdb_Male.Checked)
                {
                    Gender = "Male";
                }
                else
                {
                    Gender = "Female";
                }
                MessageBox.Show(Gender);
            }







            bool status = chk_Readme.Checked;
            if(status)
            {
                MessageBox.Show("it is checked");
            }
            else
            {
                MessageBox.Show("it is not checked");
            }
            if(lst_Cities.Text==string.Empty)
            {
                MessageBox.Show("select a City");

            }
            else
            {
                string City = lst_Cities.Text;
                MessageBox.Show(City);
            }

        }
    }
}
