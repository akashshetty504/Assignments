create table tbl_Students
(
StudentID int identity(1000,1)primary key,
StudentName varchar(100),
StudenytCity varchar(100),
StudentAddress varchar(100),
StudentEmailID varchar(100)
)
 select * from tbl_Students
