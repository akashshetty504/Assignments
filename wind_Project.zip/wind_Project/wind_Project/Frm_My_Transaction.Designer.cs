﻿namespace wind_Project
{
    partial class Frm_My_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_AccountID = new System.Windows.Forms.Label();
            this.grd_Transaction = new System.Windows.Forms.DataGridView();
            this.btn_Show = new System.Windows.Forms.Button();
            this.cmd_AccountID = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.grd_Transaction)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_AccountID
            // 
            this.lbl_AccountID.AutoSize = true;
            this.lbl_AccountID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AccountID.Location = new System.Drawing.Point(159, 117);
            this.lbl_AccountID.Name = "lbl_AccountID";
            this.lbl_AccountID.Size = new System.Drawing.Size(127, 29);
            this.lbl_AccountID.TabIndex = 5;
            this.lbl_AccountID.Text = "Account ID";
            // 
            // grd_Transaction
            // 
            this.grd_Transaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd_Transaction.Location = new System.Drawing.Point(63, 295);
            this.grd_Transaction.Name = "grd_Transaction";
            this.grd_Transaction.RowTemplate.Height = 24;
            this.grd_Transaction.Size = new System.Drawing.Size(548, 194);
            this.grd_Transaction.TabIndex = 8;
            // 
            // btn_Show
            // 
            this.btn_Show.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Show.Location = new System.Drawing.Point(217, 212);
            this.btn_Show.Name = "btn_Show";
            this.btn_Show.Size = new System.Drawing.Size(121, 43);
            this.btn_Show.TabIndex = 7;
            this.btn_Show.Text = "Show";
            this.btn_Show.UseVisualStyleBackColor = true;
            this.btn_Show.Click += new System.EventHandler(this.btn_Show_Click);
            // 
            // cmd_AccountID
            // 
            this.cmd_AccountID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd_AccountID.FormattingEnabled = true;
            this.cmd_AccountID.Location = new System.Drawing.Point(331, 109);
            this.cmd_AccountID.Name = "cmd_AccountID";
            this.cmd_AccountID.Size = new System.Drawing.Size(121, 37);
            this.cmd_AccountID.TabIndex = 9;
            // 
            // Frm_My_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(674, 501);
            this.Controls.Add(this.cmd_AccountID);
            this.Controls.Add(this.grd_Transaction);
            this.Controls.Add(this.btn_Show);
            this.Controls.Add(this.lbl_AccountID);
            this.Name = "Frm_My_Transaction";
            this.Text = "Frm_My_Transaction";
            this.Load += new System.EventHandler(this.Frm_My_Transaction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grd_Transaction)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_AccountID;
        private System.Windows.Forms.DataGridView grd_Transaction;
        private System.Windows.Forms.Button btn_Show;
        private System.Windows.Forms.ComboBox cmd_AccountID;
    }
}