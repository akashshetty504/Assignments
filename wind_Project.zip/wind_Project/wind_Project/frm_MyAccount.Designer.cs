﻿namespace wind_Project
{
    partial class frm_MyAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CID = new System.Windows.Forms.Label();
            this.btn_Show = new System.Windows.Forms.Button();
            this.txt_CID = new System.Windows.Forms.TextBox();
            this.grd_Account = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.grd_Account)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_CID
            // 
            this.lbl_CID.AutoSize = true;
            this.lbl_CID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CID.Location = new System.Drawing.Point(12, 62);
            this.lbl_CID.Name = "lbl_CID";
            this.lbl_CID.Size = new System.Drawing.Size(140, 29);
            this.lbl_CID.TabIndex = 0;
            this.lbl_CID.Text = "CustomerID";
            // 
            // btn_Show
            // 
            this.btn_Show.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Show.Location = new System.Drawing.Point(111, 160);
            this.btn_Show.Name = "btn_Show";
            this.btn_Show.Size = new System.Drawing.Size(160, 45);
            this.btn_Show.TabIndex = 1;
            this.btn_Show.Text = "Show";
            this.btn_Show.UseVisualStyleBackColor = true;
            this.btn_Show.Click += new System.EventHandler(this.btn_Show_Click);
            // 
            // txt_CID
            // 
            this.txt_CID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CID.Location = new System.Drawing.Point(182, 62);
            this.txt_CID.Name = "txt_CID";
            this.txt_CID.Size = new System.Drawing.Size(100, 34);
            this.txt_CID.TabIndex = 2;
            // 
            // grd_Account
            // 
            this.grd_Account.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd_Account.Location = new System.Drawing.Point(12, 246);
            this.grd_Account.Name = "grd_Account";
            this.grd_Account.RowTemplate.Height = 24;
            this.grd_Account.Size = new System.Drawing.Size(548, 219);
            this.grd_Account.TabIndex = 3;
            // 
            // frm_MyAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(625, 530);
            this.Controls.Add(this.grd_Account);
            this.Controls.Add(this.txt_CID);
            this.Controls.Add(this.btn_Show);
            this.Controls.Add(this.lbl_CID);
            this.Name = "frm_MyAccount";
            this.Text = "frm_MyAccount";
            this.Load += new System.EventHandler(this.frm_MyAccount_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grd_Account)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CID;
        private System.Windows.Forms.Button btn_Show;
        private System.Windows.Forms.TextBox txt_CID;
        private System.Windows.Forms.DataGridView grd_Account;
    }
}