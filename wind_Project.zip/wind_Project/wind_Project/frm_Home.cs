﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wind_Project
{
    public partial class frm_Home : Form
    {
        public frm_Home()
        {
            InitializeComponent();
        }

        private void btn_NewAccount_Click(object sender, EventArgs e)
        {
            frm_Account b = new frm_Account();
            b.Show();
        }

        private void btn_MyAccount_Click(object sender, EventArgs e)
        {
            frm_MyAccount c = new frm_MyAccount();
            c.Show();
        }

        private void btn_NewTransaction_Click(object sender, EventArgs e)
        {
            frm_New_Transaction d = new frm_New_Transaction();
            d.Show();
        }

        private void btn_MyTransaction_Click(object sender, EventArgs e)
        {
            Frm_My_Transaction n = new Frm_My_Transaction();
            n.Show();
        }

        private void frm_Home_Load(object sender, EventArgs e)
        {

        }
    }
}
