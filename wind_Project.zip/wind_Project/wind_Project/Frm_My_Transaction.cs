﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wind_Project
{
    public partial class Frm_My_Transaction : Form
    {
        public Frm_My_Transaction()
        {
            InitializeComponent();
        }

        private void btn_Show_Click(object sender, EventArgs e)
        {
            if (cmd_AccountID.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(cmd_AccountID.Text);
                CustomerDAL dal = new CustomerDAL();

                List<Transactions> list = dal.mytransaction(id);
                grd_Transaction.DataSource = list;

            }
        }

        private void Frm_My_Transaction_Load(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            List<int> List = dal.AccountID(Test.CustomerID);
            foreach (var m in List)
            {
                cmd_AccountID.Items.Add(m);
            }
        }
    }
}
