﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace wind_Project
{
    class CustomerDAL
    {

        SqlConnection con = new SqlConnection
           (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddCustomers(Customers cus)
        {
            
            
                SqlCommand com_cus_insert = new SqlCommand
                    ("proc_addCustomer", con);
                com_cus_insert.Parameters.AddWithValue("@name", cus.CustomerName);
                com_cus_insert.Parameters.AddWithValue("@email", cus.CustomerEmail);
                com_cus_insert.Parameters.AddWithValue("@mobileno", cus.CustomerMobileNo);
                com_cus_insert.Parameters.AddWithValue("@gender", cus.CustomerGender);
                com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);

                com_cus_insert.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_cus_insert.Parameters.Add(retdata);

                con.Open();


                com_cus_insert.ExecuteNonQuery();
                con.Close();






                int ID = Convert.ToInt32(retdata.Value);
                return ID;
            }
           
        


        
        public bool Login(int ID, String Password)
        {
            SqlCommand com_Login = new SqlCommand("select * from tbl_Customers where CustomerID=@id", con);
            com_Login.Parameters.AddWithValue("@id", ID);
            com_Login.Parameters.AddWithValue("@password", Password);
            con.Open();
            int count = Convert.ToInt32(com_Login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;
            } 
            else
            {
                return false;
            }
        }

        public int AddAccounts(Accounts ac)
        {
            SqlCommand com_acc_insert = new SqlCommand
                ("proc_addAccount", con);
            com_acc_insert.Parameters.AddWithValue("@id", ac.CustomerID);
            com_acc_insert.Parameters.AddWithValue("@balance", ac.AccountBalance);
            com_acc_insert.Parameters.AddWithValue("@acctype", ac.AccountType);


            com_acc_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_acc_insert.Parameters.Add(retdata);

            con.Open();
            
            com_acc_insert.ExecuteNonQuery();
            con.Close();

            int ID = Convert.ToInt32(retdata.Value);
           

            return ID;



        }

        public List<Accounts> myaccount(int id)
        {
            SqlCommand my_acc = new SqlCommand("proc_my_account", con);
            my_acc.Parameters.AddWithValue("@id", id);
            my_acc.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();

            retdata.Direction = ParameterDirection.ReturnValue;
            my_acc.Parameters.Add(retdata);
            con.Open();

            SqlDataReader dr = my_acc.ExecuteReader();
            List<Accounts> acclist = new List<Accounts>();
            if (dr.Read())
            {
                Accounts ac = new Accounts();
                ac.AccountID = dr.GetInt32(0);
                ac.CustomerID = dr.GetInt32(1);
                ac.AccountBalance = dr.GetInt32(2);
                ac.AccountType = dr.GetString(3);

                acclist.Add(ac);
                con.Close();
                return acclist;
            }

            else
            {
                return null;
            }


        }

        public int NewTransaction(Transactions tr)
        {
            SqlCommand new_trans = new SqlCommand("proc_addtransaction", con);
            new_trans.Parameters.AddWithValue("@AccountID", tr.AccountID);
            new_trans.Parameters.AddWithValue("@amount", tr.Amount);
            new_trans.Parameters.AddWithValue("@type", tr.TransactionType);
            new_trans.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            new_trans.Parameters.Add(retdata);
            con.Open();
            new_trans.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;
        }





        public List<Transactions> mytransaction(int id)
        {
            SqlCommand my_trans = new SqlCommand("proc_my_Transaction", con);
            my_trans.Parameters.AddWithValue("@id", id);
            my_trans.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            my_trans.Parameters.Add(retdata);
            con.Open();
            SqlDataReader dr = my_trans.ExecuteReader();
            List<Transactions> translist = new List<Transactions>();
            if(dr.Read())
            {
                Transactions t = new Transactions();
                t.TransactionID = dr.GetInt32(0);
                t.AccountID = dr.GetInt32(1);
                t.Amount = dr.GetInt32(2);
                t.TransactionType = dr.GetString(3);
                t.TransactionDate = dr.GetDateTime(4);
                translist.Add(t);
                con.Close();
                return translist;
                
            }
            else
            {
                return null;
            }



        }

        public List<int>AccountID(int ID)
        {
            SqlCommand AID = new SqlCommand("proc_account_per", con);
            AID.Parameters.AddWithValue("@cid", ID);
            AID.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = AID.ExecuteReader();
            List<int> list_AID = new List<int>();
            while (dr.Read())
            {
                list_AID.Add(dr.GetInt32(0));

            }
            con.Close();
            return list_AID;

        }



    }


}









