﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wind_Project
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {

            int ID = Convert.ToInt32(txt_LoginID.Text);
            string Password = txt_Password.Text;


            CustomerDAL dal = new CustomerDAL();
            bool status = dal.Login(ID, Password);
            if (status)
            {
                MessageBox.Show("valid user");

                Test.CustomerID = Convert.ToInt32(txt_LoginID.Text);
                frm_Home a = new frm_Home();
                a.Show();
            }
            else
            {
                MessageBox.Show("invalid user");
            }
        }




        private void btn_NewRegistration_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            a.Show();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }



    }
    }