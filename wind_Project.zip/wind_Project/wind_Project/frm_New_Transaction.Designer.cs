﻿namespace wind_Project
{
    partial class frm_New_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_AccountID = new System.Windows.Forms.Label();
            this.lbl_Amount = new System.Windows.Forms.Label();
            this.lbl_Type = new System.Windows.Forms.Label();
            this.btn_Transaction = new System.Windows.Forms.Button();
            this.txt_Amount = new System.Windows.Forms.TextBox();
            this.txt_Type = new System.Windows.Forms.TextBox();
            this.cmb_AccountID = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_AccountID
            // 
            this.lbl_AccountID.AutoSize = true;
            this.lbl_AccountID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AccountID.Location = new System.Drawing.Point(76, 55);
            this.lbl_AccountID.Name = "lbl_AccountID";
            this.lbl_AccountID.Size = new System.Drawing.Size(127, 29);
            this.lbl_AccountID.TabIndex = 0;
            this.lbl_AccountID.Text = "Account ID";
            // 
            // lbl_Amount
            // 
            this.lbl_Amount.AutoSize = true;
            this.lbl_Amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Amount.Location = new System.Drawing.Point(91, 142);
            this.lbl_Amount.Name = "lbl_Amount";
            this.lbl_Amount.Size = new System.Drawing.Size(94, 29);
            this.lbl_Amount.TabIndex = 1;
            this.lbl_Amount.Text = "Amount";
            // 
            // lbl_Type
            // 
            this.lbl_Type.AutoSize = true;
            this.lbl_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Type.Location = new System.Drawing.Point(117, 230);
            this.lbl_Type.Name = "lbl_Type";
            this.lbl_Type.Size = new System.Drawing.Size(68, 29);
            this.lbl_Type.TabIndex = 2;
            this.lbl_Type.Text = "Type";
            // 
            // btn_Transaction
            // 
            this.btn_Transaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Transaction.Location = new System.Drawing.Point(192, 310);
            this.btn_Transaction.Name = "btn_Transaction";
            this.btn_Transaction.Size = new System.Drawing.Size(246, 48);
            this.btn_Transaction.TabIndex = 3;
            this.btn_Transaction.Text = "Make Transaction";
            this.btn_Transaction.UseVisualStyleBackColor = true;
            this.btn_Transaction.Click += new System.EventHandler(this.btn_Transaction_Click);
            // 
            // txt_Amount
            // 
            this.txt_Amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Amount.Location = new System.Drawing.Point(269, 137);
            this.txt_Amount.Name = "txt_Amount";
            this.txt_Amount.Size = new System.Drawing.Size(100, 34);
            this.txt_Amount.TabIndex = 5;
            // 
            // txt_Type
            // 
            this.txt_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Type.Location = new System.Drawing.Point(269, 227);
            this.txt_Type.Name = "txt_Type";
            this.txt_Type.Size = new System.Drawing.Size(100, 34);
            this.txt_Type.TabIndex = 6;
            // 
            // cmb_AccountID
            // 
            this.cmb_AccountID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_AccountID.FormattingEnabled = true;
            this.cmb_AccountID.Location = new System.Drawing.Point(248, 47);
            this.cmb_AccountID.Name = "cmb_AccountID";
            this.cmb_AccountID.Size = new System.Drawing.Size(121, 37);
            this.cmb_AccountID.TabIndex = 7;
            // 
            // frm_New_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(676, 462);
            this.Controls.Add(this.cmb_AccountID);
            this.Controls.Add(this.txt_Type);
            this.Controls.Add(this.txt_Amount);
            this.Controls.Add(this.btn_Transaction);
            this.Controls.Add(this.lbl_Type);
            this.Controls.Add(this.lbl_Amount);
            this.Controls.Add(this.lbl_AccountID);
            this.Name = "frm_New_Transaction";
            this.Text = "frm_New_Transaction";
            this.Load += new System.EventHandler(this.frm_New_Transaction_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_AccountID;
        private System.Windows.Forms.Label lbl_Amount;
        private System.Windows.Forms.Label lbl_Type;
        private System.Windows.Forms.Button btn_Transaction;
        private System.Windows.Forms.TextBox txt_Amount;
        private System.Windows.Forms.TextBox txt_Type;
        private System.Windows.Forms.ComboBox cmb_AccountID;
    }
}