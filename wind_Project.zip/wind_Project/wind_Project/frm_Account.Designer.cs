﻿namespace wind_Project
{
    partial class frm_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CID = new System.Windows.Forms.Label();
            this.lbl_AccountType = new System.Windows.Forms.Label();
            this.lbl_Balance = new System.Windows.Forms.Label();
            this.txt_CID = new System.Windows.Forms.TextBox();
            this.txt_Balance = new System.Windows.Forms.TextBox();
            this.btn_New = new System.Windows.Forms.Button();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.cmb_12 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_CID
            // 
            this.lbl_CID.AutoSize = true;
            this.lbl_CID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CID.Location = new System.Drawing.Point(74, 59);
            this.lbl_CID.Name = "lbl_CID";
            this.lbl_CID.Size = new System.Drawing.Size(140, 29);
            this.lbl_CID.TabIndex = 0;
            this.lbl_CID.Text = "CustomerID";
            // 
            // lbl_AccountType
            // 
            this.lbl_AccountType.AutoSize = true;
            this.lbl_AccountType.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AccountType.Location = new System.Drawing.Point(71, 142);
            this.lbl_AccountType.Name = "lbl_AccountType";
            this.lbl_AccountType.Size = new System.Drawing.Size(159, 29);
            this.lbl_AccountType.TabIndex = 1;
            this.lbl_AccountType.Text = "Account Type";
            // 
            // lbl_Balance
            // 
            this.lbl_Balance.AutoSize = true;
            this.lbl_Balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Balance.Location = new System.Drawing.Point(104, 219);
            this.lbl_Balance.Name = "lbl_Balance";
            this.lbl_Balance.Size = new System.Drawing.Size(100, 29);
            this.lbl_Balance.TabIndex = 2;
            this.lbl_Balance.Text = "Balance";
            // 
            // txt_CID
            // 
            this.txt_CID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CID.Location = new System.Drawing.Point(233, 59);
            this.txt_CID.Name = "txt_CID";
            this.txt_CID.Size = new System.Drawing.Size(100, 34);
            this.txt_CID.TabIndex = 3;
            // 
            // txt_Balance
            // 
            this.txt_Balance.Location = new System.Drawing.Point(236, 219);
            this.txt_Balance.Name = "txt_Balance";
            this.txt_Balance.Size = new System.Drawing.Size(100, 22);
            this.txt_Balance.TabIndex = 5;
            // 
            // btn_New
            // 
            this.btn_New.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_New.Location = new System.Drawing.Point(107, 325);
            this.btn_New.Name = "btn_New";
            this.btn_New.Size = new System.Drawing.Size(107, 48);
            this.btn_New.TabIndex = 6;
            this.btn_New.Text = "New";
            this.btn_New.UseVisualStyleBackColor = true;
            this.btn_New.Click += new System.EventHandler(this.btn_New_Click);
            // 
            // btn_Reset
            // 
            this.btn_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reset.Location = new System.Drawing.Point(282, 323);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(103, 38);
            this.btn_Reset.TabIndex = 7;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // cmb_12
            // 
            this.cmb_12.FormattingEnabled = true;
            this.cmb_12.Location = new System.Drawing.Point(236, 142);
            this.cmb_12.Name = "cmb_12";
            this.cmb_12.Size = new System.Drawing.Size(121, 24);
            this.cmb_12.TabIndex = 8;
            this.cmb_12.SelectedIndexChanged += new System.EventHandler(this.cmb_12_SelectedIndexChanged);
            // 
            // frm_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 453);
            this.Controls.Add(this.cmb_12);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn_New);
            this.Controls.Add(this.txt_Balance);
            this.Controls.Add(this.txt_CID);
            this.Controls.Add(this.lbl_Balance);
            this.Controls.Add(this.lbl_AccountType);
            this.Controls.Add(this.lbl_CID);
            this.Name = "frm_Account";
            this.Text = "frm_Account";
            this.Load += new System.EventHandler(this.frm_Account_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CID;
        private System.Windows.Forms.Label lbl_AccountType;
        private System.Windows.Forms.Label lbl_Balance;
        private System.Windows.Forms.TextBox txt_CID;
        private System.Windows.Forms.TextBox txt_Balance;
        private System.Windows.Forms.Button btn_New;
        private System.Windows.Forms.Button btn_Reset;
        private System.Windows.Forms.ComboBox cmb_12;
    }
}