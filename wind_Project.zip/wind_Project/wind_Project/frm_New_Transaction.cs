﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wind_Project
{
    public partial class frm_New_Transaction : Form
    {
        public frm_New_Transaction()
        {
            InitializeComponent();
        }

        private void btn_Transaction_Click(object sender, EventArgs e)
        {
            if (cmb_AccountID.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if (txt_Amount.Text == string.Empty)
            {
                MessageBox.Show("enter amount");
            }
            else if (txt_Type.Text == string.Empty)
            {
                MessageBox.Show("enter type");

            }
            else
            {
                int id = Convert.ToInt32(cmb_AccountID.Text);
                int amount = Convert.ToInt32(txt_Amount.Text);
                string type = txt_Type.Text;

                Transactions obj = new Transactions();
                obj.AccountID = id;
                obj.Amount = amount;
                obj.TransactionType = type;


                CustomerDAL dal = new CustomerDAL();
                int ID =dal.NewTransaction(obj);
                MessageBox.Show("transaction success" + ID);
            }
        }

        private void frm_New_Transaction_Load(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            List<int> List = dal.AccountID(Test.CustomerID);
            foreach(var m in List)
            {
                cmb_AccountID.Items.Add(m);
            }
        }
    }
    }

