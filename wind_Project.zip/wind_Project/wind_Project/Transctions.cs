﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wind_Project
{
    class Transctions
    {
        public int TransID { get; set; }
        public int Amount { get; set; }
        public string TransType { get; set; }
        public DateTime TransDate { get; set; }

    }
}
