﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wind_Project
{
    public partial class frm_MyAccount : Form
    {
        public frm_MyAccount()
        {
            InitializeComponent();
        }

        private void btn_Show_Click(object sender, EventArgs e)
        {
            if (txt_CID.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                CustomerDAL dal = new CustomerDAL();

                int id = Convert.ToInt32(txt_CID.Text);
                List<Accounts> list = dal.myaccount(id);
               grd_Account.DataSource = list;

            }

        }

        private void frm_MyAccount_Load(object sender, EventArgs e)
        {
            txt_CID.Text = Test.CustomerID.ToString();

        }
    }
}
