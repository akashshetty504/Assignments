﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wind_Project
{
    public partial class frm_Account : Form
    {
        public frm_Account()
        {
            InitializeComponent();
        }

        private void btn_New_Click(object sender, EventArgs e)
        {
            if (txt_CID.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
           
            else if(txt_Balance.Text==string.Empty)
            {
                MessageBox.Show("enter the balance");

            }
            else if (cmb_12.Text == string.Empty)
            {
                MessageBox.Show("enter account type");
            }
            else
            {
                int id = Convert.ToInt32(txt_CID.Text);
                int balance = Convert.ToInt32(txt_Balance.Text);
                string acctype = cmb_12.Text;


                Accounts obj = new Accounts();
                obj.CustomerID = id;
                obj.AccountBalance = balance;
                obj.AccountType = acctype;


                CustomerDAL dal = new CustomerDAL();
                int ID = dal.AddAccounts(obj);
                MessageBox.Show("Account added" + ID);
            }
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
           
        }

        private void frm_Account_Load(object sender, EventArgs e)
        {
            txt_CID.Text = Test.CustomerID.ToString();
            cmb_12.Text = "Savings";
            cmb_12.Text = "Current";
        }

        private void cmb_12_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
