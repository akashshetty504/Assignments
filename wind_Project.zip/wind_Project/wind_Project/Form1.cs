﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wind_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_NewCustomer_Click(object sender, EventArgs e)
        {
            if (txt_CustomerName.Text == string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if (txt_CustomerEmail.Text == string.Empty)
            {
                MessageBox.Show("enter email");

            }
            else if (txt_CustomerMobileNo.Text == string.Empty)
            {
                MessageBox.Show("enter mobile no");
            }
            else if(txt_Gender.Text==string.Empty)
            {
                MessageBox.Show("enter gender");
            }


            else if (txt_CustomerPassword.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }

   
        
            else
            {
                string Name = txt_CustomerName.Text;
                string Email = txt_CustomerEmail.Text;
                string MobileNo = txt_CustomerMobileNo.Text;
                string Gender = txt_Gender.Text;
                string Password = txt_CustomerPassword.Text;
                Customers obj = new Customers();
                obj.CustomerName = Name;
                obj.CustomerEmail = Email;
                obj.CustomerMobileNo = MobileNo;
                obj.CustomerGender = Gender;
                obj.CustomerPassword = Password;

                CustomerDAL dal = new CustomerDAL();
                int id = dal.AddCustomers(obj);
                MessageBox.Show("customer added:" + id);

            }
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            txt_CustomerName.Text = string.Empty;
            txt_CustomerEmail.Text = string.Empty;
            txt_CustomerMobileNo.Text = string.Empty;
            txt_CustomerPassword.Text = string.Empty;

        }
    }
}

