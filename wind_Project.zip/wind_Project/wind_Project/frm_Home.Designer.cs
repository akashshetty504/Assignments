﻿namespace wind_Project
{
    partial class frm_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_NewAccount = new System.Windows.Forms.Button();
            this.btn_MyAccount = new System.Windows.Forms.Button();
            this.btn_NewTransaction = new System.Windows.Forms.Button();
            this.btn_MyTransaction = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_NewAccount
            // 
            this.btn_NewAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewAccount.Location = new System.Drawing.Point(93, 57);
            this.btn_NewAccount.Name = "btn_NewAccount";
            this.btn_NewAccount.Size = new System.Drawing.Size(152, 37);
            this.btn_NewAccount.TabIndex = 0;
            this.btn_NewAccount.Text = "New Account";
            this.btn_NewAccount.UseVisualStyleBackColor = true;
            this.btn_NewAccount.Click += new System.EventHandler(this.btn_NewAccount_Click);
            // 
            // btn_MyAccount
            // 
            this.btn_MyAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MyAccount.Location = new System.Drawing.Point(314, 59);
            this.btn_MyAccount.Name = "btn_MyAccount";
            this.btn_MyAccount.Size = new System.Drawing.Size(138, 35);
            this.btn_MyAccount.TabIndex = 1;
            this.btn_MyAccount.Text = "My Account";
            this.btn_MyAccount.UseVisualStyleBackColor = true;
            this.btn_MyAccount.Click += new System.EventHandler(this.btn_MyAccount_Click);
            // 
            // btn_NewTransaction
            // 
            this.btn_NewTransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewTransaction.Location = new System.Drawing.Point(20, 220);
            this.btn_NewTransaction.Name = "btn_NewTransaction";
            this.btn_NewTransaction.Size = new System.Drawing.Size(225, 37);
            this.btn_NewTransaction.TabIndex = 2;
            this.btn_NewTransaction.Text = "New transaction";
            this.btn_NewTransaction.UseVisualStyleBackColor = true;
            this.btn_NewTransaction.Click += new System.EventHandler(this.btn_NewTransaction_Click);
            // 
            // btn_MyTransaction
            // 
            this.btn_MyTransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MyTransaction.Location = new System.Drawing.Point(314, 222);
            this.btn_MyTransaction.Name = "btn_MyTransaction";
            this.btn_MyTransaction.Size = new System.Drawing.Size(215, 35);
            this.btn_MyTransaction.TabIndex = 3;
            this.btn_MyTransaction.Text = "My Transaction";
            this.btn_MyTransaction.UseVisualStyleBackColor = true;
            this.btn_MyTransaction.Click += new System.EventHandler(this.btn_MyTransaction_Click);
            // 
            // frm_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(583, 394);
            this.Controls.Add(this.btn_MyTransaction);
            this.Controls.Add(this.btn_NewTransaction);
            this.Controls.Add(this.btn_MyAccount);
            this.Controls.Add(this.btn_NewAccount);
            this.Name = "frm_Home";
            this.Text = "frm_Home";
            this.Load += new System.EventHandler(this.frm_Home_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_NewAccount;
        private System.Windows.Forms.Button btn_MyAccount;
        private System.Windows.Forms.Button btn_NewTransaction;
        private System.Windows.Forms.Button btn_MyTransaction;
    }
}