﻿namespace wind_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Reset = new System.Windows.Forms.Button();
            this.btn_NewCustomer = new System.Windows.Forms.Button();
            this.txt_CustomerPassword = new System.Windows.Forms.TextBox();
            this.txt_CustomerEmail = new System.Windows.Forms.TextBox();
            this.txt_CustomerName = new System.Windows.Forms.TextBox();
            this.lbl_CustomerPassword = new System.Windows.Forms.Label();
            this.lbl_CustomerEmail = new System.Windows.Forms.Label();
            this.lbl_CustomerName = new System.Windows.Forms.Label();
            this.lbl_CustomerMobileNo = new System.Windows.Forms.Label();
            this.lbl_CustomerGender = new System.Windows.Forms.Label();
            this.txt_CustomerMobileNo = new System.Windows.Forms.TextBox();
            this.txt_Gender = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Reset
            // 
            this.btn_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reset.Location = new System.Drawing.Point(563, 399);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(92, 37);
            this.btn_Reset.TabIndex = 15;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // btn_NewCustomer
            // 
            this.btn_NewCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NewCustomer.Location = new System.Drawing.Point(330, 397);
            this.btn_NewCustomer.Name = "btn_NewCustomer";
            this.btn_NewCustomer.Size = new System.Drawing.Size(125, 39);
            this.btn_NewCustomer.TabIndex = 14;
            this.btn_NewCustomer.Text = "New Customer";
            this.btn_NewCustomer.UseVisualStyleBackColor = true;
            this.btn_NewCustomer.Click += new System.EventHandler(this.btn_NewCustomer_Click);
            // 
            // txt_CustomerPassword
            // 
            this.txt_CustomerPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerPassword.Location = new System.Drawing.Point(477, 271);
            this.txt_CustomerPassword.Name = "txt_CustomerPassword";
            this.txt_CustomerPassword.Size = new System.Drawing.Size(100, 34);
            this.txt_CustomerPassword.TabIndex = 13;
            // 
            // txt_CustomerEmail
            // 
            this.txt_CustomerEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerEmail.Location = new System.Drawing.Point(477, 85);
            this.txt_CustomerEmail.Name = "txt_CustomerEmail";
            this.txt_CustomerEmail.Size = new System.Drawing.Size(100, 34);
            this.txt_CustomerEmail.TabIndex = 12;
            // 
            // txt_CustomerName
            // 
            this.txt_CustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerName.Location = new System.Drawing.Point(477, 25);
            this.txt_CustomerName.Name = "txt_CustomerName";
            this.txt_CustomerName.Size = new System.Drawing.Size(100, 34);
            this.txt_CustomerName.TabIndex = 11;
            // 
            // lbl_CustomerPassword
            // 
            this.lbl_CustomerPassword.AutoSize = true;
            this.lbl_CustomerPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerPassword.Location = new System.Drawing.Point(179, 271);
            this.lbl_CustomerPassword.Name = "lbl_CustomerPassword";
            this.lbl_CustomerPassword.Size = new System.Drawing.Size(230, 29);
            this.lbl_CustomerPassword.TabIndex = 10;
            this.lbl_CustomerPassword.Text = "Customer Password";
            // 
            // lbl_CustomerEmail
            // 
            this.lbl_CustomerEmail.AutoSize = true;
            this.lbl_CustomerEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerEmail.Location = new System.Drawing.Point(325, 85);
            this.lbl_CustomerEmail.Name = "lbl_CustomerEmail";
            this.lbl_CustomerEmail.Size = new System.Drawing.Size(74, 29);
            this.lbl_CustomerEmail.TabIndex = 9;
            this.lbl_CustomerEmail.Text = "Email";
            // 
            // lbl_CustomerName
            // 
            this.lbl_CustomerName.AutoSize = true;
            this.lbl_CustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerName.Location = new System.Drawing.Point(211, 28);
            this.lbl_CustomerName.Name = "lbl_CustomerName";
            this.lbl_CustomerName.Size = new System.Drawing.Size(188, 29);
            this.lbl_CustomerName.TabIndex = 8;
            this.lbl_CustomerName.Text = "Customer Name";
            // 
            // lbl_CustomerMobileNo
            // 
            this.lbl_CustomerMobileNo.AutoSize = true;
            this.lbl_CustomerMobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerMobileNo.Location = new System.Drawing.Point(273, 139);
            this.lbl_CustomerMobileNo.Name = "lbl_CustomerMobileNo";
            this.lbl_CustomerMobileNo.Size = new System.Drawing.Size(125, 29);
            this.lbl_CustomerMobileNo.TabIndex = 16;
            this.lbl_CustomerMobileNo.Text = "Mobile No";
            // 
            // lbl_CustomerGender
            // 
            this.lbl_CustomerGender.AutoSize = true;
            this.lbl_CustomerGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CustomerGender.Location = new System.Drawing.Point(304, 202);
            this.lbl_CustomerGender.Name = "lbl_CustomerGender";
            this.lbl_CustomerGender.Size = new System.Drawing.Size(94, 29);
            this.lbl_CustomerGender.TabIndex = 17;
            this.lbl_CustomerGender.Text = "Gender";
            // 
            // txt_CustomerMobileNo
            // 
            this.txt_CustomerMobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerMobileNo.Location = new System.Drawing.Point(477, 139);
            this.txt_CustomerMobileNo.Name = "txt_CustomerMobileNo";
            this.txt_CustomerMobileNo.Size = new System.Drawing.Size(100, 34);
            this.txt_CustomerMobileNo.TabIndex = 18;
            // 
            // txt_Gender
            // 
            this.txt_Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Gender.Location = new System.Drawing.Point(477, 197);
            this.txt_Gender.Name = "txt_Gender";
            this.txt_Gender.Size = new System.Drawing.Size(100, 34);
            this.txt_Gender.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(851, 517);
            this.Controls.Add(this.txt_Gender);
            this.Controls.Add(this.txt_CustomerMobileNo);
            this.Controls.Add(this.lbl_CustomerGender);
            this.Controls.Add(this.lbl_CustomerMobileNo);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn_NewCustomer);
            this.Controls.Add(this.txt_CustomerPassword);
            this.Controls.Add(this.txt_CustomerEmail);
            this.Controls.Add(this.txt_CustomerName);
            this.Controls.Add(this.lbl_CustomerPassword);
            this.Controls.Add(this.lbl_CustomerEmail);
            this.Controls.Add(this.lbl_CustomerName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Reset;
        private System.Windows.Forms.Button btn_NewCustomer;
        private System.Windows.Forms.TextBox txt_CustomerPassword;
        private System.Windows.Forms.TextBox txt_CustomerEmail;
        private System.Windows.Forms.TextBox txt_CustomerName;
        private System.Windows.Forms.Label lbl_CustomerPassword;
        private System.Windows.Forms.Label lbl_CustomerEmail;
        private System.Windows.Forms.Label lbl_CustomerName;
        private System.Windows.Forms.Label lbl_CustomerMobileNo;
        private System.Windows.Forms.Label lbl_CustomerGender;
        private System.Windows.Forms.TextBox txt_CustomerMobileNo;
        private System.Windows.Forms.TextBox txt_Gender;
    }
}

