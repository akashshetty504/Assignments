select * from tbl_employees
