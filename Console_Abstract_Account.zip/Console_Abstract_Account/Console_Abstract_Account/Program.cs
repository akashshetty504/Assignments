﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter Account ID");
            int ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter customer name");
            string Name = Console.ReadLine();
            Console.WriteLine("enter accountbalance");
            int Balance = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter account type");
            string Type = Console.ReadLine();
            Account obj = null;
            if(Type=="saving")
            {
                obj = new Saving(ID, Name, Balance);

            }
            else if(Type=="Current")
                    {
                obj = new Current(ID, Name, Balance);

            }if(obj!=null)
            {
                obj.StopPayment();
                obj.BlockAccount();
                int AccBalance = obj.GetBalance();
                Console.WriteLine("Balance" + AccBalance);
                Console.WriteLine("enter an amount to deposit");
                int Amt = Convert.ToInt32(Console.ReadLine());
                obj.Deposit(Amt);
                AccBalance = obj.GetBalance();
                Console.WriteLine("Balance" + AccBalance);
                Console.WriteLine("enter an amount to withdraw");
                Amt = Convert.ToInt32(Console.ReadLine());

                obj.Withdraw(Amt);
                AccBalance = obj.GetBalance();
                Console.WriteLine("balance" + AccBalance);

            }
            Console.ReadLine();
        }
    }
}
