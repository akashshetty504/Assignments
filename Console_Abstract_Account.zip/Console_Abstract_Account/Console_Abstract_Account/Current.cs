﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Current:Account
    {
        public Current(int AccountID,string CustomerName,int AccountBalance)
            :base(AccountID,CustomerName,AccountBalance)
        {
            Console.WriteLine("current account constructor");

        }

        public override void Deposit(int Amt)
        {
            this.AccountBalance += Amt;
        }

        public override void Withdraw(int Amt)
        {
            this.AccountBalance -= Amt;
        }
    }
}
