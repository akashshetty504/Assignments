create database librarydb

use librarydb

create table tbl_books
(
BookID int identity(1000,1) primary key,
BookName varchar(100) not null,
AuthorName varchar(100) not null,
BookImage varchar(100) not null
)

select * from tbl_books

create proc proc_addbook(@name varchar(100),@aname varchar(100),@image varchar(100))
as
insert tbl_books values(@name,@aname,@image)
return @@identity


create proc proc_Searchbook(@key varchar(100))
as
select * from tbl_books where BookID like '%'+@key+'%'
or BookName like '%' +@key+ '%'
or AuthorName like '%'+@key+'%'
