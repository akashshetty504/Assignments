﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wind_Customers
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {

            int ID = Convert.ToInt32(txt_LoginID.Text);
            string Password = txt_Password.Text;
            
            
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Login(ID, Password);
                if (status)
                {
                    MessageBox.Show("valid user");
                }
                else
                {
                    MessageBox.Show("invalid user");
                }
            }
    }
}
