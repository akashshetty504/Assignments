﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wind_Customers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_AddCustomer_Click(object sender, EventArgs e)
        {
            if (txt_CustomerName.Text == string.Empty)
            {
                MessageBox.Show("enter name");

            }
            else if (txt_CustomerCity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txt_CustomerPassword.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else if (txt_CustomerMobileNo.Text == string.Empty)
            {
                MessageBox.Show("enter mobile no");

            }
            else if (txt_CustomerAddress.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txt_CustomerEmail.Text == string.Empty)
            {
                MessageBox.Show("enter email");
            }
            else
            {
                string Name = txt_CustomerName.Text;
                string city = txt_CustomerCity.Text;
                string Password = txt_CustomerPassword.Text;
                string MobileNo = txt_CustomerMobileNo.Text;
                string Address = txt_CustomerAddress.Text;
                string Email = txt_CustomerEmail.Text;

                customers obj = new customers();
                obj.CustomerName = Name;
                obj.CustomerCity = city;
                obj.CustomerPassword = Password;
                obj.CustomerMobileNo = MobileNo;
                obj.CustomerAddress = Address;
                obj.CustomerEmail = Email;

                CustomerDAL dal = new CustomerDAL();
                int id = dal.AddCustomer(obj);
                MessageBox.Show("customer added :" + id);
            }

        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            if (txt_CustomerID.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");

            }
            else
            {
                int ID = Convert.ToInt32(txt_CustomerID.Text);
                CustomerDAL dal = new CustomerDAL();
                customers cus = dal.Find(ID);
                if (cus != null)
                {
                    txt_CustomerName.Text = cus.CustomerName;
                    txt_CustomerCity.Text = cus.CustomerCity;
                    txt_CustomerPassword.Text = cus.CustomerPassword;
                    txt_CustomerMobileNo.Text = cus.CustomerMobileNo;
                    txt_CustomerAddress.Text = cus.CustomerAddress;
                    txt_CustomerEmail.Text = cus.CustomerEmail;


                }
                else
                {
                    MessageBox.Show("not found");
                }

            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (txt_CustomerID.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if (txt_CustomerCity.Text == string.Empty)
            {
                MessageBox.Show("enter city");

            }
            else if (txt_CustomerPassword.Text == string.Empty)
            {
                MessageBox.Show("enter password");

            }
            else if (txt_CustomerMobileNo.Text == string.Empty)
            {
                MessageBox.Show("enter mobile no");
            }
            else if (txt_CustomerAddress.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txt_CustomerEmail.Text == string.Empty)
            {
                MessageBox.Show("enter email");
            }
            else
            {
                int ID = Convert.ToInt32(txt_CustomerID.Text);
                string Name = txt_CustomerName.Text;
                string City = txt_CustomerCity.Text;
                string Password = txt_CustomerPassword.Text;
                string MobileNo = txt_CustomerMobileNo.Text;
                string Address = txt_CustomerAddress.Text;
                string Email = txt_CustomerEmail.Text;
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.update(ID, Name, City, Password, MobileNo, Address, Email);
                if (status)
                {
                    MessageBox.Show("updated");

                }
                else
                {
                    MessageBox.Show("not updated");
                }


            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (txt_CustomerID.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_CustomerID.Text);
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.delete(ID);
                if (status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("not found");
                }

            }
        }
    }
}

