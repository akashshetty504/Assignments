﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Wind_Customers
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection
 (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddCustomer(customers cus)
        {
            SqlCommand com_cus_insert = new SqlCommand
     ("proc_addcustomers", con);
            com_cus_insert.Parameters.AddWithValue("@name", cus.CustomerName);
            com_cus_insert.Parameters.AddWithValue("@city", cus.CustomerCity);
            com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);
            com_cus_insert.Parameters.AddWithValue("@mobileno", cus.CustomerMobileNo);
            com_cus_insert.Parameters.AddWithValue("@address", cus.CustomerAddress);
            com_cus_insert.Parameters.AddWithValue("@email", cus.CustomerEmail);
            com_cus_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_cus_insert.Parameters.Add(retdata);



            con.Open();
            com_cus_insert.ExecuteNonQuery();
            con.Close();

            int ID = Convert.ToInt32(retdata.Value);
            return ID;
        }


        public customers Find(int ID)
        {
            SqlCommand com_find = new SqlCommand
    ("proc_Customerdetails", con);
            com_find.Parameters.AddWithValue("@id", ID);
            com_find.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                customers c = new customers();
                c.CustomerID = dr.GetInt32(0);
                c.CustomerName = dr.GetString(1);
                c.CustomerCity = dr.GetString(2);
                c.CustomerPassword = dr.GetString(3);
                c.CustomerMobileNo = dr.GetString(4);
                c.CustomerAddress = dr.GetString(5);
                c.CustomerEmail = dr.GetString(6);
                con.Close();
                return c;
            } else
            {
                return null;
            }

        }


        public bool update(int ID, string Name, string City, string Password, string MobileNo, string Address, string Email)
        {
            SqlCommand com_update = new SqlCommand
("proc_Updatecustomers", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@city", City);
            com_update.Parameters.AddWithValue("@password", Password);
            com_update.Parameters.AddWithValue("@mobileno", MobileNo);
            com_update.Parameters.AddWithValue("@address", Address);
            com_update.Parameters.AddWithValue("@email", Email);

            com_update.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_update.Parameters.Add(retdata);
            con.Open();
            com_update.ExecuteNonQuery();
            con.Close();

            int count = Convert.ToInt32(retdata.Value);
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public bool  delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand
    ("proc_deletecustomers", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            com_delete.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_delete.Parameters.Add(retdata);

            con.Open();
             com_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if(count>0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }
             

        public List<customers> Showcustomers(string City)
        {
            SqlCommand com_customers = new SqlCommand("proc_Showcustomers", con);
            com_customers.Parameters.AddWithValue("@city", City);
            com_customers.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_customers.ExecuteReader();

            List<customers> cuslist = new List<customers>();
            while (dr.Read())
            {
                customers obj = new customers();
                obj.CustomerID = dr.GetInt32(0);
                obj.CustomerName = dr.GetString(1);
                obj.CustomerCity = dr.GetString(2);
                obj.CustomerPassword = dr.GetString(3);
                obj.CustomerMobileNo = dr.GetString(4);
                obj.CustomerAddress = dr.GetString(5);
                obj.CustomerEmail = dr.GetString(6);

                cuslist.Add(obj);
            }
            con.Close();
            return cuslist;

            
        }

        public List<customers> Searchcustomers(string Search)

        {
            SqlCommand com_Search = new SqlCommand
                ("proc_searchcustomers", con);
            com_Search.Parameters.AddWithValue("@key", Search);
            com_Search.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = com_Search.ExecuteReader();
            List<customers> cuslist = new List<customers>();
            while (dr.Read())
            {
                customers cus = new customers();
                cus.CustomerID= dr.GetInt32(0);
                cus.CustomerName = dr.GetString(1);
                cus.CustomerCity = dr.GetString(2);
                cus.CustomerPassword = dr.GetString(3);
                cus.CustomerMobileNo = dr.GetString(4);
                cus.CustomerAddress = dr.GetString(5);
                cus.CustomerEmail = dr.GetString(6);

                cuslist.Add(cus);


            }
            con.Close();
            return cuslist;
        }

        public bool Login(int ID, String Password)
        {


            SqlCommand com_Login = new SqlCommand("proc_login", con);
            com_Login.Parameters.AddWithValue("@id", ID);
            com_Login.Parameters.AddWithValue("@password", Password);
            com_Login.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_Login.Parameters.Add(retdata);
            con.Open();
            com_Login.ExecuteScalar();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }





            }
}
