﻿namespace Wind_Customers
{
    partial class fem_Showcustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_Customers = new System.Windows.Forms.DataGridView();
            this.btn_SearchAll = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.txt_Search = new System.Windows.Forms.TextBox();
            this.txt_CustomerCity = new System.Windows.Forms.TextBox();
            this.lbl_Search = new System.Windows.Forms.Label();
            this.lbl_CustomerCity = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Customers)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_Customers
            // 
            this.dg_Customers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Customers.Location = new System.Drawing.Point(37, 173);
            this.dg_Customers.Name = "dg_Customers";
            this.dg_Customers.RowTemplate.Height = 24;
            this.dg_Customers.Size = new System.Drawing.Size(779, 305);
            this.dg_Customers.TabIndex = 13;
            // 
            // btn_SearchAll
            // 
            this.btn_SearchAll.Location = new System.Drawing.Point(374, 98);
            this.btn_SearchAll.Name = "btn_SearchAll";
            this.btn_SearchAll.Size = new System.Drawing.Size(121, 23);
            this.btn_SearchAll.TabIndex = 12;
            this.btn_SearchAll.Text = "Search(All)";
            this.btn_SearchAll.UseVisualStyleBackColor = true;
            this.btn_SearchAll.Click += new System.EventHandler(this.btn_SearchAll_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(369, 32);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 23);
            this.btn_Find.TabIndex = 11;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // txt_Search
            // 
            this.txt_Search.Location = new System.Drawing.Point(222, 90);
            this.txt_Search.Name = "txt_Search";
            this.txt_Search.Size = new System.Drawing.Size(100, 22);
            this.txt_Search.TabIndex = 10;
            // 
            // txt_CustomerCity
            // 
            this.txt_CustomerCity.Location = new System.Drawing.Point(220, 22);
            this.txt_CustomerCity.Name = "txt_CustomerCity";
            this.txt_CustomerCity.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerCity.TabIndex = 9;
            // 
            // lbl_Search
            // 
            this.lbl_Search.AutoSize = true;
            this.lbl_Search.Location = new System.Drawing.Point(54, 86);
            this.lbl_Search.Name = "lbl_Search";
            this.lbl_Search.Size = new System.Drawing.Size(53, 17);
            this.lbl_Search.TabIndex = 8;
            this.lbl_Search.Text = "Search";
            // 
            // lbl_CustomerCity
            // 
            this.lbl_CustomerCity.AutoSize = true;
            this.lbl_CustomerCity.Location = new System.Drawing.Point(57, 23);
            this.lbl_CustomerCity.Name = "lbl_CustomerCity";
            this.lbl_CustomerCity.Size = new System.Drawing.Size(95, 17);
            this.lbl_CustomerCity.TabIndex = 7;
            this.lbl_CustomerCity.Text = "Customer City";
            // 
            // fem_Showcustomers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 500);
            this.Controls.Add(this.dg_Customers);
            this.Controls.Add(this.btn_SearchAll);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.txt_Search);
            this.Controls.Add(this.txt_CustomerCity);
            this.Controls.Add(this.lbl_Search);
            this.Controls.Add(this.lbl_CustomerCity);
            this.Name = "fem_Showcustomers";
            this.Text = "fem_Showcustomers";
            ((System.ComponentModel.ISupportInitialize)(this.dg_Customers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_Customers;
        private System.Windows.Forms.Button btn_SearchAll;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.TextBox txt_Search;
        private System.Windows.Forms.TextBox txt_CustomerCity;
        private System.Windows.Forms.Label lbl_Search;
        private System.Windows.Forms.Label lbl_CustomerCity;
    }
}