﻿namespace Wind_Customers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CustomerID = new System.Windows.Forms.Label();
            this.lbl_CustomerName = new System.Windows.Forms.Label();
            this.lbl_CustomerCity = new System.Windows.Forms.Label();
            this.lbl_CustomerPassword = new System.Windows.Forms.Label();
            this.lbl_CustomerMobileNo = new System.Windows.Forms.Label();
            this.lbl_CustomerAddress = new System.Windows.Forms.Label();
            this.lbl_CustomerEmail = new System.Windows.Forms.Label();
            this.txt_CustomerID = new System.Windows.Forms.TextBox();
            this.txt_CustomerName = new System.Windows.Forms.TextBox();
            this.txt_CustomerCity = new System.Windows.Forms.TextBox();
            this.txt_CustomerPassword = new System.Windows.Forms.TextBox();
            this.txt_CustomerMobileNo = new System.Windows.Forms.TextBox();
            this.txt_CustomerAddress = new System.Windows.Forms.TextBox();
            this.txt_CustomerEmail = new System.Windows.Forms.TextBox();
            this.btn_AddCustomer = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_CustomerID
            // 
            this.lbl_CustomerID.AutoSize = true;
            this.lbl_CustomerID.Location = new System.Drawing.Point(33, 24);
            this.lbl_CustomerID.Name = "lbl_CustomerID";
            this.lbl_CustomerID.Size = new System.Drawing.Size(89, 17);
            this.lbl_CustomerID.TabIndex = 0;
            this.lbl_CustomerID.Text = "Customer ID:";
            // 
            // lbl_CustomerName
            // 
            this.lbl_CustomerName.AutoSize = true;
            this.lbl_CustomerName.Location = new System.Drawing.Point(29, 83);
            this.lbl_CustomerName.Name = "lbl_CustomerName";
            this.lbl_CustomerName.Size = new System.Drawing.Size(113, 17);
            this.lbl_CustomerName.TabIndex = 1;
            this.lbl_CustomerName.Text = "Customer Name:";
            // 
            // lbl_CustomerCity
            // 
            this.lbl_CustomerCity.AutoSize = true;
            this.lbl_CustomerCity.Location = new System.Drawing.Point(31, 146);
            this.lbl_CustomerCity.Name = "lbl_CustomerCity";
            this.lbl_CustomerCity.Size = new System.Drawing.Size(99, 17);
            this.lbl_CustomerCity.TabIndex = 2;
            this.lbl_CustomerCity.Text = "Customer City:";
            // 
            // lbl_CustomerPassword
            // 
            this.lbl_CustomerPassword.AutoSize = true;
            this.lbl_CustomerPassword.Location = new System.Drawing.Point(27, 209);
            this.lbl_CustomerPassword.Name = "lbl_CustomerPassword";
            this.lbl_CustomerPassword.Size = new System.Drawing.Size(137, 17);
            this.lbl_CustomerPassword.TabIndex = 3;
            this.lbl_CustomerPassword.Text = "Customer Password:";
            // 
            // lbl_CustomerMobileNo
            // 
            this.lbl_CustomerMobileNo.AutoSize = true;
            this.lbl_CustomerMobileNo.Location = new System.Drawing.Point(30, 267);
            this.lbl_CustomerMobileNo.Name = "lbl_CustomerMobileNo";
            this.lbl_CustomerMobileNo.Size = new System.Drawing.Size(139, 17);
            this.lbl_CustomerMobileNo.TabIndex = 4;
            this.lbl_CustomerMobileNo.Text = "Customer Mobile No:";
            // 
            // lbl_CustomerAddress
            // 
            this.lbl_CustomerAddress.AutoSize = true;
            this.lbl_CustomerAddress.Location = new System.Drawing.Point(28, 329);
            this.lbl_CustomerAddress.Name = "lbl_CustomerAddress";
            this.lbl_CustomerAddress.Size = new System.Drawing.Size(128, 17);
            this.lbl_CustomerAddress.TabIndex = 5;
            this.lbl_CustomerAddress.Text = "Customer Address:";
            // 
            // lbl_CustomerEmail
            // 
            this.lbl_CustomerEmail.AutoSize = true;
            this.lbl_CustomerEmail.Location = new System.Drawing.Point(27, 387);
            this.lbl_CustomerEmail.Name = "lbl_CustomerEmail";
            this.lbl_CustomerEmail.Size = new System.Drawing.Size(110, 17);
            this.lbl_CustomerEmail.TabIndex = 6;
            this.lbl_CustomerEmail.Text = "Customer Email:";
            // 
            // txt_CustomerID
            // 
            this.txt_CustomerID.Location = new System.Drawing.Point(188, 20);
            this.txt_CustomerID.Name = "txt_CustomerID";
            this.txt_CustomerID.Size = new System.Drawing.Size(184, 22);
            this.txt_CustomerID.TabIndex = 7;
            // 
            // txt_CustomerName
            // 
            this.txt_CustomerName.Location = new System.Drawing.Point(220, 75);
            this.txt_CustomerName.Name = "txt_CustomerName";
            this.txt_CustomerName.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerName.TabIndex = 8;
            // 
            // txt_CustomerCity
            // 
            this.txt_CustomerCity.Location = new System.Drawing.Point(218, 144);
            this.txt_CustomerCity.Name = "txt_CustomerCity";
            this.txt_CustomerCity.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerCity.TabIndex = 9;
            // 
            // txt_CustomerPassword
            // 
            this.txt_CustomerPassword.Location = new System.Drawing.Point(223, 206);
            this.txt_CustomerPassword.Name = "txt_CustomerPassword";
            this.txt_CustomerPassword.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerPassword.TabIndex = 10;
            // 
            // txt_CustomerMobileNo
            // 
            this.txt_CustomerMobileNo.Location = new System.Drawing.Point(222, 276);
            this.txt_CustomerMobileNo.Name = "txt_CustomerMobileNo";
            this.txt_CustomerMobileNo.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerMobileNo.TabIndex = 11;
            // 
            // txt_CustomerAddress
            // 
            this.txt_CustomerAddress.Location = new System.Drawing.Point(226, 336);
            this.txt_CustomerAddress.Name = "txt_CustomerAddress";
            this.txt_CustomerAddress.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerAddress.TabIndex = 12;
            // 
            // txt_CustomerEmail
            // 
            this.txt_CustomerEmail.Location = new System.Drawing.Point(226, 390);
            this.txt_CustomerEmail.Name = "txt_CustomerEmail";
            this.txt_CustomerEmail.Size = new System.Drawing.Size(100, 22);
            this.txt_CustomerEmail.TabIndex = 13;
            // 
            // btn_AddCustomer
            // 
            this.btn_AddCustomer.Location = new System.Drawing.Point(525, 44);
            this.btn_AddCustomer.Name = "btn_AddCustomer";
            this.btn_AddCustomer.Size = new System.Drawing.Size(75, 23);
            this.btn_AddCustomer.TabIndex = 14;
            this.btn_AddCustomer.Text = "Add Customer";
            this.btn_AddCustomer.UseVisualStyleBackColor = true;
            this.btn_AddCustomer.Click += new System.EventHandler(this.btn_AddCustomer_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(525, 140);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 23);
            this.btn_Find.TabIndex = 15;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(525, 215);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(75, 23);
            this.btn_Update.TabIndex = 16;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(525, 295);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 23);
            this.btn_Delete.TabIndex = 17;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 519);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.btn_AddCustomer);
            this.Controls.Add(this.txt_CustomerEmail);
            this.Controls.Add(this.txt_CustomerAddress);
            this.Controls.Add(this.txt_CustomerMobileNo);
            this.Controls.Add(this.txt_CustomerPassword);
            this.Controls.Add(this.txt_CustomerCity);
            this.Controls.Add(this.txt_CustomerName);
            this.Controls.Add(this.txt_CustomerID);
            this.Controls.Add(this.lbl_CustomerEmail);
            this.Controls.Add(this.lbl_CustomerAddress);
            this.Controls.Add(this.lbl_CustomerMobileNo);
            this.Controls.Add(this.lbl_CustomerPassword);
            this.Controls.Add(this.lbl_CustomerCity);
            this.Controls.Add(this.lbl_CustomerName);
            this.Controls.Add(this.lbl_CustomerID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CustomerID;
        private System.Windows.Forms.Label lbl_CustomerName;
        private System.Windows.Forms.Label lbl_CustomerCity;
        private System.Windows.Forms.Label lbl_CustomerPassword;
        private System.Windows.Forms.Label lbl_CustomerMobileNo;
        private System.Windows.Forms.Label lbl_CustomerAddress;
        private System.Windows.Forms.Label lbl_CustomerEmail;
        private System.Windows.Forms.TextBox txt_CustomerID;
        private System.Windows.Forms.TextBox txt_CustomerName;
        private System.Windows.Forms.TextBox txt_CustomerCity;
        private System.Windows.Forms.TextBox txt_CustomerPassword;
        private System.Windows.Forms.TextBox txt_CustomerMobileNo;
        private System.Windows.Forms.TextBox txt_CustomerAddress;
        private System.Windows.Forms.TextBox txt_CustomerEmail;
        private System.Windows.Forms.Button btn_AddCustomer;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_Delete;
    }
}

