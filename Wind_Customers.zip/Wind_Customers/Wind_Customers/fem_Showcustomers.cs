﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wind_Customers
{
    public partial class fem_Showcustomers : Form
    {
        public fem_Showcustomers()
        {
            InitializeComponent();
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string City = txt_CustomerCity.Text;
            List<customers> list = dal.Showcustomers(City);
            dg_Customers.DataSource = list;
        }

        private void btn_SearchAll_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string key = txt_Search.Text;
            List<customers> list = dal.Searchcustomers(key);
            dg_Customers.DataSource = list;
        }
    }
}
