Create Database PathfrontDB

use PathfrontDB

Create Table tbl_Customers
(
CustomerID int,
customerName Varchar(100),
CustomerCity varchar(100),
CustomerDOb Datetime
)


sp_help tbl_Customers
select * from tbl_Customers

insert tbl_Customers values(1001,'john','Chennai','10-24-1991')
insert tbl_Customers values(1002,'smitha','pune','10-11-1998')
insert tbl_Customers values(1003,'rahul','pune','10-10-1997')
insert tbl_Customers values(1004,'lalith','hyderbad','10-16-1996')
insert tbl_Customers values(1005,'ram','banglore','10-19-1992')

insert tbl_Customers values(1006,'xyz',null,null)

insert tbl_Customers(CustomerID,customerName)values(1007,'abc')


select * from tbl_Customers

select customerid,customername from tbl_Customers

select * from tbl_Customers where customercity ='chennai' 

update tbl_Customers set CustomerCity='hyd' ,customerName='xyz' 
where customerid=1001 and customerName='john'

delete tbl_Customers where customerid=1002

select*from tbl_Customers
 truncate table tbl_Customers
 select *from tbl_Customers

 alter table tbl_Customers add CustomerEmail varchar(100)

 select*from tbl_Customers

 alter table tbl_Customers drop column CustomerEmail


 alter table tbl_Customers alter column customername varchar(200)
 select *from tbl_Customers


select * from tbl_customers where customercity not in ('chennai','pune','hyd')
select * from tbl_customers where customercity is null

select * from tbl_customers where customerdob
beteween '12-12-1998' and '12-12-2000'

select * from tbl_Customers order by CustomerDOb asc,CustomerCity desc

select top 1 * from tbl_Customers
order by customerdob desc

select len('hello')
select substring('hello',1,4)
select lower('HELLO')
select upper('hello')
select left('hello',2)
select right('hello',2)
select isnumeric('12a')
select ceiling(25.01)
select floor(25.99)
select round(253.2595,2)
select isnull(column_name,0)
select * from Customers order by len(customername)asc






create table tbl_employees
(
employeeid int,
employeename varchar(100),
employeecity varchar(100),
employeesalary int

)

insert tbl_employees values(1001,'rahul','pune',10000)
insert tbl_employees values(1002,'xyz','chennai',12000)
insert tbl_employees values(1003,'abx','kolkata',16000)
insert tbl_employees values(1004,'hjk','banglore',14000)
insert tbl_employees values(1005,'asd','manglore',20000)



select * from tbl_employees

select sum(employeesalary) from tbl_employees

select avg(employeesalary) from tbl_employees

select max(employeesalary)from tbl_employees

select min(employeesalary) from tbl_employees

select count(*) from tbl_employees

select getdate()

select * from tbl_Customers

select customerid,customername,datediff(yy,customerdob,getdate())as 'age',
datename(dw,customerdob) as 'day',datepart(dw,customerdob)as 'number'
from tbl_Customers

select dateadd(yy,2,customerdob) from tbl_Customers

select convert  (varchar(10),employeesalary) from tbl_employees

select cast(employeesalary as decimal(12,2)) from tbl_employees

select employeecity,count(*) from tbl_employees group by employeecity

select employeecity ,avg(employeesalary) from tbl_employees group by employeecity

select employeecity,max(employeesalary) from tbl_employees group by employeecity

select employeecity ,count(*) from tbl_employees where employeesalary > 10000 group
by employeecity

select employeecity ,count(*) from tbl_employees group by employeecity
having count(*)>1




