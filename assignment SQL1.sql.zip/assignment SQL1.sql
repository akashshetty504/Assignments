create database EMP_DB

use EMP_DB

create table tbl_Employees
(
employeeid int,
employeeFname varchar(100),
employeeLname varchar(100),
employeeCity varchar(100),
employeeDOB datetime,
employeeSalary int,
employeeStatus Varchar(100)
)

alter table tbl_Employees add EmployeeDept varchar(100)

select * from tbl_Employees

alter table tbl_employees add EmployeeDOJ datetime
select * from tbl_Employees

insert tbl_Employees values(1001,'aaron','sabastin','udupi','10-12-1997',25000,'working','HR','10-12-2012')
insert tbl_Employees values(1002,'rahul','rao','chennai','11-01-1995',27000,'resigned','testing','11-01-2008')
insert tbl_Employees values(1003,'arjun','acharya','chennai','07-10-1997',23000,'resigned','HR','07-10-2005')
insert tbl_Employees values(1004,'john','tauro','pune','11-25-1994',35000,'working','R&D','11-25-2011')
insert tbl_Employees values(1005,'smitha','shetty','kolkata','12-14-1991',40000,'working','R&D','12-14-2000')
insert tbl_Employees values(1006,'gopi','rao','banglore','09-09-1992',22000,'working','sales','09-09-2003')
insert tbl_Employees values(1007,'lalith','sai','Chennai','02-19-1997',49000,'working','sales','02-19-2014')
insert tbl_Employees values(1008,'ram','sandeep','pune','05-17-1982',33000,'resigned','testing','07-11-2001')
insert tbl_Employees values(1009,'ashwini','dantis','udupi','08-02-1996',42000,'working','HR','01-01-2016')
insert tbl_Employees values(1010,'karthik','anchan','chennai','04-21-1994',29000,'working','Technical','06-07-2018')      

 select * from tbl_Employees

 select distinct employeeid,employeefname,employeelname,employeecity,employeeSalary from tbl_employees

 select * from tbl_Employees where employeeCity='chennai'

select * from tbl_Employees where Employeesalary between 25000 and 50000

select  concat(employeefname,+' '+employeelname),employeeid,employeeCity from tbl_Employees

select * from tbl_Employees

select  * from tbl_Employees  order by len(employeefname+employeeLname) asc

select sum(employeesalary) from tbl_Employees

select count(*) as count from tbl_Employees

select * from tbl_Employees where DATEPART(mm,employeedoj)=1

select * from tbl_Employees where datediff(yy,employeedoj,getdate())>5

select employeedept,count(*) noofemp from tbl_Employees group by EmployeeDept

select employeecity,count(*)  from tbl_Employees group by Employeecity

update tbl_Employees set employeecity='pune' where employeeCity='chennai'

select * from tbl_Employees


select EmployeeDept,count(*) from tbl_Employees where employeeSalary>50000 group by employeedept

select cast(employeesalary as decimal(12,4)) salary from tbl_Employees

update tbl_Employees set employeeStatus='resigned' where employeeStatus='working'

select * from tbl_Employees

select * from tbl_Employees where DATEPART(dd,employeedoj)=1

