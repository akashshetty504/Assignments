﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("account id");
            int AccID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("customer name");
            string name = Console.ReadLine();
            Console.WriteLine("account balance");
       
            int Balance = Convert.ToInt32(Console.ReadLine());

            Account obj = new Account(AccID, name, Balance);
            int NewBalance = obj.GetBalance();
            Console.WriteLine("Account balance : " + NewBalance);
            Console.WriteLine("enter an amount to withdraw");
            int Amt = Convert.ToInt32(Console.ReadLine());

            obj.Withdraw(Amt);
            NewBalance = obj.GetBalance();
            Console.Write("Account balance : " + NewBalance);
            Console.WriteLine("enter an amount to deposit :");

            Amt = Convert.ToInt32(Console.ReadLine());


           
            




            // Console.WriteLine("enter customer ID:");
            // int id = Convert.ToInt32(Console.ReadLine());
            // Console.WriteLine("enter customer name:");
            // string name = Console.ReadLine();
            // Console.WriteLine("enter customer city:");
            // string city = Console.ReadLine();
            // customer obj = new customer(id, name, city); 


            //string details = obj.GetDetails();
            // Console.WriteLine(details);


            Console.ReadLine();
        }
    }
}
