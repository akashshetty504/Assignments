﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms_Assignment
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private int ItemID;
        private int ItemQty;
        private int ItemPrice;
        private string DelivaryAddress;
        private string OrderCity;
        private string PaymentOption;


        public Order(int OrderID,string CustomerName,int ItemID,int ItemQty,int ItemPrice,string DelivaryAddress,string OrderCity)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemID = ItemID;
            this.ItemQty = ItemQty;
            this.ItemPrice = ItemPrice;
            this.DelivaryAddress = DelivaryAddress;
            this.OrderCity = OrderCity;
           
            
        }
        public int GetOrderValue()
        {
            return ItemPrice * ItemPrice;
        }
    }
}
