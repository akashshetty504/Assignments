﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_Assignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txt_ItemQty_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_ItemID_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Place_Order_Click(object sender, EventArgs e)
        {
            if (txt_OrderID.Text == string.Empty)
            {
                MessageBox.Show("enter the Order ID");
            }
            else if (txt_Customer_Name.Text == string.Empty)
            {
                MessageBox.Show("enter the customer name");
            }
            else if (txt_ItemID.Text == string.Empty)
            {
                MessageBox.Show("enter the item ID");
            }
            else if (txt_ItemQty.Text == string.Empty)
            {
                MessageBox.Show("enter the item qty");
            }
            else if (txt_Item_Price.Text == string.Empty)
            {
                MessageBox.Show("enter the item price");
            }
            else if (txt_Delivary_Address.Text == string.Empty)
            {
                MessageBox.Show("enter the Delivary Address");
            }
            else if (cmb_Order_City.Text == string.Empty)
            {
                MessageBox.Show("select a city");
            }
            else
            {
                if (rdb_Cash.Checked == false && rdb_Card.Checked == false && rdb_NetBanking.Checked == false)
                {
                    MessageBox.Show("Select Payment Opton");
                }
                else
                {
                    string PaymentOption = string.Empty;
                    if (rdb_Card.Checked)
                    {
                        PaymentOption = "Cash";
                    }
                    else if (rdb_Card.Checked)
                    {
                        PaymentOption = "Card";
                    }
                    else if (rdb_NetBanking.Checked)
                    {
                        PaymentOption = "NetBanking";
                    }
                    int OrderId = Convert.ToInt32(txt_OrderID.Text);
                    int ItemId = Convert.ToInt32(txt_ItemID.Text);
                    int Itemqty = Convert.ToInt32(txt_ItemQty.Text);
                    string Customername = txt_Customer_Name.Text;
                    int Itemprice = Convert.ToInt32(txt_Item_Price.Text);
                    string DelivaryAdd = txt_Delivary_Address.Text;
                    string Ordercity = cmb_Order_City.Text;


                    Order obj = new Order(OrderId, Customername, ItemId, Itemqty, Itemprice, DelivaryAdd, Ordercity);
                    int Amt = obj.GetOrderValue();
                    MessageBox.Show("order is placed:" + Amt);
                }
            }

            }
            
                
            
            
           }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_Order_City.Items.Add("pune");
            cmb_Order_City.Items.Add("Chennai");
            cmb_Order_City.Items.Add("Hyd");
        }
    }
    

