﻿namespace WindowsForms_Assignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_OrderID = new System.Windows.Forms.TextBox();
            this.txt_Customer_Name = new System.Windows.Forms.TextBox();
            this.txt_ItemID = new System.Windows.Forms.TextBox();
            this.txt_ItemQty = new System.Windows.Forms.TextBox();
            this.txt_Item_Price = new System.Windows.Forms.TextBox();
            this.txt_Delivary_Address = new System.Windows.Forms.TextBox();
            this.cmb_Order_City = new System.Windows.Forms.ComboBox();
            this.rdb_Cash = new System.Windows.Forms.RadioButton();
            this.rdb_Card = new System.Windows.Forms.RadioButton();
            this.rdb_NetBanking = new System.Windows.Forms.RadioButton();
            this.lbl_OrderID = new System.Windows.Forms.Label();
            this.lbl_Customer_Name = new System.Windows.Forms.Label();
            this.lbl_ItemID = new System.Windows.Forms.Label();
            this.lbl_ItemQty = new System.Windows.Forms.Label();
            this.lbl_Item_Price = new System.Windows.Forms.Label();
            this.lbl_Delivary_Address = new System.Windows.Forms.Label();
            this.btn_Place_Order = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_OrderID
            // 
            this.txt_OrderID.Location = new System.Drawing.Point(249, 33);
            this.txt_OrderID.Name = "txt_OrderID";
            this.txt_OrderID.Size = new System.Drawing.Size(100, 22);
            this.txt_OrderID.TabIndex = 0;
            // 
            // txt_Customer_Name
            // 
            this.txt_Customer_Name.Location = new System.Drawing.Point(249, 92);
            this.txt_Customer_Name.Name = "txt_Customer_Name";
            this.txt_Customer_Name.Size = new System.Drawing.Size(100, 22);
            this.txt_Customer_Name.TabIndex = 1;
            // 
            // txt_ItemID
            // 
            this.txt_ItemID.Location = new System.Drawing.Point(249, 153);
            this.txt_ItemID.Name = "txt_ItemID";
            this.txt_ItemID.Size = new System.Drawing.Size(100, 22);
            this.txt_ItemID.TabIndex = 2;
            this.txt_ItemID.TextChanged += new System.EventHandler(this.txt_ItemID_TextChanged);
            // 
            // txt_ItemQty
            // 
            this.txt_ItemQty.Location = new System.Drawing.Point(249, 214);
            this.txt_ItemQty.Name = "txt_ItemQty";
            this.txt_ItemQty.Size = new System.Drawing.Size(100, 22);
            this.txt_ItemQty.TabIndex = 3;
            this.txt_ItemQty.TextChanged += new System.EventHandler(this.txt_ItemQty_TextChanged);
            // 
            // txt_Item_Price
            // 
            this.txt_Item_Price.Location = new System.Drawing.Point(249, 272);
            this.txt_Item_Price.Name = "txt_Item_Price";
            this.txt_Item_Price.Size = new System.Drawing.Size(100, 22);
            this.txt_Item_Price.TabIndex = 4;
            // 
            // txt_Delivary_Address
            // 
            this.txt_Delivary_Address.Location = new System.Drawing.Point(249, 337);
            this.txt_Delivary_Address.Name = "txt_Delivary_Address";
            this.txt_Delivary_Address.Size = new System.Drawing.Size(100, 22);
            this.txt_Delivary_Address.TabIndex = 5;
            // 
            // cmb_Order_City
            // 
            this.cmb_Order_City.FormattingEnabled = true;
            this.cmb_Order_City.Location = new System.Drawing.Point(515, 21);
            this.cmb_Order_City.Name = "cmb_Order_City";
            this.cmb_Order_City.Size = new System.Drawing.Size(121, 24);
            this.cmb_Order_City.TabIndex = 6;
            // 
            // rdb_Cash
            // 
            this.rdb_Cash.AutoSize = true;
            this.rdb_Cash.Location = new System.Drawing.Point(525, 78);
            this.rdb_Cash.Name = "rdb_Cash";
            this.rdb_Cash.Size = new System.Drawing.Size(61, 21);
            this.rdb_Cash.TabIndex = 7;
            this.rdb_Cash.TabStop = true;
            this.rdb_Cash.Text = "Cash";
            this.rdb_Cash.UseVisualStyleBackColor = true;
            // 
            // rdb_Card
            // 
            this.rdb_Card.AutoSize = true;
            this.rdb_Card.Location = new System.Drawing.Point(525, 138);
            this.rdb_Card.Name = "rdb_Card";
            this.rdb_Card.Size = new System.Drawing.Size(59, 21);
            this.rdb_Card.TabIndex = 8;
            this.rdb_Card.TabStop = true;
            this.rdb_Card.Text = "Card";
            this.rdb_Card.UseVisualStyleBackColor = true;
            // 
            // rdb_NetBanking
            // 
            this.rdb_NetBanking.AutoSize = true;
            this.rdb_NetBanking.Location = new System.Drawing.Point(525, 200);
            this.rdb_NetBanking.Name = "rdb_NetBanking";
            this.rdb_NetBanking.Size = new System.Drawing.Size(102, 21);
            this.rdb_NetBanking.TabIndex = 9;
            this.rdb_NetBanking.TabStop = true;
            this.rdb_NetBanking.Text = "NetBanking";
            this.rdb_NetBanking.UseVisualStyleBackColor = true;
            // 
            // lbl_OrderID
            // 
            this.lbl_OrderID.AutoSize = true;
            this.lbl_OrderID.Location = new System.Drawing.Point(77, 36);
            this.lbl_OrderID.Name = "lbl_OrderID";
            this.lbl_OrderID.Size = new System.Drawing.Size(58, 17);
            this.lbl_OrderID.TabIndex = 10;
            this.lbl_OrderID.Text = "OrderID";
            // 
            // lbl_Customer_Name
            // 
            this.lbl_Customer_Name.AutoSize = true;
            this.lbl_Customer_Name.Location = new System.Drawing.Point(70, 98);
            this.lbl_Customer_Name.Name = "lbl_Customer_Name";
            this.lbl_Customer_Name.Size = new System.Drawing.Size(109, 17);
            this.lbl_Customer_Name.TabIndex = 11;
            this.lbl_Customer_Name.Text = "Customer Name";
            // 
            // lbl_ItemID
            // 
            this.lbl_ItemID.AutoSize = true;
            this.lbl_ItemID.Location = new System.Drawing.Point(75, 160);
            this.lbl_ItemID.Name = "lbl_ItemID";
            this.lbl_ItemID.Size = new System.Drawing.Size(47, 17);
            this.lbl_ItemID.TabIndex = 12;
            this.lbl_ItemID.Text = "ItemID";
            // 
            // lbl_ItemQty
            // 
            this.lbl_ItemQty.AutoSize = true;
            this.lbl_ItemQty.Location = new System.Drawing.Point(74, 218);
            this.lbl_ItemQty.Name = "lbl_ItemQty";
            this.lbl_ItemQty.Size = new System.Drawing.Size(60, 17);
            this.lbl_ItemQty.TabIndex = 13;
            this.lbl_ItemQty.Text = "Item Qty";
            // 
            // lbl_Item_Price
            // 
            this.lbl_Item_Price.AutoSize = true;
            this.lbl_Item_Price.Location = new System.Drawing.Point(75, 277);
            this.lbl_Item_Price.Name = "lbl_Item_Price";
            this.lbl_Item_Price.Size = new System.Drawing.Size(70, 17);
            this.lbl_Item_Price.TabIndex = 14;
            this.lbl_Item_Price.Text = "Item Price";
            // 
            // lbl_Delivary_Address
            // 
            this.lbl_Delivary_Address.AutoSize = true;
            this.lbl_Delivary_Address.Location = new System.Drawing.Point(70, 340);
            this.lbl_Delivary_Address.Name = "lbl_Delivary_Address";
            this.lbl_Delivary_Address.Size = new System.Drawing.Size(115, 17);
            this.lbl_Delivary_Address.TabIndex = 15;
            this.lbl_Delivary_Address.Text = "Delivary Address";
            // 
            // btn_Place_Order
            // 
            this.btn_Place_Order.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Place_Order.Location = new System.Drawing.Point(491, 322);
            this.btn_Place_Order.Name = "btn_Place_Order";
            this.btn_Place_Order.Size = new System.Drawing.Size(154, 37);
            this.btn_Place_Order.TabIndex = 16;
            this.btn_Place_Order.Text = "Place Order";
            this.btn_Place_Order.UseVisualStyleBackColor = true;
            this.btn_Place_Order.Click += new System.EventHandler(this.btn_Place_Order_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(986, 481);
            this.Controls.Add(this.btn_Place_Order);
            this.Controls.Add(this.lbl_Delivary_Address);
            this.Controls.Add(this.lbl_Item_Price);
            this.Controls.Add(this.lbl_ItemQty);
            this.Controls.Add(this.lbl_ItemID);
            this.Controls.Add(this.lbl_Customer_Name);
            this.Controls.Add(this.lbl_OrderID);
            this.Controls.Add(this.rdb_NetBanking);
            this.Controls.Add(this.rdb_Card);
            this.Controls.Add(this.rdb_Cash);
            this.Controls.Add(this.cmb_Order_City);
            this.Controls.Add(this.txt_Delivary_Address);
            this.Controls.Add(this.txt_Item_Price);
            this.Controls.Add(this.txt_ItemQty);
            this.Controls.Add(this.txt_ItemID);
            this.Controls.Add(this.txt_Customer_Name);
            this.Controls.Add(this.txt_OrderID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_OrderID;
        private System.Windows.Forms.TextBox txt_Customer_Name;
        private System.Windows.Forms.TextBox txt_ItemID;
        private System.Windows.Forms.TextBox txt_ItemQty;
        private System.Windows.Forms.TextBox txt_Item_Price;
        private System.Windows.Forms.TextBox txt_Delivary_Address;
        private System.Windows.Forms.ComboBox cmb_Order_City;
        private System.Windows.Forms.RadioButton rdb_Cash;
        private System.Windows.Forms.RadioButton rdb_Card;
        private System.Windows.Forms.RadioButton rdb_NetBanking;
        private System.Windows.Forms.Label lbl_OrderID;
        private System.Windows.Forms.Label lbl_Customer_Name;
        private System.Windows.Forms.Label lbl_ItemID;
        private System.Windows.Forms.Label lbl_ItemQty;
        private System.Windows.Forms.Label lbl_Item_Price;
        private System.Windows.Forms.Label lbl_Delivary_Address;
        private System.Windows.Forms.Button btn_Place_Order;
    }
}

