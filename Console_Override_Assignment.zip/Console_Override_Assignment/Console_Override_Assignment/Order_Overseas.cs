﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Override_Assignment
{
    class Order_Overseas:Order
    {
        public Order_Overseas(string CustomerName,String ItemName,int ItemQuantity,int ItemPrice)
            :base( CustomerName,ItemName,ItemQuantity,ItemPrice)
        {

        }
        public override int GetOrderValue()
        {

            int TotalOrderValue = PItemQuantity * PItemPrice + 1000;
            return TotalOrderValue;
        }
    }
}
