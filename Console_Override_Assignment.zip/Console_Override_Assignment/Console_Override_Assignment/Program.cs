﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Override_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the customer name");
            string Name = Console.ReadLine();
            Console.WriteLine("enter the item name");
            string Iname = Console.ReadLine();
            Console.WriteLine("enter the item quantity");
            int Quantity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the item price");
            int Price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the type");
            string Type = Console.ReadLine();

            Order obj = null;
            if (Type == "Order")
            {


                obj = new Order(Name, Iname, Quantity, Price);
            }
            else if(Type=="Order_seas")
            {
                obj = new Order_Overseas(Name, Iname, Quantity, Price);


            }

            if (obj != null)
            {
                int OrderAmount = obj.GetOrderValue();
                Console.WriteLine(OrderAmount);
                int sid = obj.PCustomerID;
                Console.WriteLine(sid);
                string Details = obj.GetDetails();
                Console.WriteLine(Details);
                Console.ReadLine();

            } 

        }
    }
}
