﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace wind_Reflection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_ReadType_Click(object sender, EventArgs e)
        {
            Type t = typeof(Test);
            MessageBox.Show(t.FullName);
            MessageBox.Show(t.Assembly.FullName);
            foreach(MethodInfo m in t.GetMethods())
            {
                MessageBox.Show(m.Name);
            }
        }
        Assembly asm;
        private void btn_LoadAssembly_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.ShowDialog();

            string dlladress = dialog.FileName;
            asm = Assembly.LoadFile(dlladress);
            MessageBox.Show(asm.FullName);


            lst_Classes.Items.Clear();
            foreach(Type t in asm.GetTypes())
            {
                lst_Classes.Items.Add(t.FullName);
            }
        }

        private void lst_Classes_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = lst_Classes.Text;
            Type t = asm.GetType(name);

            lst_Methods.Items.Clear();
            foreach(MethodInfo m in t.GetMethods())
            {
                lst_Methods.Items.Add(m.Name);
            }
        }

        private void btn_Call_Click(object sender, EventArgs e)
        {
            Type t = asm.GetType(lst_Classes.Text);
            object obj = Activator.CreateInstance(t);
            MethodInfo m = t.GetMethod(lst_Methods.Text);
            object returndata = m.Invoke(obj, null);
            MessageBox.Show(returndata.ToString());
        }
    }
}
