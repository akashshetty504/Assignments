﻿namespace wind_Reflection
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_ReadType = new System.Windows.Forms.Button();
            this.btn_LoadAssembly = new System.Windows.Forms.Button();
            this.lst_Classes = new System.Windows.Forms.ListBox();
            this.lst_Methods = new System.Windows.Forms.ListBox();
            this.btn_Call = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_ReadType
            // 
            this.btn_ReadType.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ReadType.Location = new System.Drawing.Point(113, 33);
            this.btn_ReadType.Name = "btn_ReadType";
            this.btn_ReadType.Size = new System.Drawing.Size(152, 73);
            this.btn_ReadType.TabIndex = 0;
            this.btn_ReadType.Text = "Read Type";
            this.btn_ReadType.UseVisualStyleBackColor = true;
            this.btn_ReadType.Click += new System.EventHandler(this.btn_ReadType_Click);
            // 
            // btn_LoadAssembly
            // 
            this.btn_LoadAssembly.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LoadAssembly.Location = new System.Drawing.Point(113, 150);
            this.btn_LoadAssembly.Name = "btn_LoadAssembly";
            this.btn_LoadAssembly.Size = new System.Drawing.Size(152, 73);
            this.btn_LoadAssembly.TabIndex = 1;
            this.btn_LoadAssembly.Text = "Load Assembly";
            this.btn_LoadAssembly.UseVisualStyleBackColor = true;
            this.btn_LoadAssembly.Click += new System.EventHandler(this.btn_LoadAssembly_Click);
            // 
            // lst_Classes
            // 
            this.lst_Classes.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_Classes.FormattingEnabled = true;
            this.lst_Classes.ItemHeight = 29;
            this.lst_Classes.Location = new System.Drawing.Point(62, 259);
            this.lst_Classes.Name = "lst_Classes";
            this.lst_Classes.Size = new System.Drawing.Size(263, 236);
            this.lst_Classes.TabIndex = 2;
            this.lst_Classes.SelectedIndexChanged += new System.EventHandler(this.lst_Classes_SelectedIndexChanged);
            // 
            // lst_Methods
            // 
            this.lst_Methods.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_Methods.FormattingEnabled = true;
            this.lst_Methods.ItemHeight = 29;
            this.lst_Methods.Location = new System.Drawing.Point(389, 259);
            this.lst_Methods.Name = "lst_Methods";
            this.lst_Methods.Size = new System.Drawing.Size(262, 236);
            this.lst_Methods.TabIndex = 3;
            // 
            // btn_Call
            // 
            this.btn_Call.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Call.Location = new System.Drawing.Point(684, 331);
            this.btn_Call.Name = "btn_Call";
            this.btn_Call.Size = new System.Drawing.Size(152, 73);
            this.btn_Call.TabIndex = 4;
            this.btn_Call.Text = "Call";
            this.btn_Call.UseVisualStyleBackColor = true;
            this.btn_Call.Click += new System.EventHandler(this.btn_Call_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 569);
            this.Controls.Add(this.btn_Call);
            this.Controls.Add(this.lst_Methods);
            this.Controls.Add(this.lst_Classes);
            this.Controls.Add(this.btn_LoadAssembly);
            this.Controls.Add(this.btn_ReadType);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_ReadType;
        private System.Windows.Forms.Button btn_LoadAssembly;
        private System.Windows.Forms.ListBox lst_Classes;
        private System.Windows.Forms.ListBox lst_Methods;
        private System.Windows.Forms.Button btn_Call;
    }
}

