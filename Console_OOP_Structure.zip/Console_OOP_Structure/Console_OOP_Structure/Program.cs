﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Structure
{
    class Program
    {
        static void Main(string[] args)
        {
            Book b1 = new Book(1, "Dotnet");
            Book b2 = new Book(2, "SQL");
            Console.WriteLine(b1.PName +" "+ b2.PName);//dotnet sql
            b1 = b2;
            Console.WriteLine(b1.PName + " " + b2.PName);//sql sql
            b2.PName = "XYZ";
            Console.WriteLine(b1.PName + " " + b2.PName);
            Console.ReadLine();

        }
    }
}
