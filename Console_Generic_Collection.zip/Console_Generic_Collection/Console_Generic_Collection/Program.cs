﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            College c = new College(1, "PathFront");
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("enter your operation:1-Add , 2-Find,3-Remove,4-show,5-Exit,6-Leave");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch(opt)
                {
                    case 1:
                        Console.WriteLine("enetr the student name");
                        string Name = Console.ReadLine();
                        Console.WriteLine("enter the student city");
                        string City = Console.ReadLine();
                        Student s = new Student(Name, City);
                        c.AddStudent(s);
                        Console.WriteLine("student Added:" + s.PStudentID);
                        break;
                    case 2:
                        Console.WriteLine("enter the student id");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Student obj = c.Find(ID);
                        if(obj!=null)
                        {
                            Console.WriteLine(obj.PStudentID + " " + obj.PStudentName);
                        }
                        else
                        {
                            Console.WriteLine("student not found");

                        } break;
                    case 3:
                        Console.WriteLine("enter the student id");
                        int SID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(SID);
                        if(status)
                        {
                            Console.WriteLine("Student removed");
                        }
                        else
                        {
                            Console.WriteLine("student not found");
                        }
                        break;
                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        Console.WriteLine("enter the student id");
                        int StdID = Convert.ToInt32(Console.ReadLine());
                        Student sobj = c.Find(StdID);
                        Console.WriteLine("enter the reason");
                        string Reason = Console.ReadLine();
                        sobj.TakeLeave(Reason);
                        break;


                }
            }

        }
    }
}
