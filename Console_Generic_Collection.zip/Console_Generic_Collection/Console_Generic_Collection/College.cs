﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collection
{
    class College
    {
        public void onLeave(int ID, string Reason)
        {
            Console.WriteLine("college class : student on leave:" + ID + " ," + Reason);
        }

        private int  CollegeID;
        private string CollegeName;

        public College( int CollegeID,string CollegeName)
        {
            this.CollegeID = CollegeID;
            this.CollegeName = CollegeName;

        }
       
        private List<Student> studentlist = new List<Student>();
        public void AddStudent(Student st)
        {
            Student.delleave d = new Student.delleave(this.onLeave);
            st.evtleave +=d;
            studentlist.Add(st);
        }
        public Student Find(int ID)
        {
            foreach(Student s in studentlist)
            {
                if(s.PStudentID==ID)
                {
                    return s;
                }
            }
            return null;
                  
        }
        public bool Remove(int ID)
        {
            foreach(Student s in studentlist)
            {
                if (s.PStudentID == ID)
                {
                    studentlist.Remove(s);
                    return true;
                }
            }return false;
        } 
        public void ShowAll()
        {
            foreach(Student s in studentlist)
            {
                Console.WriteLine(s.PStudentID + " " + s.PStudentName + " " + s.PStudentCity);
            }
        }

    }
}
