﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collection
{
    class Student
    {
        public delegate void delleave(int ID, string Reason);
        public event delleave evtleave;


        private int StudentID;
        private string StudentName;
        private string StudentCity;
        private static int count = 1000;

        public Student(string StudentName, string StudentCity)
        {
            Student.count++;
            this.StudentID = Student.count;
            this.StudentName = StudentName;
            this.StudentCity = StudentCity;
        }
        public int PStudentID { get { return this.StudentID; } }
        public string PStudentName { get { return this.StudentName; } }
        public string PStudentCity { get { return this.StudentCity; } }


            public void TakeLeave(string Reason)
        {
            if(this.evtleave!=null)
                {
                this.evtleave(this.StudentID, Reason);
            }
            Console.WriteLine("student on leave :" + this.StudentID + ",Reason : " + Reason);

        } }
    }

