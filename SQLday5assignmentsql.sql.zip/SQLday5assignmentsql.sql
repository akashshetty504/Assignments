select * from tbl_Students

create proc proc_addstudents(@name varchar(100),@city varchar(100),@address varchar(100),@email varchar(100))
as
insert tbl_Students values(@name,@city,@address,@email)

create proc proc_studentdetails(@id int)
as
select * from  tbl_Students where StudentID=@id

create proc proc_Showstudent(@city varchar(100))
as
select * from tbl_Students where StudenytCity=@city

create proc proc_Updatestudent(@id int,@city varchar(100),@address varchar(100),@email varchar(100))
as
update tbl_Students set StudenytCity=@city,StudentAddress=@address,StudentEmailID=@email
where StudentID=@id
return @@rowcount

create proc proc_deletestudent(@id int)
as
delete tbl_Students where StudentID=@id
return @@rowcount

create proc proc_searchstudent(@key varchar(100))
as
select * from tbl_Students where StudentID like '%'+@key+'%' or StudentName like '%'+@key+'%' or StudenytCity like '%'+@key+'%';
		

