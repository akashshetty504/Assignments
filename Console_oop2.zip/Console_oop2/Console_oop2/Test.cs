﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop2
{
    class Test
    {
        public void call(out int Amt)
        {
            Amt = 1000;
        }


        public void callArray(params int [] marks)
        {
            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }
        }

        public int GetOrderValue( int itemprice,int itemqty)
        {
           return itemqty * itemprice;
        }
    }

}
