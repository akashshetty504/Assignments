﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop2
{
    class Program
    {
        static void Main(string[] args)
        {
            XYZ obj1 = new XYZ();
            obj1.Call();
            obj1.GetData();

            
            int[] marks = new int[3];
            marks[0]= 10;
            marks[1] = 20;
            marks[2] = 30;


            Test obj = new Test();
            obj.callArray(16,29,50);
            int orderAmt = obj.GetOrderValue(itemqty:2, itemprice:1000);
            Console.WriteLine(orderAmt);
            int x ;
            obj.call(out x);
            Console.WriteLine(x);
            Console.ReadLine();

        }
    }
}
