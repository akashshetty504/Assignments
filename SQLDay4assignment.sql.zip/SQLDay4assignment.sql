create database CustomersADO

use CustomersADO

create table tbl_Customers
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(100),
CustomerCity Varchar(100),
CustomerPassword Varchar(100),
CustomerMobileNo varchar(100),
CustomerAddress varchar(100),
CustomerEmail varchar(100)
)

select * from tbl_Customers
