create table tbl_accounts
(
accountid int identity(1,1),
customername varchar(100),
accountbalance int
)
insert tbl_accounts values('john',3000)
insert tbl_accounts values('rahul',6000)
insert tbl_accounts values('lalith',4000)
insert tbl_accounts values('ram',8000)
insert tbl_accounts values('gopi',7000)

select*from tbl_accounts

