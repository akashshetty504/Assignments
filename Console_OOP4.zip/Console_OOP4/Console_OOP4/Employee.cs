﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4
{
    class Employee
    {
        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private double EmployeeSalary;


        public Employee(int EmployeeID,string EmployeeName,string EmployeeCity,double EmployeeSalary)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;

        }
     public double GetEmployeeSalary(int noofdays)
        {
            return EmployeeSalary * noofdays/30;

  

        }
        public string GetDetails()
        {
            return EmployeeID + " " + EmployeeName + " " + EmployeeCity + " " + EmployeeSalary;
        }


    }
}
