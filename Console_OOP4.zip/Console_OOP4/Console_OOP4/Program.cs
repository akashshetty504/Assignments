﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Employee ID");
            int ID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Employee Name");
            string Name = Console.ReadLine();
            Console.WriteLine("Employee City");
            string City = Console.ReadLine();
            Console.WriteLine("employee salary");
            double Salary = Convert.ToInt64(Console.ReadLine());

            Employee obj = new Employee( ID, Name, City, Salary);

            Console.WriteLine("no of days");
            int Day = Convert.ToInt32(Console.ReadLine());

            double totalsalary=obj.GetEmployeeSalary(Day);
            Console.WriteLine(totalsalary);

            string Details = obj.GetDetails();
            Console.WriteLine(Details);
            Console.ReadLine();

            
        }
    }
}
