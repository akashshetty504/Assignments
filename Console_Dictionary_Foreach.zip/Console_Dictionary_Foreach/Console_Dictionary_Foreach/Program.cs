﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Dictionary_Foreach
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> names = new Dictionary<string, string>();
            names.Add("E1", "Ajay");
            names.Add("E2", "vijay");
            names.Add("E3", "john");
            names.Add("E4", "julee");

            foreach(KeyValuePair<string,string> s in names)
            {
                Console.WriteLine(s.Key + " " + s.Value);
            }
            foreach(string k in names.Keys)
            {
                Console.WriteLine(k);
            }
            foreach(string v in names.Values)
            {
                Console.WriteLine(v);
            }

            string name = names["E1"];
            Console.WriteLine(names);
            Console.ReadLine();
        }
    }
}
