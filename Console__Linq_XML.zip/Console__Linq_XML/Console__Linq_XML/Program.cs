﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Console__Linq_XML
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement orders = new XElement("Orders", new XElement(
                "Order", new XElement("OrderID", "1001"),
                          new XElement("CustomerName", "XYZ"),
                          new XElement("OrderAmt", "20000")),

                          new XElement("Order", new XElement("OrderID", "1002"),
                          new XElement("CustomerName", "ABC"),
                          new XElement("OrderAmt", "30000"))


                          );

            orders.Save(@"C:/xml/orders.xml");
            Console.WriteLine("XML file Created");
                



            /*
            string url = @"C:\Users\Akash\Documents\Visual Studio 2015\Projects\library\Console__Linq_XML\Console__Linq_XML\customers.xml";

            XDocument doc = XDocument.Load(url);

            var data = from x in doc.Descendants("customer")

                       select new
                       {
                           CID = x.Element("CustomerID").Value,
                           CName = x.Element("CustomerName").Value,
                           CCity = x.Element("CustomerCity").Value


                       };
            foreach (var d in data)
            {
                Console.WriteLine(d.CID + " " + d.CName + " " + d.CCity);


            }
            */
            Console.ReadLine();
        }
    }
}
