select * from tbl_Customers

create proc proc_addcustomers(@name varchar(100),@city varchar(100),@password varchar(100),@mobileno varchar(100),@address varchar(100),@email varchar(100))
as
insert tbl_Customers values(@name,@city,@password,@mobileno,@address,@email)

create proc proc_Customerdetails(@id int)
as
select * from  tbl_Customers where CustomerID=@id

create proc proc_Showcustomers(@city varchar(100))
as
select * from tbl_Customers where CustomerCity=@city

create proc proc_Updatecustomers(@id int,@city varchar(100),@password varchar(100),@mobileno varchar(100),@address varchar(100),@email varchar(100))
as
update tbl_Customers set CustomerCity=@city,CustomerPassword=@password,CustomerMobileNo=@mobileno,CustomerAddress=@address,CustomerEmail=@email
where CustomerID=@id
return @@rowcount

create proc proc_deletecustomers(@id int)
as
delete tbl_Customers where CustomerID=@id
return @@rowcount

create proc proc_searchcustomers(@key varchar(100))
as
select * from tbl_Customers where CustomerID like '%'+@key+'%' or CustomerName like '%'+@key+'%' or CustomerCity like '%'+@key+'%';
		

create proc proc_login(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_Customers where CustomerID=@id and CustomerPassword=@password
return @count

