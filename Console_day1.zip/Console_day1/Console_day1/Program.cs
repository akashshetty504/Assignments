﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool flag = true;
            while (flag)
            {
                Console.WriteLine(flag);
                flag = false;
            }









            int[] num = new int[5];
            num[0] = 10;
            num[1] = 20;
            num[2] = 30;
            num[3] = 40;
            num[4] = 50;
            /*
            for(int c=0;c<num.Length;c++)
            {
                Console.WriteLine(num[c]);
            }
            */
            foreach(int n in num)
            {
                Console.WriteLine(n);
            }








            /*
            int x = 0;
            while(x<10)
            {
                Console.WriteLine(x);
                x++;

            }
            for(int c=0;c<10;c++)
            {
                Console.WriteLine(c);
            }
            
            int opt = 3;
            switch(opt)
            {
                case 1:
                    Console.WriteLine("one");
                    break;
                case 2:
                    Console.WriteLine("two");
                    break;
                default:
                    Console.WriteLine("wrong no.");
                    break;              
            }       
                 



            /*
            Console.WriteLine("enter the names: ");
            string itemname = Console.ReadLine();
            Console.WriteLine("enter item quantity:");
            int qty = Convert.ToInt32(Console.ReadLine());
            if (qty < 1)
            {
                Console.WriteLine("invalid quantity");
            }
            else
            {
                Console.WriteLine("order placed");

            }

           */
            Console.ReadLine();
        }
    }
}
