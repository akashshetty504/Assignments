create database bankdb

use bankdb

create table tbl_customerinfo
(
customerid int identity(100,1) primary key,
customername varchar(100) not null,
customercity varchar(100) not null,
customeraddress varchar (100) not null,
customermobileno varchar(15) not null unique,
customerpanno varchar(15) not null unique,
customerpassword varchar(100)
)

insert tbl_customerinfo values('abc','pune','xyz','9108842688','155263674ASD','password1')
insert tbl_customerinfo values('rahul','chennai','cbv','973765373','1763262','password2')

insert tbl_customerinfo values('iii','chennai','ggg','809879945412','99831103567','password9')

 select * from tbl_customerinfo

 create table tbl_accountinfo 
 (
 accountid int identity(1000,1) primary key,
 customerid int not null foreign key references tbl_customerinfo(customerid),
 accounttype varchar(100) not null,
 accountbalance int not null,
 accountopendate datetime not  null,
 accountstatus varchar(100) not null 
 )


 insert tbl_accountinfo values(106,'saving',62000,getdate(),'open')
 insert tbl_accountinfo values (100,'saving',20000,'09-12-2019','open')

select * from tbl_accountinfo


create table tbl_transactioninfo
(
transactionid int identity(10,1) primary key,
accountid int not null foreign key references tbl_accountinfo(accountid),
transactiontype varchar(100) not null,
amount int check(amount>0),
transactiondate datetime not null
)


insert tbl_transactioninfo values(1004,'debit',11000,getdate())


select * from tbl_transactioninfo

select * from tbl_customerinfo

select * from tbl_accountinfo

select tbl_customerinfo.customerid,tbl_customerinfo.customername,tbl_customerinfo.customeraddress,tbl_customerinfo.customermobileno,tbl_accountinfo.accountid,tbl_accountinfo.accountbalance
from tbl_customerinfo join tbl_accountinfo
on
tbl_customerinfo.customerid=tbl_accountinfo.customerid



--4


select tbl_accountinfo.accountid,tbl_accountinfo.accountbalance,tbl_transactioninfo.transactionid,
tbl_transactioninfo.amount,tbl_transactioninfo.transactiontype from 
tbl_accountinfo join tbl_transactioninfo on
tbl_accountinfo.accountid=tbl_transactioninfo.accountid
--5

select tbl_customerinfo.customerid,tbl_customerinfo.customername,tbl_customerinfo.customeraddress,tbl_customerinfo.customermobileno,
tbl_accountinfo.accountid,tbl_accountinfo.accountbalance,tbl_transactioninfo.transactionid,
tbl_transactioninfo.amount,tbl_transactioninfo.transactiontype from tbl_customerinfo join
tbl_accountinfo on tbl_customerinfo.customerid=tbl_accountinfo.customerid
join tbl_transactioninfo on
tbl_accountinfo.accountid=tbl_transactioninfo.accountid
--6

select * from tbl_customerinfo where customerid in (select customerid from tbl_accountinfo)
--7
select * from tbl_customerinfo where customerid not in(select customerid from tbl_accountinfo)
--8
select * from tbl_accountinfo where accountid in(select accountid from tbl_transactioninfo)
--9
select * from tbl_accountinfo where accountid not in (select accountid from tbl_transactioninfo)
--10
 
select  top 5  * from tbl_transactioninfo where accountid=1001 order by transactiondate desc
--1
select * from tbl_transactioninfo where transactiondate between '11-12-1996' and '09-12-2019'
--2
select * from tbl_accountinfo where customerid=101
--3