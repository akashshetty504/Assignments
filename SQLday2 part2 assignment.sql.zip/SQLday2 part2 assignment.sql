create database onlineorderingdb1

use onlineorderingdb1

create table tbl_restuarant
(
restuarantid int identity(10,1) primary key,
restuarantname varchar(100) not null,
restuarantcity varchar(100) not null,
restuarantaddress varchar (100) not null,
contactno varchar(15) not null unique,
)

insert tbl_restuarant values('lll','kolkata','dfy','232593411657') 

select * from tbl_restuarant


create table tbl_rmenuitems
(
menuid int identity(100,1) primary key,
restuarantid int not null foreign key references tbl_restuarant(restuarantid),
menuname varchar(100) not null,
menutype varchar(100) not null,
menucategory varchar (100) not null,
menuprice int not null,
menudesc varchar(100) not null
)

insert tbl_rmenuitems values(11,'strh','nonveg','south',4000,'wler')

select * from tbl_rmenuitems

create table tbl_customers
(
customerid varchar(200) primary key,
customername varchar(100) not null,
customercity varchar(100) not null,
customerdob datetime not null,
customergender varchar(100) not null,
customerpassword varchar(100) not null,
)

insert tbl_customers values('dghb@gmail.com','vbn','poiy','12-08-2000','female','password1')


select * from tbl_customers

 create table tbl_orders
(
orderid int identity(1000,1) primary key,
customerid varchar(200) not null foreign key references tbl_customers(customerid),
orderdate datetime not null,
delivaryaddress varchar(100) not null,
orderstatus varchar(100) not null,
)

insert tbl_orders values('rahul@gmail.com',getdate(),'iop','goihj')
select * from tbl_orders

create table tbl_ordermenus
(
orderid int not null foreign key references tbl_orders(orderid),
menuid int not null foreign key references tbl_rmenuitems(menuid),
menuqty int check(menuqty>0),
menuprice int check(menuprice>0),
)

insert tbl_ordermenus values(1002,103,2,55000)
select * from tbl_ordermenus


select restuarantname from tbl_restuarant where restuarantcity='kolkata'

select r.restuarantid,r.restuarantname,m.menuid,m.menuname,m.menuprice 
from tbl_restuarant r join tbl_rmenuitems m on 
r.restuarantid=m.restuarantid

select r.restuarantid,r.restuarantname,m.menuid,m.menuname,m.menuprice 
from tbl_restuarant r join tbl_rmenuitems m on 
r.restuarantid=m.restuarantid
where restuarantcity='kolkata'

select * from tbl_orders 
where customerid='rao@gmail.com'

select o.orderid,c.customerid,o.orderdate,m.menuid,m.menuqty,m.menuprice from tbl_orders o
join tbl_customers c on c.customerid=o.customerid join tbl_ordermenus m on 
o.orderid=m.orderid

select top 5* from tbl_orders where customerid='rao@gmail.com'
order by customerid desc

select * from tbl_ordermenus order by menuprice asc

select count(restuarantname) as 'No of restuarant',restuarantcity from tbl_restuarant group by restuarantcity

select customername from tbl_customers where customerid not in(select customerid from tbl_orders)

select top 1 * from tbl_rmenuitems order by menuprice desc

select top 1 * from tbl_rmenuitems where menuid in(select top 2 with ties menuid from
tbl_rmenuitems order by menuprice desc)order by menuprice asc

