﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP3_Properties
{
    class Program
    {
        static void Main(string[] args)
        {
           

            Console.WriteLine("enter student name");
            string Name = Console.ReadLine();

            Console.WriteLine("enter the marks");
            int Marks = Convert.ToInt32(Console.ReadLine());

            Student obj = new Student( Name, Marks);

            int sid = obj.PStudentID;
            string sname = obj.PStudentName;
            int smarks = obj.PStudentMarks;
            Student s1 = new Student("ABC", 90);
            Console.WriteLine(s1.PStudentID);

            Console.WriteLine(sid + " " + sname + " " + smarks);

            obj.PStudentMarks = 101;
            Console.WriteLine(obj.PStudentMarks);
            obj.PStudentMarks = 90;
            Console.WriteLine(obj.PStudentMarks);


            Console.ReadLine();



        }
    }
}
