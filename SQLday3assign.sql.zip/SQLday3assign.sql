create database EmployeesManagementDB

use EmployeesManagementDB

create table tbl_employee
(
employeeid int identity(100,1) primary key,
employeename varchar(100) not null,
employeecity varchar(100) not null,
employeesalary int,
employeedob varchar (100) not null,
employeemobileno varchar(15) not null unique,
employeedoj varchar(15) not null ,
employeepassword varchar(100),
employeeemailid varchar(100) unique,
employeedept varchar(100)
)

insert tbl_employee values('rdtt','goa',35000,'01-01-1998','2467863487','01-01-2010','password1',
'kjc@gmail.com','sales')

select * from tbl_employee

create table tbl_ava_leaves
(
 employeeid int not null foreign key references tbl_employee(employeeid),
 stickleave varchar(100),
causalleave varchar(100),
 vocationleave varchar(100),
 compoff varchar(100)
 )

 insert tbl_ava_leaves values(104,'dhyfz','hdfcvbn','cgoghj','tfgct')
 select * from tbl_ava_leaves

 create table tbl_employeeleaves
 (
 employeeid int not null foreign key references tbl_employee(employeeid),
  LeaveType varchar(100) ,
  LeaveApplyDate datetime , 
  LeaveDate datetime, 
  NoOfLeaves int
 )

 insert tbl_employeeleaves values(104,'cuasal','02-02-2006','02-05-2006',3)

  select  * from tbl_employeeleaves



  create table tbl_EmployeeSalary
  (
 employeeid int not null foreign key references tbl_employee(employeeid),
EmployeeSalary int , 
SalaryMonth int , 
SalaryYear int, 
SalaryDate int
)

insert tbl_EmployeeSalary values(103,15000,05,2006,18)

select * from tbl_EmployeeSalary
