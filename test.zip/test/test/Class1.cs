﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    public class Class1
    {
        public string Call1()
        {
            return "hello from call1";        }
        public string Call2()
        {
            return "hello from call2";
         }
    }
}
