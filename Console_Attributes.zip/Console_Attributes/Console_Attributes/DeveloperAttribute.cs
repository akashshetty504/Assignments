﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Attributes
{
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Method)]
    class DeveloperAttribute:Attribute
    {
        public string DeveloperID { get; set; }
        public string DeveloperName { get; set; }

        public DeveloperAttribute(string DeveloperID,string DeveloperName)
        {
            this.DeveloperID = DeveloperID;
            this.DeveloperName = DeveloperName;
        }
    }
}
