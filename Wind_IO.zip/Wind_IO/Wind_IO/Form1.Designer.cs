﻿namespace Wind_IO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_BinaryWriter = new System.Windows.Forms.Button();
            this.btn_BinaryReader = new System.Windows.Forms.Button();
            this.btn_StreamReader = new System.Windows.Forms.Button();
            this.btn_StreamWriter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_BinaryWriter
            // 
            this.btn_BinaryWriter.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BinaryWriter.Location = new System.Drawing.Point(73, 76);
            this.btn_BinaryWriter.Name = "btn_BinaryWriter";
            this.btn_BinaryWriter.Size = new System.Drawing.Size(176, 86);
            this.btn_BinaryWriter.TabIndex = 0;
            this.btn_BinaryWriter.Text = "Binary Writer";
            this.btn_BinaryWriter.UseVisualStyleBackColor = true;
            this.btn_BinaryWriter.Click += new System.EventHandler(this.btn_BinaryWriter_Click);
            // 
            // btn_BinaryReader
            // 
            this.btn_BinaryReader.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BinaryReader.Location = new System.Drawing.Point(72, 224);
            this.btn_BinaryReader.Name = "btn_BinaryReader";
            this.btn_BinaryReader.Size = new System.Drawing.Size(177, 86);
            this.btn_BinaryReader.TabIndex = 1;
            this.btn_BinaryReader.Text = "Binary Reader";
            this.btn_BinaryReader.UseVisualStyleBackColor = true;
            this.btn_BinaryReader.Click += new System.EventHandler(this.btn_BinaryReader_Click);
            // 
            // btn_StreamReader
            // 
            this.btn_StreamReader.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_StreamReader.Location = new System.Drawing.Point(349, 224);
            this.btn_StreamReader.Name = "btn_StreamReader";
            this.btn_StreamReader.Size = new System.Drawing.Size(177, 86);
            this.btn_StreamReader.TabIndex = 3;
            this.btn_StreamReader.Text = "Stream Reader";
            this.btn_StreamReader.UseVisualStyleBackColor = true;
            this.btn_StreamReader.Click += new System.EventHandler(this.btn_StreamReader_Click);
            // 
            // btn_StreamWriter
            // 
            this.btn_StreamWriter.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_StreamWriter.Location = new System.Drawing.Point(350, 76);
            this.btn_StreamWriter.Name = "btn_StreamWriter";
            this.btn_StreamWriter.Size = new System.Drawing.Size(176, 86);
            this.btn_StreamWriter.TabIndex = 2;
            this.btn_StreamWriter.Text = "Stream Writer";
            this.btn_StreamWriter.UseVisualStyleBackColor = true;
            this.btn_StreamWriter.Click += new System.EventHandler(this.btn_StreamWriter_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 451);
            this.Controls.Add(this.btn_StreamReader);
            this.Controls.Add(this.btn_StreamWriter);
            this.Controls.Add(this.btn_BinaryReader);
            this.Controls.Add(this.btn_BinaryWriter);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_BinaryWriter;
        private System.Windows.Forms.Button btn_BinaryReader;
        private System.Windows.Forms.Button btn_StreamReader;
        private System.Windows.Forms.Button btn_StreamWriter;
    }
}

