﻿namespace Wind_Serialization
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_ProductID = new System.Windows.Forms.Label();
            this.lbl_ProductName = new System.Windows.Forms.Label();
            this.lbl_ProductPrice = new System.Windows.Forms.Label();
            this.txt_ProductID = new System.Windows.Forms.TextBox();
            this.txt_ProductName = new System.Windows.Forms.TextBox();
            this.txt_ProductPrice = new System.Windows.Forms.TextBox();
            this.btn_Serialize = new System.Windows.Forms.Button();
            this.btn_Deserialize = new System.Windows.Forms.Button();
            this.btn_XMLDeserialize = new System.Windows.Forms.Button();
            this.btn_XMLSerialize = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_ProductID
            // 
            this.lbl_ProductID.AutoSize = true;
            this.lbl_ProductID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProductID.Location = new System.Drawing.Point(69, 57);
            this.lbl_ProductID.Name = "lbl_ProductID";
            this.lbl_ProductID.Size = new System.Drawing.Size(125, 29);
            this.lbl_ProductID.TabIndex = 0;
            this.lbl_ProductID.Text = "Product ID";
            // 
            // lbl_ProductName
            // 
            this.lbl_ProductName.AutoSize = true;
            this.lbl_ProductName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProductName.Location = new System.Drawing.Point(66, 138);
            this.lbl_ProductName.Name = "lbl_ProductName";
            this.lbl_ProductName.Size = new System.Drawing.Size(161, 29);
            this.lbl_ProductName.TabIndex = 1;
            this.lbl_ProductName.Text = "ProductName";
            // 
            // lbl_ProductPrice
            // 
            this.lbl_ProductPrice.AutoSize = true;
            this.lbl_ProductPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ProductPrice.Location = new System.Drawing.Point(65, 217);
            this.lbl_ProductPrice.Name = "lbl_ProductPrice";
            this.lbl_ProductPrice.Size = new System.Drawing.Size(158, 29);
            this.lbl_ProductPrice.TabIndex = 2;
            this.lbl_ProductPrice.Text = "Product Price";
            // 
            // txt_ProductID
            // 
            this.txt_ProductID.Location = new System.Drawing.Point(233, 64);
            this.txt_ProductID.Name = "txt_ProductID";
            this.txt_ProductID.Size = new System.Drawing.Size(100, 22);
            this.txt_ProductID.TabIndex = 3;
            // 
            // txt_ProductName
            // 
            this.txt_ProductName.Location = new System.Drawing.Point(233, 148);
            this.txt_ProductName.Name = "txt_ProductName";
            this.txt_ProductName.Size = new System.Drawing.Size(100, 22);
            this.txt_ProductName.TabIndex = 4;
            // 
            // txt_ProductPrice
            // 
            this.txt_ProductPrice.Location = new System.Drawing.Point(233, 217);
            this.txt_ProductPrice.Name = "txt_ProductPrice";
            this.txt_ProductPrice.Size = new System.Drawing.Size(100, 22);
            this.txt_ProductPrice.TabIndex = 5;
            // 
            // btn_Serialize
            // 
            this.btn_Serialize.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Serialize.Location = new System.Drawing.Point(102, 324);
            this.btn_Serialize.Name = "btn_Serialize";
            this.btn_Serialize.Size = new System.Drawing.Size(115, 34);
            this.btn_Serialize.TabIndex = 6;
            this.btn_Serialize.Text = "Serialize";
            this.btn_Serialize.UseVisualStyleBackColor = true;
            this.btn_Serialize.Click += new System.EventHandler(this.btn_Serialize_Click);
            // 
            // btn_Deserialize
            // 
            this.btn_Deserialize.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Deserialize.Location = new System.Drawing.Point(317, 324);
            this.btn_Deserialize.Name = "btn_Deserialize";
            this.btn_Deserialize.Size = new System.Drawing.Size(145, 38);
            this.btn_Deserialize.TabIndex = 7;
            this.btn_Deserialize.Text = "Deserialize";
            this.btn_Deserialize.UseVisualStyleBackColor = true;
            this.btn_Deserialize.Click += new System.EventHandler(this.btn_Deserialize_Click);
            // 
            // btn_XMLDeserialize
            // 
            this.btn_XMLDeserialize.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_XMLDeserialize.Location = new System.Drawing.Point(317, 419);
            this.btn_XMLDeserialize.Name = "btn_XMLDeserialize";
            this.btn_XMLDeserialize.Size = new System.Drawing.Size(145, 98);
            this.btn_XMLDeserialize.TabIndex = 9;
            this.btn_XMLDeserialize.Text = "XML Deserialize";
            this.btn_XMLDeserialize.UseVisualStyleBackColor = true;
            this.btn_XMLDeserialize.Click += new System.EventHandler(this.btn_XMLDeserialize_Click);
            // 
            // btn_XMLSerialize
            // 
            this.btn_XMLSerialize.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_XMLSerialize.Location = new System.Drawing.Point(102, 419);
            this.btn_XMLSerialize.Name = "btn_XMLSerialize";
            this.btn_XMLSerialize.Size = new System.Drawing.Size(115, 78);
            this.btn_XMLSerialize.TabIndex = 8;
            this.btn_XMLSerialize.Text = "XML Serialize";
            this.btn_XMLSerialize.UseVisualStyleBackColor = true;
            this.btn_XMLSerialize.Click += new System.EventHandler(this.btn_XMLSerialize_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 561);
            this.Controls.Add(this.btn_XMLDeserialize);
            this.Controls.Add(this.btn_XMLSerialize);
            this.Controls.Add(this.btn_Deserialize);
            this.Controls.Add(this.btn_Serialize);
            this.Controls.Add(this.txt_ProductPrice);
            this.Controls.Add(this.txt_ProductName);
            this.Controls.Add(this.txt_ProductID);
            this.Controls.Add(this.lbl_ProductPrice);
            this.Controls.Add(this.lbl_ProductName);
            this.Controls.Add(this.lbl_ProductID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_ProductID;
        private System.Windows.Forms.Label lbl_ProductName;
        private System.Windows.Forms.Label lbl_ProductPrice;
        private System.Windows.Forms.TextBox txt_ProductID;
        private System.Windows.Forms.TextBox txt_ProductName;
        private System.Windows.Forms.TextBox txt_ProductPrice;
        private System.Windows.Forms.Button btn_Serialize;
        private System.Windows.Forms.Button btn_Deserialize;
        private System.Windows.Forms.Button btn_XMLDeserialize;
        private System.Windows.Forms.Button btn_XMLSerialize;
    }
}

