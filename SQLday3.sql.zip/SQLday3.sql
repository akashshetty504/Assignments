create database PathFrontADO

use PathFrontADO

create table tbl_employee
(
EmployeeID int identity(1000,1),
EmployeeName varchar(100),
EmployeeCity varchar(100),
EmployeePassword varchar(100),
EmployeeDOj datetime
)

select* from tbl_employee

