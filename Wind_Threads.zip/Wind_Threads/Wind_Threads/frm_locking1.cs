﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Wind_Threads
{
    public partial class frm_locking1 : Form
    {
        ReaderWriterLock rw = new ReaderWriterLock();


        int total;
        public void sum()
        {
            int n1 = Convert.ToInt32(txt_Number1.Text);
            int n2 = Convert.ToInt32(txt_Number2.Text);
            // if (Monitor.TryEnter(this,3000))
            // lock (this)
            // {
            // {
            rw.AcquireReaderLock(Timeout.Infinite);
                total = n1 + n2;
                Thread.Sleep(15000);
                MessageBox.Show("Total :" + total);
            rw.ReleaseLock();
                // }
               // Monitor.Exit(this);
           // }
           // else
//{
               // MessageBox.Show("Other task");
           // }
        }


        public void sum2()
        {
            int n1 = Convert.ToInt32(txt_Number1.Text);
            int n2 = Convert.ToInt32(txt_Number2.Text);
            // if (Monitor.TryEnter(this,3000))
            // lock (this)
            // {
            // {
            rw.AcquireWriterLock(Timeout.Infinite);
            total = n1 + n2;
            Thread.Sleep(15000);
            MessageBox.Show("Total :" + total);
            rw.ReleaseLock();
            // }
            // Monitor.Exit(this);
            // }
            // else
            //{
            // MessageBox.Show("Other task");
            // }
        }

        public frm_locking1()
        {
            InitializeComponent();
        }

        private void btn_Thread1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(this.sum);
            th1.Start();
        }

        private void btn_Thread2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(this.sum2);
            th2.Start();
        }
    }
}
