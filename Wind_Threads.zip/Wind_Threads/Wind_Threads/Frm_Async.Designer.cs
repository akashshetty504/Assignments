﻿namespace Wind_Threads
{
    partial class Frm_Async
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_AsyncSum = new System.Windows.Forms.Button();
            this.txt_Number2 = new System.Windows.Forms.TextBox();
            this.txt_Number1 = new System.Windows.Forms.TextBox();
            this.lbl_Number2 = new System.Windows.Forms.Label();
            this.lbl_Number1 = new System.Windows.Forms.Label();
            this.lst_msgd = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_AsyncSum
            // 
            this.btn_AsyncSum.Location = new System.Drawing.Point(236, 246);
            this.btn_AsyncSum.Name = "btn_AsyncSum";
            this.btn_AsyncSum.Size = new System.Drawing.Size(132, 23);
            this.btn_AsyncSum.TabIndex = 9;
            this.btn_AsyncSum.Text = "Async Sum";
            this.btn_AsyncSum.UseVisualStyleBackColor = true;
            this.btn_AsyncSum.Click += new System.EventHandler(this.btn_AsyncSum_Click);
            // 
            // txt_Number2
            // 
            this.txt_Number2.Location = new System.Drawing.Point(331, 181);
            this.txt_Number2.Name = "txt_Number2";
            this.txt_Number2.Size = new System.Drawing.Size(100, 22);
            this.txt_Number2.TabIndex = 8;
            // 
            // txt_Number1
            // 
            this.txt_Number1.Location = new System.Drawing.Point(332, 88);
            this.txt_Number1.Name = "txt_Number1";
            this.txt_Number1.Size = new System.Drawing.Size(100, 22);
            this.txt_Number1.TabIndex = 7;
            // 
            // lbl_Number2
            // 
            this.lbl_Number2.AutoSize = true;
            this.lbl_Number2.Location = new System.Drawing.Point(169, 176);
            this.lbl_Number2.Name = "lbl_Number2";
            this.lbl_Number2.Size = new System.Drawing.Size(70, 17);
            this.lbl_Number2.TabIndex = 6;
            this.lbl_Number2.Text = "Number 2";
            // 
            // lbl_Number1
            // 
            this.lbl_Number1.AutoSize = true;
            this.lbl_Number1.Location = new System.Drawing.Point(177, 94);
            this.lbl_Number1.Name = "lbl_Number1";
            this.lbl_Number1.Size = new System.Drawing.Size(70, 17);
            this.lbl_Number1.TabIndex = 5;
            this.lbl_Number1.Text = "Number 1";
            // 
            // lst_msgd
            // 
            this.lst_msgd.FormattingEnabled = true;
            this.lst_msgd.ItemHeight = 16;
            this.lst_msgd.Location = new System.Drawing.Point(248, 301);
            this.lst_msgd.Name = "lst_msgd";
            this.lst_msgd.Size = new System.Drawing.Size(120, 84);
            this.lst_msgd.TabIndex = 10;
            // 
            // Frm_Async
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 397);
            this.Controls.Add(this.lst_msgd);
            this.Controls.Add(this.btn_AsyncSum);
            this.Controls.Add(this.txt_Number2);
            this.Controls.Add(this.txt_Number1);
            this.Controls.Add(this.lbl_Number2);
            this.Controls.Add(this.lbl_Number1);
            this.Name = "Frm_Async";
            this.Text = "Frm_Async";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_AsyncSum;
        private System.Windows.Forms.TextBox txt_Number2;
        private System.Windows.Forms.TextBox txt_Number1;
        private System.Windows.Forms.Label lbl_Number2;
        private System.Windows.Forms.Label lbl_Number1;
        private System.Windows.Forms.ListBox lst_msgd;
    }
}