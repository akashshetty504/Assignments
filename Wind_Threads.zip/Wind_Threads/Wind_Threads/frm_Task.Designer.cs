﻿namespace Wind_Threads
{
    partial class frm_Task
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Task = new System.Windows.Forms.Button();
            this.btn_Task2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Task
            // 
            this.btn_Task.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Task.Location = new System.Drawing.Point(105, 102);
            this.btn_Task.Name = "btn_Task";
            this.btn_Task.Size = new System.Drawing.Size(143, 35);
            this.btn_Task.TabIndex = 0;
            this.btn_Task.Text = "New Task";
            this.btn_Task.UseVisualStyleBackColor = true;
            this.btn_Task.Click += new System.EventHandler(this.btn_Task_Click);
            // 
            // btn_Task2
            // 
            this.btn_Task2.Location = new System.Drawing.Point(137, 202);
            this.btn_Task2.Name = "btn_Task2";
            this.btn_Task2.Size = new System.Drawing.Size(75, 23);
            this.btn_Task2.TabIndex = 1;
            this.btn_Task2.Text = "New Task2";
            this.btn_Task2.UseVisualStyleBackColor = true;
            this.btn_Task2.Click += new System.EventHandler(this.btn_Task2_Click);
            // 
            // frm_Task
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 320);
            this.Controls.Add(this.btn_Task2);
            this.Controls.Add(this.btn_Task);
            this.Name = "frm_Task";
            this.Text = "frm_Task";
            this.Load += new System.EventHandler(this.frm_Task_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Task;
        private System.Windows.Forms.Button btn_Task2;
    }
}