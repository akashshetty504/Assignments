﻿namespace Wind_Threads
{
    partial class Wind_Thread_Pool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_ThreadPool = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_ThreadPool
            // 
            this.btn_ThreadPool.Location = new System.Drawing.Point(217, 152);
            this.btn_ThreadPool.Name = "btn_ThreadPool";
            this.btn_ThreadPool.Size = new System.Drawing.Size(126, 23);
            this.btn_ThreadPool.TabIndex = 0;
            this.btn_ThreadPool.Text = "Thread Pool";
            this.btn_ThreadPool.UseVisualStyleBackColor = true;
            this.btn_ThreadPool.Click += new System.EventHandler(this.btn_ThreadPool_Click);
            // 
            // Wind_Thread_Pool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 363);
            this.Controls.Add(this.btn_ThreadPool);
            this.Name = "Wind_Thread_Pool";
            this.Text = "Wind_Thread_Pool";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_ThreadPool;
    }
}