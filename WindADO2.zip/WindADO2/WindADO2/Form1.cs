﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindADO2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
       
          if (txt_StudentName.Text == string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if (txt_StudentCity.Text == string.Empty)
            {
                MessageBox.Show("enter city");

            }
            else if (txt_StudentAddress.Text == string.Empty)
            {
                MessageBox.Show("enter Address");

            }
            else if (txt_StudentEmailID.Text == string.Empty)
            {
                MessageBox.Show("enter emailid");

            }

            else
            {
                string Name = txt_StudentName.Text;
                string City = txt_StudentCity.Text;
                string Address =txt_StudentAddress.Text;
                string EmailID = txt_StudentEmailID.Text;
                Student obj = new Student();
                obj.StudentName = Name;
                obj.StudentCity = City;
                obj.StudentAddress = Address;
                obj.StudentEmailID = EmailID;

                StudentDAL dal = new StudentDAL();
                int id = dal.AddStudents(obj);
                MessageBox.Show("Student added:" + id);

            }
        }

        private void btn_Find_Click(object sender, EventArgs e)
        {
        
            if (txt_StudentID.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");

            }
            else
            {
                int ID = Convert.ToInt32(txt_StudentID.Text);
                StudentDAL dal = new StudentDAL();
                Student std = dal.Find(ID);
                if (std != null)

                {

                    txt_StudentName.Text = std.StudentName;
                    txt_StudentCity.Text = std.StudentCity;

                    txt_StudentAddress.Text = std.StudentAddress;
                    txt_StudentEmailID.Text = std.StudentEmailID;
                }
                else
                {
                    MessageBox.Show("not found");
                }



            }

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
        
            if (txt_StudentID.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if (txt_StudentName.Text == string.Empty)
            {
                MessageBox.Show("enter Name");

            }
            else if (txt_StudentCity.Text == string.Empty)
            {
                MessageBox.Show("enter City");

            }
            else if (txt_StudentAddress.Text == string.Empty)
            {
                MessageBox.Show("enter Address");

            }
            else if (txt_StudentEmailID.Text == string.Empty)
            {
                MessageBox.Show("enter EmailID");

            }
            else
            {
                int ID = Convert.ToInt32(txt_StudentID.Text);
                string Name = txt_StudentName.Text;
                string City = txt_StudentCity.Text;
                string Address = txt_StudentAddress.Text;
                string EmailID = txt_StudentEmailID.Text;

                StudentDAL dal = new StudentDAL();
                bool status = dal.update(ID, Name,City,Address,EmailID);
                if (status)
                {
                    MessageBox.Show("updated");

                }
                else
                {
                    MessageBox.Show("not updated");
                }


            }

        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (txt_StudentID.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_StudentID.Text);
                StudentDAL dal = new StudentDAL();
                bool status = dal.Delete(ID);
                if (status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }

    }
}




