﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WindADO2
{
    class StudentDAL
    {
        SqlConnection con = new SqlConnection
           (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddStudents(Student std)
        {
            SqlCommand com_std_insert = new SqlCommand
                ("proc_addstudents", con);
            com_std_insert.Parameters.AddWithValue("@name", std.StudentName);
            com_std_insert.Parameters.AddWithValue("@city", std.StudentCity);
            com_std_insert.Parameters.AddWithValue("@address",std.StudentAddress);
            com_std_insert.Parameters.AddWithValue("@email", std.StudentEmailID);
            com_std_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_std_insert.Parameters.Add(retdata);

            con.Open();

            com_std_insert.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;


        }
        public Student Find(int ID)
        {
            SqlCommand com_find = new SqlCommand
            ("proc_studentdetails", con);
            com_find.Parameters.AddWithValue("@id", ID);
            com_find.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                Student s = new Student();
                s.StudentID = dr.GetInt32(0);
                s.StudentName = dr.GetString(1);
                s.StudentCity = dr.GetString(2);
                s.StudentAddress = dr.GetString(3);
                s.StudentEmailID = dr.GetString(4);
                con.Close();
                return s;
            }
            else
            {
                return null;
            }
        }

        public bool update(int ID, string Name, string City, string Address,string EmaiID)
        {
            SqlCommand com_update = new SqlCommand
                ("proc_Updatestudent", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@name", Name);
            com_update.Parameters.AddWithValue("@city", City);
            com_update.Parameters.AddWithValue("@address", Address);
            com_update.Parameters.AddWithValue("@emailid", EmaiID);
            com_update.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_update.Parameters.Add(retdata);

            con.Open();
             com_update.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand
         ("proc_deletestudent", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            com_delete.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_delete.Parameters.Add(retdata);

            con.Open();
             com_delete.ExecuteNonQuery();
            con.Close();
                int count = Convert.ToInt32(retdata.Value);
            if (count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }

        }


        public List<Student> Showstudent(string City)
        {
            SqlCommand com_student = new SqlCommand("proc_Showstudent", con);
            com_student.Parameters.AddWithValue("@city", City);
            com_student.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_student.ExecuteReader();

            List<Student> stdlist = new List<Student>();
            while (dr.Read())
            {
                Student obj = new Student();
                obj.StudentID = dr.GetInt32(0);
                obj.StudentName = dr.GetString(1);
                obj.StudentCity = dr.GetString(2);
                obj.StudentAddress = dr.GetString(3);
               obj.StudentEmailID = dr.GetString(4);

                stdlist.Add(obj);
            }
            con.Close();
            return stdlist;


        }

        public List<Student> Searchstudent(string Search)

        {
            SqlCommand com_Search = new SqlCommand
                ("proc_searchstudent", con);
            com_Search.Parameters.AddWithValue("@key", Search);
            com_Search.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = com_Search.ExecuteReader();
            List<Student> stdlist = new List<Student>();
            while (dr.Read())
            {
                Student std = new Student();
                std.StudentID = dr.GetInt32(0);
                std.StudentName = dr.GetString(1);
                std.StudentCity = dr.GetString(2);
                std.StudentAddress = dr.GetString(5);
                std.StudentEmailID = dr.GetString(6);

                stdlist.Add(std);


            }
            con.Close();
            return stdlist;
        }


    }
}
