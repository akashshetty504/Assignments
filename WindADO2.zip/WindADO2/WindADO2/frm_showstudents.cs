﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindADO2
{
    public partial class frm_showstudents : Form
    {
        public frm_showstudents()
        {
            InitializeComponent();
        }

        private void frm_showstudents_Load(object sender, EventArgs e)
        {

        }

        private void btn_Find_Click(object sender, EventArgs e)
        {

            StudentDAL dal = new StudentDAL();
            string City = txt_StudentCity.Text;
            List<Student> list = dal.Showstudent(City);
            dg_student.DataSource = list;

        }

        private void dg_Customers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_SearchAll_Click(object sender, EventArgs e)
        {

            StudentDAL dal = new StudentDAL();
            string key = txt_Search1.Text;
            List<Student> list = dal.Searchstudent(key);
            dg_student.DataSource = list;

        }
    }
}
