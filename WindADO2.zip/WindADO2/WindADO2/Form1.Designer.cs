﻿namespace WindADO2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_StudentID = new System.Windows.Forms.Label();
            this.lbl_StudentName = new System.Windows.Forms.Label();
            this.lbl_StudentCity = new System.Windows.Forms.Label();
            this.lbl_StudentAddress = new System.Windows.Forms.Label();
            this.lbl_StudentEmailID = new System.Windows.Forms.Label();
            this.txt_StudentID = new System.Windows.Forms.TextBox();
            this.txt_StudentName = new System.Windows.Forms.TextBox();
            this.txt_StudentCity = new System.Windows.Forms.TextBox();
            this.txt_StudentEmailID = new System.Windows.Forms.TextBox();
            this.txt_StudentAddress = new System.Windows.Forms.TextBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_StudentID
            // 
            this.lbl_StudentID.AutoSize = true;
            this.lbl_StudentID.Location = new System.Drawing.Point(81, 49);
            this.lbl_StudentID.Name = "lbl_StudentID";
            this.lbl_StudentID.Size = new System.Drawing.Size(74, 17);
            this.lbl_StudentID.TabIndex = 0;
            this.lbl_StudentID.Text = "Student ID";
            // 
            // lbl_StudentName
            // 
            this.lbl_StudentName.AutoSize = true;
            this.lbl_StudentName.Location = new System.Drawing.Point(74, 122);
            this.lbl_StudentName.Name = "lbl_StudentName";
            this.lbl_StudentName.Size = new System.Drawing.Size(98, 17);
            this.lbl_StudentName.TabIndex = 1;
            this.lbl_StudentName.Text = "Student Name";
            // 
            // lbl_StudentCity
            // 
            this.lbl_StudentCity.AutoSize = true;
            this.lbl_StudentCity.Location = new System.Drawing.Point(80, 183);
            this.lbl_StudentCity.Name = "lbl_StudentCity";
            this.lbl_StudentCity.Size = new System.Drawing.Size(84, 17);
            this.lbl_StudentCity.TabIndex = 2;
            this.lbl_StudentCity.Text = "Student City";
            // 
            // lbl_StudentAddress
            // 
            this.lbl_StudentAddress.AutoSize = true;
            this.lbl_StudentAddress.Location = new System.Drawing.Point(79, 253);
            this.lbl_StudentAddress.Name = "lbl_StudentAddress";
            this.lbl_StudentAddress.Size = new System.Drawing.Size(113, 17);
            this.lbl_StudentAddress.TabIndex = 3;
            this.lbl_StudentAddress.Text = "Student Address";
            // 
            // lbl_StudentEmailID
            // 
            this.lbl_StudentEmailID.AutoSize = true;
            this.lbl_StudentEmailID.Location = new System.Drawing.Point(74, 317);
            this.lbl_StudentEmailID.Name = "lbl_StudentEmailID";
            this.lbl_StudentEmailID.Size = new System.Drawing.Size(108, 17);
            this.lbl_StudentEmailID.TabIndex = 4;
            this.lbl_StudentEmailID.Text = "Student EmailID";
            // 
            // txt_StudentID
            // 
            this.txt_StudentID.Location = new System.Drawing.Point(199, 52);
            this.txt_StudentID.Name = "txt_StudentID";
            this.txt_StudentID.Size = new System.Drawing.Size(100, 22);
            this.txt_StudentID.TabIndex = 5;
            // 
            // txt_StudentName
            // 
            this.txt_StudentName.Location = new System.Drawing.Point(199, 122);
            this.txt_StudentName.Name = "txt_StudentName";
            this.txt_StudentName.Size = new System.Drawing.Size(100, 22);
            this.txt_StudentName.TabIndex = 6;
            // 
            // txt_StudentCity
            // 
            this.txt_StudentCity.Location = new System.Drawing.Point(199, 183);
            this.txt_StudentCity.Name = "txt_StudentCity";
            this.txt_StudentCity.Size = new System.Drawing.Size(100, 22);
            this.txt_StudentCity.TabIndex = 7;
            // 
            // txt_StudentEmailID
            // 
            this.txt_StudentEmailID.Location = new System.Drawing.Point(199, 312);
            this.txt_StudentEmailID.Name = "txt_StudentEmailID";
            this.txt_StudentEmailID.Size = new System.Drawing.Size(100, 22);
            this.txt_StudentEmailID.TabIndex = 8;
            // 
            // txt_StudentAddress
            // 
            this.txt_StudentAddress.Location = new System.Drawing.Point(199, 253);
            this.txt_StudentAddress.Name = "txt_StudentAddress";
            this.txt_StudentAddress.Size = new System.Drawing.Size(100, 22);
            this.txt_StudentAddress.TabIndex = 9;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(569, 56);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(75, 23);
            this.btn_Add.TabIndex = 10;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(569, 122);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 23);
            this.btn_Find.TabIndex = 11;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // btn_Update
            // 
            this.btn_Update.Location = new System.Drawing.Point(569, 177);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(75, 23);
            this.btn_Update.TabIndex = 12;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = true;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(569, 247);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 23);
            this.btn_Delete.TabIndex = 13;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(975, 471);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.txt_StudentAddress);
            this.Controls.Add(this.txt_StudentEmailID);
            this.Controls.Add(this.txt_StudentCity);
            this.Controls.Add(this.txt_StudentName);
            this.Controls.Add(this.txt_StudentID);
            this.Controls.Add(this.lbl_StudentEmailID);
            this.Controls.Add(this.lbl_StudentAddress);
            this.Controls.Add(this.lbl_StudentCity);
            this.Controls.Add(this.lbl_StudentName);
            this.Controls.Add(this.lbl_StudentID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_StudentID;
        private System.Windows.Forms.Label lbl_StudentName;
        private System.Windows.Forms.Label lbl_StudentCity;
        private System.Windows.Forms.Label lbl_StudentAddress;
        private System.Windows.Forms.Label lbl_StudentEmailID;
        private System.Windows.Forms.TextBox txt_StudentID;
        private System.Windows.Forms.TextBox txt_StudentName;
        private System.Windows.Forms.TextBox txt_StudentCity;
        private System.Windows.Forms.TextBox txt_StudentEmailID;
        private System.Windows.Forms.TextBox txt_StudentAddress;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_Delete;
    }
}

