﻿namespace WindADO2
{
    partial class frm_showstudents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_student = new System.Windows.Forms.DataGridView();
            this.btn_SearchAll = new System.Windows.Forms.Button();
            this.btn_Find = new System.Windows.Forms.Button();
            this.txt_Search1 = new System.Windows.Forms.TextBox();
            this.txt_StudentCity = new System.Windows.Forms.TextBox();
            this.lbl_Search = new System.Windows.Forms.Label();
            this.lbl_StudentCity = new System.Windows.Forms.Label();
            this.lbl_Search1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_student)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_student
            // 
            this.dg_student.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_student.Location = new System.Drawing.Point(45, 237);
            this.dg_student.Name = "dg_student";
            this.dg_student.RowTemplate.Height = 24;
            this.dg_student.Size = new System.Drawing.Size(779, 305);
            this.dg_student.TabIndex = 20;
            this.dg_student.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_Customers_CellContentClick);
            // 
            // btn_SearchAll
            // 
            this.btn_SearchAll.Location = new System.Drawing.Point(610, 102);
            this.btn_SearchAll.Name = "btn_SearchAll";
            this.btn_SearchAll.Size = new System.Drawing.Size(121, 23);
            this.btn_SearchAll.TabIndex = 19;
            this.btn_SearchAll.Text = "Search(All)";
            this.btn_SearchAll.UseVisualStyleBackColor = true;
            this.btn_SearchAll.Click += new System.EventHandler(this.btn_SearchAll_Click);
            // 
            // btn_Find
            // 
            this.btn_Find.Location = new System.Drawing.Point(610, 12);
            this.btn_Find.Name = "btn_Find";
            this.btn_Find.Size = new System.Drawing.Size(75, 23);
            this.btn_Find.TabIndex = 18;
            this.btn_Find.Text = "Find";
            this.btn_Find.UseVisualStyleBackColor = true;
            this.btn_Find.Click += new System.EventHandler(this.btn_Find_Click);
            // 
            // txt_Search1
            // 
            this.txt_Search1.Location = new System.Drawing.Point(399, 93);
            this.txt_Search1.Name = "txt_Search1";
            this.txt_Search1.Size = new System.Drawing.Size(100, 22);
            this.txt_Search1.TabIndex = 17;
            // 
            // txt_StudentCity
            // 
            this.txt_StudentCity.Location = new System.Drawing.Point(399, 12);
            this.txt_StudentCity.Name = "txt_StudentCity";
            this.txt_StudentCity.Size = new System.Drawing.Size(100, 22);
            this.txt_StudentCity.TabIndex = 16;
            // 
            // lbl_Search
            // 
            this.lbl_Search.AutoSize = true;
            this.lbl_Search.Location = new System.Drawing.Point(-93, 67);
            this.lbl_Search.Name = "lbl_Search";
            this.lbl_Search.Size = new System.Drawing.Size(53, 17);
            this.lbl_Search.TabIndex = 15;
            this.lbl_Search.Text = "Search";
            // 
            // lbl_StudentCity
            // 
            this.lbl_StudentCity.AutoSize = true;
            this.lbl_StudentCity.Location = new System.Drawing.Point(203, 18);
            this.lbl_StudentCity.Name = "lbl_StudentCity";
            this.lbl_StudentCity.Size = new System.Drawing.Size(84, 17);
            this.lbl_StudentCity.TabIndex = 14;
            this.lbl_StudentCity.Text = "Student City";
            // 
            // lbl_Search1
            // 
            this.lbl_Search1.AutoSize = true;
            this.lbl_Search1.Location = new System.Drawing.Point(220, 109);
            this.lbl_Search1.Name = "lbl_Search1";
            this.lbl_Search1.Size = new System.Drawing.Size(61, 17);
            this.lbl_Search1.TabIndex = 21;
            this.lbl_Search1.Text = "Search1";
            // 
            // frm_showstudents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1444, 608);
            this.Controls.Add(this.lbl_Search1);
            this.Controls.Add(this.dg_student);
            this.Controls.Add(this.btn_SearchAll);
            this.Controls.Add(this.btn_Find);
            this.Controls.Add(this.txt_Search1);
            this.Controls.Add(this.txt_StudentCity);
            this.Controls.Add(this.lbl_Search);
            this.Controls.Add(this.lbl_StudentCity);
            this.Name = "frm_showstudents";
            this.Text = "frm_showstudents";
            this.Load += new System.EventHandler(this.frm_showstudents_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_student)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_student;
        private System.Windows.Forms.Button btn_SearchAll;
        private System.Windows.Forms.Button btn_Find;
        private System.Windows.Forms.TextBox txt_Search1;
        private System.Windows.Forms.TextBox txt_StudentCity;
        private System.Windows.Forms.Label lbl_Search;
        private System.Windows.Forms.Label lbl_StudentCity;
        private System.Windows.Forms.Label lbl_Search1;
    }
}