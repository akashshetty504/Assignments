﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindADO2
{
    class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public string StudentCity { get; set; }
        public string StudentAddress { get; set; }
        public string StudentEmailID { get; set; }
    }
}
