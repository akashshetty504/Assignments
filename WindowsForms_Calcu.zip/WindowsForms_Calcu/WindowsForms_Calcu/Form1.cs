﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_Calcu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_GetSum_Click(object sender, EventArgs e)
        {
            if (txt_N1.Text == string.Empty)
            {
                MessageBox.Show("enter number 1");

            }
            else if (txt_N2.Text == string.Empty)
            {
                MessageBox.Show("enter number 2");
            }
            else
            {
                int n1 = Convert.ToInt32(txt_N1.Text);
                int n2 = Convert.ToInt32(txt_N2.Text);

                Calculators.Cals obj = new Calculators.Cals();
                int total1 = obj.GetSum(n1, n2);
                lbl_Sum.Text = total1.ToString();

            }
        }

        private void btn_Multiplication_Click(object sender, EventArgs e)
        {
            if (txt_N1.Text == string.Empty)
            {
                MessageBox.Show("enter number 1");

            }
            else if (txt_N2.Text == string.Empty)
            {
                MessageBox.Show("enter number 2");
            }
            else
            {
                int n1 = Convert.ToInt32(txt_N1.Text);
                int n2 = Convert.ToInt32(txt_N2.Text);

                Calculators.Cals obj = new Calculators.Cals();
                int total2 = obj.GetMultiply(n1, n2);
                lbl_Multiplication.Text = total2.ToString();
            }
        }

        private void btn_GetDivision_Click(object sender, EventArgs e)
        {
            if (txt_N1.Text == string.Empty)
            {
                MessageBox.Show("enter number 1");

            }
            else if (txt_N2.Text == string.Empty)
            {
                MessageBox.Show("enter number 2");
            }
            else
            {
                int n1 = Convert.ToInt32(txt_N1.Text);
                int n2 = Convert.ToInt32(txt_N2.Text);

                Calculators.Cals obj = new Calculators.Cals();
                int total3 = obj.GetDivide(n1, n2);
                lbl_Division.Text = total3.ToString();
            }
        }

        private void btn_GetSubtraction_Click(object sender, EventArgs e)
        {
            if (txt_N1.Text == string.Empty)
            {
                MessageBox.Show("enter number 1");

            }
            else if (txt_N2.Text == string.Empty)
            {
                MessageBox.Show("enter number 2");
            }
            else
            {
                int n1 = Convert.ToInt32(txt_N1.Text);
                int n2 = Convert.ToInt32(txt_N2.Text);

                Calculators.Cals obj = new Calculators.Cals();
                int total4 = obj.GetSubtract(n1, n2);
                lbl_Subtraction.Text = total4.ToString();
            }
        }

    }
}


        
    
