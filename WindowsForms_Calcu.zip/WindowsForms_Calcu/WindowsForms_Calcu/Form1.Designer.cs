﻿namespace WindowsForms_Calcu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_N1 = new System.Windows.Forms.Label();
            this.lbl_N2 = new System.Windows.Forms.Label();
            this.txt_N1 = new System.Windows.Forms.TextBox();
            this.txt_N2 = new System.Windows.Forms.TextBox();
            this.btn_GetSum = new System.Windows.Forms.Button();
            this.btn_Multiplication = new System.Windows.Forms.Button();
            this.btn_GetDivision = new System.Windows.Forms.Button();
            this.btn_GetSubtraction = new System.Windows.Forms.Button();
            this.lbl_Sum = new System.Windows.Forms.Label();
            this.lbl_Multiplication = new System.Windows.Forms.Label();
            this.lbl_Division = new System.Windows.Forms.Label();
            this.lbl_Subtraction = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_N1
            // 
            this.lbl_N1.AutoSize = true;
            this.lbl_N1.Location = new System.Drawing.Point(119, 60);
            this.lbl_N1.Name = "lbl_N1";
            this.lbl_N1.Size = new System.Drawing.Size(26, 17);
            this.lbl_N1.TabIndex = 0;
            this.lbl_N1.Text = "N1";
            // 
            // lbl_N2
            // 
            this.lbl_N2.AutoSize = true;
            this.lbl_N2.Location = new System.Drawing.Point(119, 137);
            this.lbl_N2.Name = "lbl_N2";
            this.lbl_N2.Size = new System.Drawing.Size(26, 17);
            this.lbl_N2.TabIndex = 1;
            this.lbl_N2.Text = "N2";
            // 
            // txt_N1
            // 
            this.txt_N1.Location = new System.Drawing.Point(211, 62);
            this.txt_N1.Name = "txt_N1";
            this.txt_N1.Size = new System.Drawing.Size(100, 22);
            this.txt_N1.TabIndex = 2;
            // 
            // txt_N2
            // 
            this.txt_N2.Location = new System.Drawing.Point(216, 139);
            this.txt_N2.Name = "txt_N2";
            this.txt_N2.Size = new System.Drawing.Size(100, 22);
            this.txt_N2.TabIndex = 3;
            // 
            // btn_GetSum
            // 
            this.btn_GetSum.Location = new System.Drawing.Point(162, 227);
            this.btn_GetSum.Name = "btn_GetSum";
            this.btn_GetSum.Size = new System.Drawing.Size(75, 23);
            this.btn_GetSum.TabIndex = 4;
            this.btn_GetSum.Text = "GetSum";
            this.btn_GetSum.UseVisualStyleBackColor = true;
            this.btn_GetSum.Click += new System.EventHandler(this.btn_GetSum_Click);
            // 
            // btn_Multiplication
            // 
            this.btn_Multiplication.Location = new System.Drawing.Point(162, 299);
            this.btn_Multiplication.Name = "btn_Multiplication";
            this.btn_Multiplication.Size = new System.Drawing.Size(75, 23);
            this.btn_Multiplication.TabIndex = 5;
            this.btn_Multiplication.Text = "Getmultiplication";
            this.btn_Multiplication.UseVisualStyleBackColor = true;
            this.btn_Multiplication.Click += new System.EventHandler(this.btn_Multiplication_Click);
            // 
            // btn_GetDivision
            // 
            this.btn_GetDivision.Location = new System.Drawing.Point(162, 367);
            this.btn_GetDivision.Name = "btn_GetDivision";
            this.btn_GetDivision.Size = new System.Drawing.Size(75, 23);
            this.btn_GetDivision.TabIndex = 6;
            this.btn_GetDivision.Text = "GetDivision";
            this.btn_GetDivision.UseVisualStyleBackColor = true;
            this.btn_GetDivision.Click += new System.EventHandler(this.btn_GetDivision_Click);
            // 
            // btn_GetSubtraction
            // 
            this.btn_GetSubtraction.Location = new System.Drawing.Point(162, 432);
            this.btn_GetSubtraction.Name = "btn_GetSubtraction";
            this.btn_GetSubtraction.Size = new System.Drawing.Size(75, 23);
            this.btn_GetSubtraction.TabIndex = 7;
            this.btn_GetSubtraction.Text = "GetSubtraction";
            this.btn_GetSubtraction.UseVisualStyleBackColor = true;
            this.btn_GetSubtraction.Click += new System.EventHandler(this.btn_GetSubtraction_Click);
            // 
            // lbl_Sum
            // 
            this.lbl_Sum.AutoSize = true;
            this.lbl_Sum.Location = new System.Drawing.Point(365, 227);
            this.lbl_Sum.Name = "lbl_Sum";
            this.lbl_Sum.Size = new System.Drawing.Size(36, 17);
            this.lbl_Sum.TabIndex = 8;
            this.lbl_Sum.Text = "Sum";
            // 
            // lbl_Multiplication
            // 
            this.lbl_Multiplication.AutoSize = true;
            this.lbl_Multiplication.Location = new System.Drawing.Point(365, 299);
            this.lbl_Multiplication.Name = "lbl_Multiplication";
            this.lbl_Multiplication.Size = new System.Drawing.Size(89, 17);
            this.lbl_Multiplication.TabIndex = 9;
            this.lbl_Multiplication.Text = "Multiplication";
            // 
            // lbl_Division
            // 
            this.lbl_Division.AutoSize = true;
            this.lbl_Division.Location = new System.Drawing.Point(365, 367);
            this.lbl_Division.Name = "lbl_Division";
            this.lbl_Division.Size = new System.Drawing.Size(57, 17);
            this.lbl_Division.TabIndex = 10;
            this.lbl_Division.Text = "Division";
            // 
            // lbl_Subtraction
            // 
            this.lbl_Subtraction.AutoSize = true;
            this.lbl_Subtraction.Location = new System.Drawing.Point(365, 432);
            this.lbl_Subtraction.Name = "lbl_Subtraction";
            this.lbl_Subtraction.Size = new System.Drawing.Size(80, 17);
            this.lbl_Subtraction.TabIndex = 11;
            this.lbl_Subtraction.Text = "Subtraction";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 495);
            this.Controls.Add(this.lbl_Subtraction);
            this.Controls.Add(this.lbl_Division);
            this.Controls.Add(this.lbl_Multiplication);
            this.Controls.Add(this.lbl_Sum);
            this.Controls.Add(this.btn_GetSubtraction);
            this.Controls.Add(this.btn_GetDivision);
            this.Controls.Add(this.btn_Multiplication);
            this.Controls.Add(this.btn_GetSum);
            this.Controls.Add(this.txt_N2);
            this.Controls.Add(this.txt_N1);
            this.Controls.Add(this.lbl_N2);
            this.Controls.Add(this.lbl_N1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_N1;
        private System.Windows.Forms.Label lbl_N2;
        private System.Windows.Forms.TextBox txt_N1;
        private System.Windows.Forms.TextBox txt_N2;
        private System.Windows.Forms.Button btn_GetSum;
        private System.Windows.Forms.Button btn_Multiplication;
        private System.Windows.Forms.Button btn_GetDivision;
        private System.Windows.Forms.Button btn_GetSubtraction;
        private System.Windows.Forms.Label lbl_Sum;
        private System.Windows.Forms.Label lbl_Multiplication;
        private System.Windows.Forms.Label lbl_Division;
        private System.Windows.Forms.Label lbl_Subtraction;
    }
}

